/** @type {import('tailwindcss').Config} */
const scale = [
  '50',
  '100',
  '200',
  '300',
  '400',
  '500',
  '600',
  '700',
  '800',
  '900',
  '950',
];

const buildScale = (name: string) =>
  scale.reduce<Record<string, string>>((acc, step) => {
    acc[step] = `oklch(var(--${name}-${step}) / <alpha-value>)`;
    return acc;
  }, {});

export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        background: buildScale('background'),
        primary: buildScale('primary'),
        accent: buildScale('accent'),
        secondary: buildScale('secondary'),
        foreground: buildScale('foreground'),
      },
      fontFamily: {
        sans: ['var(--font-body)'],
        body: ['var(--font-body)'],
        heading: ['var(--font-heading)'],
        display: ['var(--font-heading)'],
        label: ['var(--font-label)'],
      },
      maxWidth: {
        content: '1240px',
      },
      transitionTimingFunction: {
        smooth: 'cubic-bezier(0.22, 1, 0.36, 1)',
      },
    },
  },
  plugins: [],
};