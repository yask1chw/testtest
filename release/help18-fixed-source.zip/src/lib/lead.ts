/**
 * Единый механизм обработки заявок для всех форм сайта.
 *
 * Все формы отправляют данные в один обработчик и передают одинаковый набор
 * служебных полей: request_id, form_id, section_id, page_url, page_title,
 * utm-метки, дату и время, ссылку на согласие и статус обработки.
 *
 * Подключение CRM, телефонии или коллтрекинга выполняется на серверной стороне
 * (Supabase Edge Function / API обработчика формы). Секретные ключи нельзя
 * хранить в клиентском коде, поэтому здесь предусмотрена только публичная
 * точка подключения через VITE_PUBLIC_CRM_WEBHOOK_URL.
 */

const env = import.meta.env as unknown as Record<string, string | undefined>;

export const LEAD_FORM_ID = 'dbfkamgob50fdbpndc8g';
export const LEAD_FORM_ENDPOINT = 'https://readdy.ai/api/form/dbfkamgob50fdbpndc8g';

/** Публичный вебхук приёмника заявок (CRM/уведомления). Задаётся при настройке. */
const CRM_WEBHOOK_URL = (env.VITE_PUBLIC_CRM_WEBHOOK_URL || '').trim();

const UTM_KEYS = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'] as const;
const UTM_STORAGE_KEY = 'nm_utm';

export type LeadStatus = 'idle' | 'sending' | 'success' | 'error';

export interface LeadContext {
  formId: string;
  formName: string;
  sectionId: string;
}

export interface LeadResult {
  ok: boolean;
  message: string;
}

function readUtm(): Record<string, string> {
  const result: Record<string, string> = {};

  if (typeof window === 'undefined') {
    return result;
  }

  const search = new URLSearchParams(window.location.search);
  UTM_KEYS.forEach((key) => {
    const value = search.get(key);
    if (value) {
      result[key] = value;
    }
  });

  try {
    if (Object.keys(result).length > 0) {
      window.sessionStorage.setItem(UTM_STORAGE_KEY, JSON.stringify(result));
    } else {
      const stored = window.sessionStorage.getItem(UTM_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as Record<string, string>;
        UTM_KEYS.forEach((key) => {
          if (parsed[key]) {
            result[key] = parsed[key];
          }
        });
      }
    }
  } catch {
    // sessionStorage может быть недоступен — заявка всё равно отправляется.
  }

  return result;
}

function createRequestId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `req-${Date.now()}-${Math.random().toString(16).slice(2, 10)}`;
}

function parseServer(response: Response, responseText: string) {
  let parsed: {
    code?: string;
    message?: string;
    meta?: { message?: string; detail?: string };
  } | null = null;

  try {
    parsed = JSON.parse(responseText);
  } catch {
    parsed = null;
  }

  const serverMessage =
    parsed?.meta?.message || parsed?.message || parsed?.meta?.detail || responseText || '';
  const normalized = typeof serverMessage === 'string' ? serverMessage : '';
  const isSpam = normalized.toLowerCase().includes('spam');
  const isSuccess = response.ok && parsed?.code === 'OK' && !isSpam;

  return { isSuccess, isSpam, serverMessage: normalized };
}

export async function submitLead(
  form: HTMLFormElement,
  context: LeadContext,
): Promise<LeadResult> {
  const formData = new FormData(form);

  const honeypot = String(formData.get('website_alt') || '').trim();
  if (honeypot) {
    return {
      ok: true,
      message: 'Спасибо! Заявка отправлена. Специалист клиники свяжется с вами.',
    };
  }
  formData.delete('website_alt');

  const phone = String(formData.get('phone') || '').trim();
  if (phone.replace(/\D/g, '').length < 10) {
    return {
      ok: false,
      message: 'Проверьте номер телефона — в нём должно быть не меньше 10 цифр.',
    };
  }

  const params = new URLSearchParams();
  formData.forEach((value, key) => {
    if (typeof value === 'string' && value.trim() !== '') {
      params.append(key, value);
    }
  });

  const requestId = createRequestId();
  const utm = readUtm();

  params.append('request_id', requestId);
  params.append('form_id', context.formId);
  params.append('form_name', context.formName);
  params.append('section_id', context.sectionId);
  params.append('page_url', typeof window !== 'undefined' ? window.location.href : '');
  params.append('page_title', typeof document !== 'undefined' ? document.title : '');
  params.append('created_at', new Date().toISOString());
  params.append('consent_reference', 'policy-v1');
  params.append('processing_status', 'new');
  Object.entries(utm).forEach(([key, value]) => params.append(key, value));

  try {
    const response = await fetch(LEAD_FORM_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString(),
    });

    const responseText = await response.text();
    const { isSuccess, isSpam, serverMessage } = parseServer(response, responseText);

    if (!isSuccess) {
      return {
        ok: false,
        message: isSpam
          ? 'Не удалось отправить заявку. Попробуйте ещё раз или позвоните в клинику.'
          : serverMessage || 'Не удалось отправить заявку. Попробуйте ещё раз или позвоните в клинику.',
      };
    }

    if (CRM_WEBHOOK_URL) {
      fetch(CRM_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          request_id: requestId,
          form_id: context.formId,
          form_name: context.formName,
          section_id: context.sectionId,
          phone,
          page_url: typeof window !== 'undefined' ? window.location.href : '',
          ...utm,
          created_at: new Date().toISOString(),
        }),
      }).catch(() => {
        // Приёмник CRM недоступен — заявка уже сохранена основным обработчиком.
      });
    }

    return {
      ok: true,
      message: 'Спасибо! Заявка отправлена. Специалист клиники свяжется с вами в соответствии с режимом работы.',
    };
  } catch {
    return {
      ok: false,
      message: 'Не удалось отправить заявку. Проверьте соединение или позвоните в клинику.',
    };
  }
}