/**
 * Аналитика сайта — единая точка подключения Яндекс Метрики и отправки целей.
 *
 * Идентификатор счётчика задаётся через переменную окружения
 * VITE_PUBLIC_YANDEX_METRIKA_ID. Случайный идентификатор не подставляется:
 * пока значение не задано, счётчик не загружается, а события складываются
 * только в dataLayer — это подготовленная точка интеграции, а не имитация
 * работающей аналитики.
 *
 * В события никогда не передаются контактные данные, сведения о диагнозе
 * и свободные описания состояния пациента. Набор параметров ограничен
 * белым списком ниже.
 */

const env = import.meta.env as unknown as Record<string, string | undefined>;

export const METRIKA_ID = (env.VITE_PUBLIC_YANDEX_METRIKA_ID || '').trim();

declare global {
  interface Window {
    dataLayer?: Record<string, unknown>[];
    ym?: (counterId: number, action: string, ...args: unknown[]) => void;
  }
}

/** Названия целей из технического задания. */
export const ANALYTICS_EVENTS = [
  'click_phone',
  'open_callback',
  'submit_callback',
  'callback_success',
  'callback_error',
  'click_service',
  'click_prices',
  'click_doctor',
  'click_route',
  'click_messenger',
] as const;

export type AnalyticsEventName = (typeof ANALYTICS_EVENTS)[number] | 'page_view';

/** Белый список параметров: всё остальное отбрасывается. */
const ALLOWED_PARAMS = [
  'page_path',
  'section_id',
  'button_id',
  'service_category',
  'form_id',
  'form_name',
] as const;

type EventParams = Partial<Record<(typeof ALLOWED_PARAMS)[number], string>>;

let initialized = false;
const recentPageViews = new Map<string, number>();

function sanitizeParams(params: EventParams): Record<string, string> {
  const result: Record<string, string> = {};
  ALLOWED_PARAMS.forEach((key) => {
    const value = params[key];
    if (typeof value === 'string' && value.trim() !== '') {
      result[key] = value;
    }
  });
  return result;
}

function getPagePath(): string {
  if (typeof window === 'undefined') {
    return '';
  }
  return `${window.location.pathname}${window.location.search}`;
}

function pushToDataLayer(payload: Record<string, unknown>): void {
  if (typeof window === 'undefined') {
    return;
  }
  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push(payload);
}

function sendGoal(name: string, params: Record<string, string>): void {
  if (!METRIKA_ID || typeof window === 'undefined' || typeof window.ym !== 'function') {
    return;
  }
  window.ym(Number(METRIKA_ID), 'reachGoal', name, params);
}

export function initAnalytics(): void {
  if (initialized || typeof window === 'undefined') {
    return;
  }
  initialized = true;

  window.dataLayer = window.dataLayer || [];

  if (!METRIKA_ID || document.getElementById('yandex-metrika')) {
    return;
  }

  const script = document.createElement('script');
  script.id = 'yandex-metrika';
  script.async = true;
  script.src = `https://mc.yandex.ru/metrika/tag.js?id=${encodeURIComponent(METRIKA_ID)}`;
  // Standard queue: the tag loader must receive init even before it has loaded.
  if (!window.ym) {
    const queue = Object.assign(
      (...args: unknown[]) => { queue.a.push(args); },
      { a: [] as unknown[][], l: Date.now() },
    );
    window.ym = queue;
  }
  window.ym(Number(METRIKA_ID), 'init', {
    accurateTrackBounce: true,
    clickmap: true,
    trackLinks: true,
    webvisor: false,
    trackHash: true,
  });
  document.head.appendChild(script);
}

export function isAnalyticsEnabled(): boolean {
  return METRIKA_ID !== '';
}

export function trackEvent(name: AnalyticsEventName, params: EventParams = {}): void {
  if (typeof window === 'undefined') {
    return;
  }

  const payload = sanitizeParams({ page_path: getPagePath(), ...params });
  pushToDataLayer({ event: name, ...payload });
  sendGoal(name, payload);
}

/** Просмотр виртуальной страницы SPA. Дубли в пределах секунды отбрасываются. */
export function trackPageView(path?: string, title?: string): void {
  if (typeof window === 'undefined') {
    return;
  }

  const pagePath = path || getPagePath();
  const key = `${pagePath}|${title || ''}`;
  const now = Date.now();
  const previous = recentPageViews.get(key);

  if (previous && now - previous < 1000) {
    return;
  }
  recentPageViews.set(key, now);

  pushToDataLayer({ event: 'page_view', page_path: pagePath, page_title: title || document.title });

  if (METRIKA_ID && typeof window.ym === 'function') {
    window.ym(Number(METRIKA_ID), 'hit', pagePath, { title: title || document.title });
  }
}

export function trackPhoneClick(sectionId: string, buttonId = 'phone'): void {
  trackEvent('click_phone', { section_id: sectionId, button_id: buttonId });
}

export function trackOpenCallback(sectionId: string, buttonId = 'open_callback'): void {
  trackEvent('open_callback', { section_id: sectionId, button_id: buttonId });
}

export function trackServiceClick(sectionId: string, serviceCategory: string, buttonId?: string): void {
  trackEvent('click_service', {
    section_id: sectionId,
    service_category: serviceCategory,
    button_id: buttonId || `service_${serviceCategory}`,
  });
}

export function trackPricesClick(sectionId: string, buttonId = 'prices'): void {
  trackEvent('click_prices', { section_id: sectionId, button_id: buttonId });
}

export function trackDoctorClick(sectionId: string, buttonId = 'doctors'): void {
  trackEvent('click_doctor', { section_id: sectionId, button_id: buttonId });
}

export function trackRouteClick(sectionId: string, buttonId = 'route'): void {
  trackEvent('click_route', { section_id: sectionId, button_id: buttonId });
}

/**
 * Точка подключения мессенджера. Событие отправляется только если мессенджер
 * действительно настроен (ссылка задаётся через VITE_PUBLIC_MESSENGER_URL).
 */
export function trackMessengerClick(sectionId: string, buttonId = 'messenger'): void {
  trackEvent('click_messenger', { section_id: sectionId, button_id: buttonId });
}

export const MESSENGER_URL = (env.VITE_PUBLIC_MESSENGER_URL || '').trim();