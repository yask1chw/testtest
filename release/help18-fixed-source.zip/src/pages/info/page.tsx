import { Link } from 'react-router-dom';
import PageShell from '@/components/feature/PageShell';
import ContactsSection from '@/pages/home/components/ContactsSection';
import { clinic, doctors, requisites, serviceMenu } from '@/mocks/home';
import { priceFactors, priceGroups, type PriceGroup } from '@/mocks/prices';
import { serviceDetails } from '@/mocks/services';
import { trackServiceClick } from '@/lib/analytics';

export type InfoPageKind =
  | 'services'
  | 'prices'
  | 'doctors'
  | 'about'
  | 'reviews'
  | 'articles'
  | 'contacts';

const meta: Record<InfoPageKind, { title: string; description: string; meta: string; lead: string }> = {
  services: {
    title: 'Наркологические услуги в Ижевске',
    description: 'Помогаем пациентам при состояниях, связанных с употреблением алкоголя и психоактивных веществ. Необходимость процедур и условия лечения определяет врач.',
    meta: 'Наркологические услуги в Ижевске — направления помощи | Хелп18',
    lead: 'Восемь направлений медицинской помощи — на дому и в клинике. Выберите подходящий раздел, чтобы узнать порядок обращения, условия и стоимость.',
  },
  prices: {
    title: 'Цены на медицинские услуги',
    description: 'Прайс-лист по направлениям: вызов врача на дом, процедуры и капельницы, анализы, стационар, перевозка лежачих больных, психолог и дежурство на мероприятиях.',
    meta: 'Цены на медицинские услуги в Ижевске — прайс-лист по направлениям | Хелп18',
    lead: 'Стоимость сгруппирована по направлениям помощи. Итоговая сумма зависит от состояния пациента, объёма помощи и условий выезда и обсуждается до начала лечения.',
  },
  doctors: {
    title: 'Врачи клиники',
    description: 'Приём ведут психиатры-наркологи с подтверждённой медицинской квалификацией. Сведения о специалистах и направлениях работы.',
    meta: 'Врачи наркологической клиники в Ижевске | Хелп18',
    lead: 'Приём ведут специалисты с подтверждённой медицинской квалификацией. Сведения об образовании и сертификатах предоставляются по запросу.',
  },
  about: {
    title: 'О наркологической клинике',
    description: 'Как клиника организует помощь: принципы работы, порядок обращения и прозрачные условия лечения.',
    meta: 'О наркологической клинике в Ижевске | Хелп18',
    lead: 'Мы объясняем, как устроена помощь, до того как вы что-то решите, и не торопим с выбором.',
  },
  reviews: {
    title: 'Отзывы пациентов',
    description: 'Порядок публикации отзывов, требования к содержанию и способы поделиться обратной связью о работе клиники.',
    meta: 'Отзывы пациентов о наркологической клинике в Ижевске | Хелп18',
    lead: 'Отзывы публикуются только с согласия автора и без сведений, позволяющих идентифицировать пациента.',
  },
  articles: {
    title: 'Статьи о наркологической помощи',
    description: 'Материалы о запое, абстиненции, кодировании и лечении зависимостей. Справочный характер информации.',
    meta: 'Статьи о наркологической помощи — Ижевск | Хелп18',
    lead: 'Разбираем медицинские темы простым языком. Материалы носят справочный характер и не заменяют консультацию врача.',
  },
  contacts: {
    title: 'Как связаться с наркологической клиникой в Ижевске',
    description: 'Телефон, режим работы и порядок обращения за наркологической помощью в Ижевске.',
    meta: 'Контакты наркологической клиники в Ижевске | Хелп18',
    lead: 'Позвоните, чтобы уточнить условия обращения и возможность выезда врача.',
  },
};

const articleTopics = [
  {
    tag: 'Запой',
    title: 'Как понять, что запой опасен для здоровья',
    text: 'Какие признаки указывают на риск осложнений и почему оценка состояния должна проводиться врачом.',
  },
  {
    tag: 'Абстиненция',
    title: 'Алкогольная абстиненция: почему она возникает',
    text: 'Что происходит с организмом при отмене алкоголя и в каких случаях требуется медицинская помощь.',
  },
  {
    tag: 'Лечение',
    title: 'Как проходит первый приём у нарколога',
    text: 'Какие вопросы задаёт врач, что нужно взять с собой и как обсуждается план помощи.',
  },
  {
    tag: 'Кодирование',
    title: 'Кодирование: показания, ограничения и риски',
    text: 'Почему метод подходит не всем и как он сочетается с дальнейшим лечением зависимости.',
  },
];

const aboutPrinciples = [
  {
    title: 'Без осуждения',
    text: 'Общаемся уважительно и не используем формулировки, которые унижают пациента.',
  },
  {
    title: 'Только по показаниям',
    text: 'Назначаем процедуры, обоснованные результатами осмотра, а не «на всякий случай».',
  },
  {
    title: 'С объяснением',
    text: 'Рассказываем, что происходит, зачем нужна процедура и какие есть альтернативы.',
  },
  {
    title: 'С соблюдением тайны',
    text: 'Информация о обращении защищается законодательством о врачебной тайне.',
  },
];

const canonical: Record<InfoPageKind, string> = {
  services: '/uslugi/',
  prices: '/ceny/',
  doctors: '/vrachi/',
  about: '/o-klinike/',
  reviews: '/otzyvy/',
  articles: '/stati/',
  contacts: '/kontakty/',
};

function ServicesContent() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
      {serviceDetails.map((service) => (
        <article
          key={service.slug}
          className="rounded-lg border border-background-200 bg-background-50 p-5 hover:border-primary-300 transition-colors flex flex-col"
        >
          <h2 className="font-heading font-bold text-[15.5px] leading-snug text-foreground-950">
            {service.menuTitle}
          </h2>
          <p className="mt-2 text-[13px] leading-relaxed text-foreground-600 flex-1">{service.lead}</p>
          <Link
            to={service.slug}
            onClick={() => trackServiceClick('services_page', service.menuTitle)}
            className="mt-4 inline-flex items-center gap-1.5 text-[13px] font-medium text-primary-700 hover:text-primary-900 transition-colors"
          >
            Подробнее об услуге
            <i className="ri-arrow-right-line" aria-hidden="true" />
          </Link>
        </article>
      ))}
      <div className="sm:col-span-2 lg:col-span-3 rounded-lg bg-secondary-100 p-5">
        <p className="text-[13px] leading-relaxed text-secondary-900">
          Не уверены, какой формат помощи подходит? Позвоните по номеру {clinic.phone} — специалист
          уточнит ситуацию и расскажет о доступных вариантах обращения.
        </p>
      </div>
    </div>
  );
}

function PriceGroupCard({ group }: { group: PriceGroup }) {
  return (
    <section
      id={group.id}
      className="rounded-lg border border-background-200 bg-background-50 overflow-hidden scroll-mt-24"
    >
      <div className="flex items-start gap-3 px-4 md:px-5 py-4 bg-background-100 border-b border-background-200">
        <span className="w-9 h-9 shrink-0 rounded-md bg-background-50 flex items-center justify-center">
          <i className={`${group.icon} text-primary-700`} aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <h2 className="font-heading font-bold text-[15px] leading-snug text-foreground-950">
            {group.title}
          </h2>
          <p className="mt-0.5 text-[11.5px] leading-snug text-foreground-500">{group.hint}</p>
        </div>
      </div>
      <ul>
        {group.rows.map((row) => (
          <li
            key={row.name}
            className="grid grid-cols-1 sm:grid-cols-[1fr_auto] gap-1 sm:gap-4 px-4 md:px-5 py-3 border-t border-background-200 first:border-t-0"
          >
            <span className="text-[13.5px] leading-snug text-foreground-900">{row.name}</span>
            <span className="font-heading font-semibold text-[13.5px] text-primary-800 whitespace-nowrap">
              {row.price}
            </span>
          </li>
        ))}
      </ul>
      {group.note ? (
        <p className="px-4 md:px-5 py-3 border-t border-background-200 bg-accent-50 text-[12px] leading-relaxed text-accent-900">
          {group.note}
        </p>
      ) : null}
    </section>
  );
}

function PricesContent() {
  return (
    <div>
      <div className="flex flex-wrap gap-2">
        {priceGroups.map((group) => (
          <a
            key={group.id}
            href={`#${group.id}`}
            className="rounded-full border border-background-200 bg-background-50 px-3 py-1.5 text-[12.5px] font-medium text-foreground-700 hover:border-primary-300 hover:text-primary-800 transition-colors whitespace-nowrap cursor-pointer"
          >
            {group.title}
          </a>
        ))}
      </div>

      <div className="mt-6 grid grid-cols-1 xl:grid-cols-2 gap-4 md:gap-5 items-start">
        {priceGroups.map((group) => (
          <PriceGroupCard key={group.id} group={group} />
        ))}
      </div>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-[0.85fr_1.15fr] gap-4 md:gap-5 items-start">
        <div className="rounded-lg bg-secondary-100 p-5 md:p-6">
          <h2 className="font-heading font-bold text-[16px] text-secondary-950">
            От чего зависит стоимость
          </h2>
          <ul className="mt-3 space-y-2.5">
            {priceFactors.map((factor) => (
              <li key={factor} className="flex items-start gap-2 text-[13.5px] leading-snug text-secondary-900">
                <i className="ri-check-line text-primary-700 mt-0.5" aria-hidden="true" />
                {factor}
              </li>
            ))}
          </ul>
          <p className="mt-4 pt-4 border-t border-secondary-200 text-[12.5px] leading-relaxed text-secondary-800">
            Точную стоимость специалист называет после уточнения ситуации. Оплата — после
            согласования объёма помощи.
          </p>
        </div>

        <div className="rounded-lg border border-background-200 bg-background-50 p-5 md:p-6">
          <h2 className="font-heading font-bold text-[16px] text-foreground-950">
            Как читать прайс-лист
          </h2>
          <ul className="mt-3 space-y-2.5 text-[12.5px] leading-relaxed text-foreground-600">
            <li className="flex items-start gap-2">
              <i className="ri-information-line text-primary-600 mt-0.5" aria-hidden="true" />
              Цены указаны в рублях. Пометка «+ препарат» означает, что стоимость лекарства
              рассчитывается отдельно.
            </li>
            <li className="flex items-start gap-2">
              <i className="ri-information-line text-primary-600 mt-0.5" aria-hidden="true" />
              «Индивидуальный расчёт» — стоимость зависит от объёма помощи и согласуется
              со специалистом.
            </li>
            <li className="flex items-start gap-2">
              <i className="ri-information-line text-primary-600 mt-0.5" aria-hidden="true" />
              Прайс-лист является ориентировочным и не является публичной офертой. Актуальные
              цены уточняйте по телефону.
            </li>
          </ul>
          <p className="mt-4 text-[12.5px] leading-relaxed text-foreground-500">
            Полные условия оказания платных услуг — в разделе{' '}
            <Link to="/platnye-uslugi/" className="text-primary-700 underline">
              информация о платных медицинских услугах
            </Link>
            .
          </p>
        </div>
      </div>
    </div>
  );
}

function DoctorsContent() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
      {doctors.map((doctor) => (
        <article
          key={doctor.name}
          className="bg-background-50 border border-background-200 rounded-lg overflow-hidden"
        >
          <div className="w-full h-[260px] md:h-[300px] bg-background-200 overflow-hidden">
            <img
              src={doctor.photo}
              alt={`${doctor.name} — ${doctor.role}`}
              title={`${doctor.name} — ${doctor.focus}`}
              width={600}
              height={700}
              loading="lazy"
              decoding="async"
              className="w-full h-full object-cover object-top"
            />
          </div>
          <div className="p-4 md:p-5">
            <h2 className="font-heading font-bold text-[15.5px] leading-snug text-foreground-950">
              {doctor.name}
            </h2>
            <p className="mt-1 text-[13px] text-primary-800">{doctor.role}</p>
            <p className="mt-3 text-[12.5px] leading-relaxed text-foreground-600">{doctor.focus}</p>
            <p className="mt-3 pt-3 border-t border-background-200 text-[12px] text-foreground-500">
              {doctor.experience}
            </p>
          </div>
        </article>
      ))}
      <p className="sm:col-span-2 lg:col-span-3 text-[12.5px] leading-relaxed text-foreground-600">
        Сведения об образовании и сертификатах специалистов предоставляются по запросу.
        Направления работы указаны справочно и уточняются при обращении.
      </p>
    </div>
  );
}

function AboutContent() {
  return (
    <div className="max-w-3xl space-y-8">
      <section>
        <h2 className="font-heading font-bold text-[19px] md:text-[22px] text-foreground-950">
          Как мы работаем
        </h2>
        <div className="mt-3 space-y-2.5 text-[14px] leading-relaxed text-foreground-700">
          <p>
            Клиника оказывает наркологическую помощь жителям Ижевска: консультации
            психиатра-нарколога, помощь при запое и интоксикации, кодирование, лечение зависимостей
            и наблюдение в стационаре.
          </p>
          <p>
            Мы не обещаем «мгновенного избавления» и не назначаем процедуры без осмотра. Формат
            помощи определяется состоянием пациента и медицинскими показаниями, а медицинское
            вмешательство проводится при информированном добровольном согласии.
          </p>
        </div>
      </section>

      <section>
        <h2 className="font-heading font-bold text-[19px] md:text-[22px] text-foreground-950">
          Принципы работы
        </h2>
        <div className="mt-3.5 grid grid-cols-1 sm:grid-cols-2 gap-3">
          {aboutPrinciples.map((item) => (
            <div key={item.title} className="rounded-lg border border-background-200 bg-background-50 p-4">
              <h3 className="font-heading font-semibold text-[14px] text-foreground-950">{item.title}</h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-foreground-600">{item.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="rounded-lg border border-background-200 bg-background-50 p-5">
        <h2 className="font-heading font-bold text-[16px] text-foreground-950">
          Сведения об организации
        </h2>
        <dl className="mt-3 space-y-2 text-[13px] text-foreground-700">
          <div className="flex flex-wrap gap-x-2">
            <dt className="text-foreground-500">Наименование:</dt>
            <dd>{requisites.legalName}</dd>
          </div>
          <div className="flex flex-wrap gap-x-2">
            <dt className="text-foreground-500">Телефон:</dt>
            <dd>{clinic.phone}</dd>
          </div>
        </dl>
      </section>
    </div>
  );
}

function ReviewsContent() {
  return (
    <div className="max-w-3xl space-y-6">
      <div className="rounded-lg border border-background-200 bg-background-50 p-5 md:p-6">
        <h2 className="font-heading font-bold text-[18px] text-foreground-950">
          Как публикуются отзывы
        </h2>
        <ul className="mt-3 space-y-2.5 text-[13.5px] leading-relaxed text-foreground-700">
          <li className="flex items-start gap-2">
            <i className="ri-check-line text-primary-700 mt-0.5" aria-hidden="true" />
            Отзыв публикуется только с согласия автора.
          </li>
          <li className="flex items-start gap-2">
            <i className="ri-check-line text-primary-700 mt-0.5" aria-hidden="true" />
            Мы не размещаем сведения, позволяющие идентифицировать пациента.
          </li>
          <li className="flex items-start gap-2">
            <i className="ri-check-line text-primary-700 mt-0.5" aria-hidden="true" />
            Отзывы о лечении не используются как рекламное обещание результата.
          </li>
        </ul>
      </div>

      <div className="rounded-lg border border-accent-300 bg-accent-50 px-4 py-3.5">
        <p className="flex items-start gap-2 text-[12.5px] leading-relaxed text-accent-900">
          <i className="ri-information-line mt-0.5" aria-hidden="true" />
          Раздел готов к публикации отзывов, но тексты не размещены: отзывы добавляются только после
          получения согласия пациентов. Выдуманные отзывы на сайте не публикуются.
        </p>
      </div>

      <div className="rounded-lg border border-background-200 bg-background-50 p-5 md:p-6">
        <h2 className="font-heading font-bold text-[18px] text-foreground-950">
          Как оставить обратную связь
        </h2>
        <p className="mt-2 text-[13.5px] leading-relaxed text-foreground-600">
          Позвоните по номеру {clinic.phone}. Если вы хотите, чтобы
          отзыв был опубликован, сообщите об этом — мы согласуем текст и получим письменное согласие.
        </p>
        <a
          href={clinic.phoneHref}
          className="mt-4 inline-flex items-center gap-2 h-11 px-5 rounded-md bg-primary-600 text-background-50 text-[14px] font-medium hover:bg-primary-700 transition-colors whitespace-nowrap"
        >
          <i className="ri-phone-line" aria-hidden="true" />
          Позвонить в клинику
        </a>
      </div>
    </div>
  );
}

function ArticlesContent() {
  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-5">
        {articleTopics.map((article) => (
          <article
            key={article.title}
            className="rounded-lg border border-background-200 bg-background-50 p-5"
          >
            <span className="inline-flex items-center rounded-full bg-secondary-100 px-2.5 py-1 text-[11.5px] font-medium text-secondary-900">
              {article.tag}
            </span>
            <h2 className="mt-3 font-heading font-bold text-[15.5px] leading-snug text-foreground-950">
              {article.title}
            </h2>
            <p className="mt-2 text-[13px] leading-relaxed text-foreground-600">{article.text}</p>
            <p className="mt-3 text-[11.5px] text-foreground-500">Материал готовится к публикации</p>
          </article>
        ))}
      </div>
      <p className="mt-5 text-[12.5px] leading-relaxed text-foreground-500 max-w-2xl">
        Статьи носят справочный характер, не содержат персональных схем лечения и не заменяют
        консультацию врача. Перед публикацией медицинские тексты согласуются со специалистом клиники.
      </p>
    </div>
  );
}

function ContactsContent() {
  return (
    <div>
      <ContactsSection />
      <div className="mt-2 rounded-lg border border-background-200 bg-background-50 p-5">
        <h2 className="font-heading font-bold text-[16px] text-foreground-950">Реквизиты</h2>
        <dl className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 text-[13px] text-foreground-700">
          <div>
            <dt className="text-foreground-500 text-[11.5px]">Наименование</dt>
            <dd>{requisites.legalName}</dd>
          </div>
          <div>
            <dt className="text-foreground-500 text-[11.5px]">ИНН / ОГРН</dt>
            <dd>
              {requisites.inn} / {requisites.ogrn}
            </dd>
          </div>
        </dl>
      </div>
    </div>
  );
}

export default function InfoPage({ kind }: { kind: InfoPageKind }) {
  const data = meta[kind];

  return (
    <PageShell
      title={data.title}
      description={data.lead}
      metaTitle={data.meta}
      metaDescription={data.description}
      canonicalPath={canonical[kind]}
      breadcrumbs={[{ label: 'Главная', href: '/' }, { label: data.title }]}
    >
      {kind === 'services' && <ServicesContent />}
      {kind === 'prices' && <PricesContent />}
      {kind === 'doctors' && <DoctorsContent />}
      {kind === 'about' && <AboutContent />}
      {kind === 'reviews' && <ReviewsContent />}
      {kind === 'articles' && <ArticlesContent />}
      {kind === 'contacts' && <ContactsContent />}
    </PageShell>
  );
}
