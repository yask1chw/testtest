import { Link } from 'react-router-dom';
import SiteHeader from '@/components/feature/SiteHeader';
import SiteFooter from '@/components/feature/SiteFooter';
import MobileActionBar from '@/components/feature/MobileActionBar';
import { clinic, serviceMenu } from '@/mocks/home';
import useDocumentMeta from '@/hooks/useDocumentMeta';

/**
 * Страница 404. SPA отдаёт её на неизвестные маршруты клиентским роутером.
 * Чтобы поисковые системы получали реальный HTTP-статус 404, на хостинге
 * нужна настройка отдачи кода 404 для неизвестных адресов.
 */
export default function NotFound() {
  useDocumentMeta({
    title: 'Страница не найдена | Хелп18 Ижевск',
    description:
      'Запрошенная страница не найдена. Вернитесь на главную страницу или выберите нужную услугу наркологической клиники в Ижевске.',
    noindex: true,
  });

  return (
    <div className="min-h-screen bg-background-50 flex flex-col pb-[76px] lg:pb-0">
      <a href="#main-content" className="skip-link">
        Перейти к основному содержанию
      </a>
      <SiteHeader />
      <main id="main-content" tabIndex={-1} className="flex-1">
        <div className="max-w-content mx-auto px-4 md:px-6 py-14 md:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-[1.05fr_0.95fr] gap-8 lg:gap-12 items-start">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full bg-background-200 px-3.5 py-1.5 text-[12.5px] font-medium text-foreground-800">
                <i className="ri-error-warning-line" aria-hidden="true" />
                Ошибка 404
              </span>
              <h1 className="mt-5 font-heading font-extrabold text-[27px] md:text-[38px] leading-[1.14] text-foreground-950">
                Страница не найдена
              </h1>
              <p className="mt-4 text-[15px] md:text-[16px] leading-relaxed text-foreground-600 max-w-xl">
                Возможно, адрес изменился или страница была удалена. Вы можете вернуться на главную
                страницу или выбрать необходимую услугу.
              </p>

              <div className="mt-7 flex flex-col sm:flex-row gap-3">
                <Link
                  to="/"
                  className="h-12 px-6 rounded-md bg-primary-600 text-background-50 text-[15px] font-medium flex items-center justify-center gap-2 hover:bg-primary-700 transition-colors whitespace-nowrap"
                >
                  <i className="ri-home-4-line text-lg" aria-hidden="true" />
                  На главную
                </Link>
                <Link
                  to="/uslugi/"
                  className="h-12 px-6 rounded-md border border-primary-300 text-primary-800 text-[15px] font-medium flex items-center justify-center gap-2 hover:bg-primary-50 transition-colors whitespace-nowrap"
                >
                  Посмотреть услуги
                </Link>
              </div>

              <div className="mt-8 rounded-lg border border-background-200 bg-background-100 p-5">
                <p className="text-[13px] leading-relaxed text-foreground-700">
                  Если нужна медицинская помощь, позвоните по номеру{' '}
                  <a
                    href={clinic.phoneHref}
                    className="font-heading font-bold text-primary-800 hover:text-primary-900 whitespace-nowrap"
                  >
                    {clinic.phone}
                  </a>
                  . Специалист уточнит ситуацию и расскажет об условиях обращения.
                </p>
              </div>
            </div>

            <div className="rounded-lg border border-background-200 bg-background-50 p-5 md:p-6">
              <h2 className="font-heading font-bold text-[15px] text-foreground-950">
                Популярные направления
              </h2>
              <div className="mt-4 space-y-1">
                {serviceMenu.slice(0, 6).map((item) => (
                  <Link
                    key={item.href}
                    to={item.href}
                    className="flex items-center justify-between gap-3 px-3 py-2.5 rounded-md text-[13.5px] text-foreground-800 hover:bg-primary-50 transition-colors"
                  >
                    <span className="flex items-center gap-2.5">
                      <i className={`${item.icon} text-primary-600`} aria-hidden="true" />
                      {item.title}
                    </span>
                    <i className="ri-arrow-right-line text-foreground-400" aria-hidden="true" />
                  </Link>
                ))}
              </div>
              <div className="mt-4 pt-4 border-t border-background-200 flex flex-wrap gap-x-4 gap-y-2 text-[12.5px]">
                <Link to="/ceny/" className="text-primary-700 hover:text-primary-900">
                  Цены
                </Link>
                <Link to="/vrachi/" className="text-primary-700 hover:text-primary-900">
                  Врачи
                </Link>
                <Link to="/kontakty/" className="text-primary-700 hover:text-primary-900">
                  Контакты
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>
      <SiteFooter />
      <MobileActionBar />
    </div>
  );
}