import type { ReactNode } from 'react';

interface LegalSectionProps {
  title: string;
  id?: string;
  children: ReactNode;
}

export default function LegalSection({ title, id, children }: LegalSectionProps) {
  return (
    <section id={id} className="scroll-mt-28">
      <h2 className="font-heading font-bold text-[18px] md:text-[21px] leading-snug text-foreground-950">
        {title}
      </h2>
      <div className="mt-2.5 space-y-2.5 text-[14px] leading-relaxed text-foreground-700">
        {children}
      </div>
    </section>
  );
}