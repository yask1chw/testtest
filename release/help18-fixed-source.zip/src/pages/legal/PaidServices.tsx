import { Link } from 'react-router-dom';
import PageShell from '@/components/feature/PageShell';
import LegalSection from '@/pages/legal/components/LegalSection';
import { clinic, requisites } from '@/mocks/home';
import { priceGroups } from '@/mocks/prices';

export default function PaidServices() {
  return (
    <PageShell
      title="Информация о платных медицинских услугах"
      eyebrow="Документы"
      description="Порядок оказания платной медицинской помощи, состав сведений об услугах, правила оплаты и ответственность сторон."
      breadcrumbs={[
        { label: 'Главная', href: '/' },
        { label: 'Информация о платных медицинских услугах' },
      ]}
      metaTitle="Платные медицинские услуги — порядок и условия | Хелп18 Ижевск"
      metaDescription="Порядок оказания платных медицинских услуг в наркологической клинике в Ижевске: перечень сведений, договор, стоимость, оплата и права пациента."
      canonicalPath="/platnye-uslugi/"
    >
      <div className="max-w-3xl">
        <div className="rounded-lg border border-accent-300 bg-accent-50 px-4 py-3.5">
          <p className="flex items-start gap-2 text-[12.5px] leading-relaxed text-accent-900">
            <i className="ri-draft-line mt-0.5" aria-hidden="true" />
            Шаблон страницы. Итоговый текст утверждается медицинской организацией в соответствии
            с действующими правилами предоставления платных медицинских услуг. Цены ниже —
            демонстрационные.
          </p>
        </div>

        <div className="mt-8 space-y-7">
          <LegalSection title="1. Общие положения">
            <p>
              Медицинская организация {requisites.legalName} оказывает платные медицинские услуги.
              Услуги предоставляются по предварительному согласованию объёма помощи и после
              оформления необходимых документов.
            </p>
          </LegalSection>

          <LegalSection title="2. Сведения об исполнителе">
            <ul className="list-disc pl-5 space-y-1.5">
              <li>наименование: {requisites.legalName};</li>
              <li>телефон: {clinic.phone}.</li>
            </ul>
          </LegalSection>

          <LegalSection title="3. Порядок обращения и заключения договора">
            <p>
              Обращение поступает по телефону или через форму на сайте. Специалист уточняет
              ситуацию, объясняет возможные форматы помощи и порядок оформления. Платные услуги
              оказываются на основании договора, который заключается в письменной форме;
              пациенту предоставляется информация о составе услуги, стоимости и порядке оплаты
              до её оказания.
            </p>
          </LegalSection>

          <LegalSection title="4. Стоимость услуг">
            <p>
              Стоимость определяется действующим прайс-листом клиники. Итоговая сумма зависит от
              состояния пациента, объёма медицинской помощи и условий выезда. Ориентировочные
              цены основных услуг сгруппированы по направлениям; полный прайс-лист с составом
              процедур размещён в разделе цен.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {priceGroups.map((group) => (
                <div
                  key={group.id}
                  className="rounded-md border border-background-200 bg-background-50 px-4 py-3 flex items-start justify-between gap-3"
                >
                  <span className="text-[13px] leading-snug text-foreground-900 min-w-0">
                    {group.title}
                  </span>
                  <span className="font-heading font-semibold text-[13px] text-primary-800 whitespace-nowrap">
                    {group.fromPrice}
                  </span>
                </div>
              ))}
            </div>
            <Link
              to="/ceny/"
              className="inline-flex items-center gap-1.5 text-[13.5px] font-medium text-primary-700 hover:text-primary-900 transition-colors"
            >
              Перейти к странице цен
              <i className="ri-arrow-right-line" aria-hidden="true" />
            </Link>
          </LegalSection>

          <LegalSection title="5. Оплата">
            <p>
              Оплата производится в порядке, согласованном при оформлении услуги. Документ об
              оплате предоставляется пациенту. Объём медицинской помощи и её стоимость
              согласуются до начала лечения и не меняются в процессе его проведения без
              согласования с пациентом.
            </p>
          </LegalSection>

          <LegalSection title="6. Права и обязанности пациента">
            <p>
              Пациент вправе получить информацию о медицинской организации, специалистах,
              услугах, их стоимости и условиях оказания, а также отказаться от медицинского
              вмешательства с разъяснением возможных последствий. Медицинское вмешательство
              проводится при информированном добровольном согласии, кроме случаев,
              предусмотренных законодательством.
            </p>
          </LegalSection>

          <LegalSection title="7. Ограничения">
            <p>
              Возможность оказания помощи на дому определяется состоянием пациента и медицинскими
              показаниями. При наличии противопоказаний врач может рекомендовать наблюдение и
              лечение в стационаре либо отказаться от проведения процедуры на дому.
            </p>
          </LegalSection>

          <LegalSection title="8. Обращения и претензии">
            <p>
              Обращения по вопросам оказания услуг принимаются по телефону {clinic.phone}.
              Порядок рассмотрения обращений соответствует требованиям
              законодательства о защите прав потребителей и об охране здоровья граждан.
            </p>
          </LegalSection>
        </div>
      </div>
    </PageShell>
  );
}