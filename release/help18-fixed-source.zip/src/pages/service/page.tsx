import { Link } from 'react-router-dom';
import PageShell from '@/components/feature/PageShell';
import { serviceDetails } from '@/mocks/services';
import { clinic } from '@/mocks/home';
import { useRequestModal } from '@/hooks/useRequestModal';
import { trackPhoneClick, trackPricesClick, trackServiceClick } from '@/lib/analytics';

export default function ServicePage({ slug }: { slug: string }) {
  const service = serviceDetails.find((item) => item.slug === slug);
  const { openRequest } = useRequestModal();

  if (!service) {
    return null;
  }

  return (
    <PageShell
      title={service.h1}
      eyebrow="Услуга"
      description={service.lead}
      breadcrumbs={[
        { label: 'Главная', href: '/' },
        { label: 'Услуги', href: '/uslugi/' },
        { label: service.menuTitle },
      ]}
      metaTitle={service.metaTitle}
      metaDescription={service.metaDescription}
      canonicalPath={service.slug}
    >
      <div className="grid grid-cols-1 lg:grid-cols-[1.15fr_0.85fr] gap-8 lg:gap-10 items-start">
        <div className="space-y-8">
          <section>
            <h2 className="font-heading font-bold text-[19px] md:text-[22px] text-foreground-950">
              Когда стоит обратиться
            </h2>
            <ul className="mt-3.5 space-y-2.5">
              {service.indications.map((item) => (
                <li key={item} className="flex items-start gap-2.5 text-[14px] leading-relaxed text-foreground-700">
                  <i className="ri-check-line text-primary-700 mt-0.5" aria-hidden="true" />
                  {item}
                </li>
              ))}
            </ul>
            <p className="mt-4 text-[12.5px] leading-relaxed text-foreground-500">
              Перечень не является диагностическим критерием. Необходимость помощи определяет врач
              после осмотра.
            </p>
          </section>

          <section className="rounded-lg border border-background-200 bg-background-50 p-5 md:p-6">
            <h2 className="font-heading font-bold text-[19px] md:text-[22px] text-foreground-950">
              Что входит в помощь
            </h2>
            <ul className="mt-3.5 space-y-2.5">
              {service.includes.map((item) => (
                <li key={item} className="flex items-start gap-2.5 text-[14px] leading-relaxed text-foreground-700">
                  <i className="ri-check-double-line text-primary-700 mt-0.5" aria-hidden="true" />
                  {item}
                </li>
              ))}
            </ul>
          </section>

          <section>
            <h2 className="font-heading font-bold text-[19px] md:text-[22px] text-foreground-950">
              Как проходит обращение
            </h2>
            <div className="mt-4 space-y-3">
              {service.process.map((step, index) => (
                <div
                  key={step.title}
                  className="flex items-start gap-3 rounded-lg border border-background-200 bg-background-50 p-4"
                >
                  <span className="w-8 h-8 shrink-0 rounded-full bg-primary-50 text-primary-800 font-heading font-bold text-[13px] flex items-center justify-center">
                    {index + 1}
                  </span>
                  <div>
                    <h3 className="font-heading font-semibold text-[14.5px] text-foreground-950">
                      {step.title}
                    </h3>
                    <p className="mt-1 text-[13px] leading-relaxed text-foreground-600">{step.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <div className="rounded-lg border border-accent-300 bg-accent-50 px-4 py-3.5">
            <p className="flex items-start gap-2 text-[12.5px] leading-relaxed text-accent-900">
              <i className="ri-alert-line mt-0.5" aria-hidden="true" />
              {service.note}
            </p>
          </div>

          <section>
            <h2 className="font-heading font-bold text-[19px] md:text-[22px] text-foreground-950">
              Связанные разделы
            </h2>
            <div className="mt-3.5 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {service.related.map((link) => (
                <Link
                  key={link.href}
                  to={link.href}
                  onClick={() => trackServiceClick('service_page_related', link.label)}
                  className="flex items-center justify-between gap-3 px-4 py-3 rounded-md border border-background-200 bg-background-50 text-[13.5px] text-foreground-900 hover:border-primary-300 hover:bg-primary-50 transition-colors"
                >
                  {link.label}
                  <i className="ri-arrow-right-line text-foreground-400" aria-hidden="true" />
                </Link>
              ))}
            </div>
          </section>
        </div>

        <aside className="lg:sticky lg:top-24 space-y-4">
          <div className="rounded-lg border border-background-200 bg-background-50 p-5">
            <h2 className="font-heading font-bold text-[16px] text-foreground-950">
              Ориентировочная стоимость
            </h2>
            <ul className="mt-3 space-y-2.5">
              {service.prices.map((row) => (
                <li
                  key={row.name}
                  className="flex items-start justify-between gap-3 text-[13px] leading-snug text-foreground-700"
                >
                  <span>{row.name}</span>
                  <span className="font-heading font-semibold text-primary-800 whitespace-nowrap">
                    {row.price}
                  </span>
                </li>
              ))}
            </ul>
            <p className="mt-3 pt-3 border-t border-background-200 text-[11.5px] leading-relaxed text-foreground-500">
              Цены ориентировочные. Итоговая стоимость согласуется после уточнения ситуации
              и осмотра врача.
            </p>
            <Link
              to="/ceny/"
              onClick={() => trackPricesClick('service_page', 'service_prices_link')}
              className="mt-2 inline-flex items-center gap-1.5 text-[12.5px] font-medium text-primary-700 hover:text-primary-900 transition-colors"
            >
              Полный прайс-лист
              <i className="ri-arrow-right-line" aria-hidden="true" />
            </Link>
          </div>

          <div className="rounded-lg bg-primary-600 p-5">
            <h2 className="font-heading font-bold text-[16px] text-background-50">
              Нужна консультация?
            </h2>
            <p className="mt-1.5 text-[12.5px] leading-relaxed text-primary-100">
              Специалист уточнит ситуацию и расскажет о возможных вариантах помощи.
            </p>
            <a
              href={clinic.phoneHref}
              onClick={() => trackPhoneClick('service_page', 'service_phone')}
              className="mt-4 flex items-center justify-center gap-2 h-11 rounded-md bg-background-50 text-primary-900 text-[14.5px] font-medium hover:bg-primary-50 transition-colors whitespace-nowrap"
            >
              <i className="ri-phone-line" aria-hidden="true" />
              {clinic.phone}
            </a>
            <button
              type="button"
              onClick={() => openRequest('service_page')}
              className="mt-2.5 w-full h-11 rounded-md border border-primary-300 text-background-50 text-[14px] font-medium flex items-center justify-center gap-2 hover:bg-primary-700 transition-colors whitespace-nowrap cursor-pointer"
            >
              <i className="ri-send-plane-line" aria-hidden="true" />
              Оставить заявку
            </button>
            <p className="mt-3 text-[11px] leading-relaxed text-primary-200">
              Помощь оказывается по медицинским показаниям и при добровольном согласии пациента.
            </p>
          </div>
        </aside>
      </div>
    </PageShell>
  );
}