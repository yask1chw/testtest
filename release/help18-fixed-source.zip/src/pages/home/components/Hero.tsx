import { clinic } from '@/mocks/home';
import { useRequestModal } from '@/hooks/useRequestModal';
import { trackPhoneClick, trackPricesClick } from '@/lib/analytics';

const advantages = [
  'Возможность вызова нарколога на дом',
  'Консультации и лечение в клинике',
  'Медицинская помощь по показаниям',
];

export default function Hero() {
  const { openRequest } = useRequestModal();

  return (
    <section className="relative overflow-hidden bg-background-50">
      <div
        className="pointer-events-none absolute -top-40 -left-32 w-[520px] h-[520px] rounded-full bg-primary-100/70 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute top-24 right-0 w-[420px] h-[420px] rounded-full bg-accent-100/60 blur-3xl"
        aria-hidden="true"
      />

      <div className="relative max-w-content mx-auto px-4 md:px-6 py-10 md:py-16 lg:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-[1.05fr_0.95fr] gap-10 lg:gap-14 items-center">
          <div className="animate-fade-up min-w-0">
            <span className="inline-flex items-center gap-2 rounded-full bg-secondary-100 px-3.5 py-1.5 text-[12.5px] font-medium text-secondary-900">
              <i className="ri-stethoscope-line" aria-hidden="true" />
              Наркологическая помощь в Ижевске
            </span>

            <h1 className="mt-5 font-heading font-extrabold text-[29px] sm:text-[36px] lg:text-[46px] leading-[1.14] text-foreground-950">
              Наркологическая помощь в Ижевске — на дому и в клинике
            </h1>

            <p className="mt-5 text-[16px] md:text-[17px] leading-relaxed text-foreground-700 max-w-xl">
              Вызов врача-нарколога, вывод из запоя, помощь при алкогольной интоксикации,
              кодирование и лечение зависимостей. Врач оценит состояние пациента и определит
              подходящий формат медицинской помощи.
            </p>

            <div className="mt-7 flex flex-col sm:flex-row gap-3">
              <button
                type="button"
                onClick={() => openRequest('hero')}
                className="h-12 px-6 rounded-md bg-primary-600 text-background-50 text-[15.5px] font-medium flex items-center justify-center gap-2 hover:bg-primary-700 transition-colors whitespace-nowrap cursor-pointer"
              >
                <i className="ri-phone-line text-lg" aria-hidden="true" />
                Вызвать нарколога
              </button>
              <a
                href="#ceny"
                onClick={() => trackPricesClick('hero', 'hero_prices')}
                className="h-12 px-6 rounded-md border border-primary-300 bg-background-50 text-primary-800 text-[15.5px] font-medium flex items-center justify-center gap-2 hover:bg-primary-50 transition-colors whitespace-nowrap cursor-pointer"
              >
                Узнать стоимость
              </a>
            </div>

            <ul className="mt-6 space-y-2">
              {advantages.map((item) => (
                <li
                  key={item}
                  className="flex items-start gap-2 text-[13.5px] leading-snug text-foreground-700"
                >
                  <i
                    className="ri-checkbox-circle-line text-primary-600 text-base mt-0.5 shrink-0"
                    aria-hidden="true"
                  />
                  {item}
                </li>
              ))}
            </ul>

            <p className="mt-5 text-[12.5px] leading-relaxed text-foreground-500 max-w-lg">
              Возможность оказания помощи на дому определяется состоянием пациента
              и медицинскими показаниями.
            </p>

            <a
              href={clinic.phoneHref}
              onClick={() => trackPhoneClick('hero', 'hero_phone')}
              className="mt-4 inline-flex items-center gap-2 text-[13.5px] font-medium text-primary-800 hover:text-primary-900 transition-colors whitespace-nowrap"
            >
              <i className="ri-phone-line" aria-hidden="true" />
              {clinic.phone}
              <span className="font-normal text-foreground-500">— круглосуточно</span>
            </a>
          </div>

          <div className="animate-fade-up relative min-w-0">
            <div className="relative w-full h-[300px] sm:h-[420px] lg:h-[520px] rounded-lg overflow-hidden bg-background-200">
              <img
                src="https://readdy.ai/api/search-image?query=Calm%20medical%20scene%20of%20a%20doctor%20in%20a%20white%20coat%20with%20a%20medical%20bag%20standing%20in%20a%20bright%20neutral%20apartment%20hallway%2C%20soft%20muted%20teal%20and%20warm%20beige%20tones%2C%20natural%20daylight%20from%20a%20window%2C%20clean%20minimal%20editorial%20photography%2C%20professional%20and%20reassuring%20atmosphere%2C%20shallow%20depth%20of%20field&width=900&height=1100&seq=hero-narkolog-home-01&orientation=portrait"
                alt="Врач-нарколог приезжает на дом к пациенту в Ижевске"
                title="Вызов нарколога на дом в Ижевске"
                className="w-full h-full object-cover object-top"
              />
              <div
                className="absolute inset-0 bg-gradient-to-t from-foreground-950/45 via-foreground-950/5 to-transparent"
                aria-hidden="true"
              />
              <div className="absolute left-4 right-4 bottom-4 rounded-md bg-background-50/95 backdrop-blur-sm p-4">
                <p className="flex items-start gap-2.5 text-[13px] leading-snug text-foreground-800">
                  <i
                    className="ri-stethoscope-line text-primary-600 text-lg mt-0.5"
                    aria-hidden="true"
                  />
                  Врач оценит состояние пациента и определит необходимый объём медицинской помощи.
                </p>
              </div>
            </div>

            <div className="absolute -top-3 right-3 md:right-5 rounded-md bg-background-50 border border-background-200 px-3.5 py-2.5">
              <span className="block text-[11px] uppercase tracking-wide text-foreground-500">
                Формат помощи
              </span>
              <span className="block font-heading font-bold text-[14.5px] text-foreground-950">
                Дом или стационар
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}