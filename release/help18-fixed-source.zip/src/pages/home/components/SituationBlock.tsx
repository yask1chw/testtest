import { Link } from 'react-router-dom';
import { situations } from '@/mocks/home';
import { useRequestModal } from '@/hooks/useRequestModal';
import { trackServiceClick } from '@/lib/analytics';

export default function SituationBlock() {
  const { openRequest } = useRequestModal();

  return (
    <section className="bg-background-50 py-14 md:py-20">
      <div className="max-w-content mx-auto px-4 md:px-6">
        <div className="max-w-3xl">
          <span className="inline-flex items-center gap-2 text-[12.5px] font-medium uppercase tracking-[0.16em] text-primary-700">
            <span className="w-6 h-px bg-primary-400" aria-hidden="true" />
            Когда нужен врач
          </span>
          <h2 className="mt-3 font-heading font-extrabold text-[26px] md:text-[34px] leading-[1.16] text-foreground-950">
            В каких ситуациях стоит обратиться к наркологу?
          </h2>
          <p className="mt-3 text-[15px] md:text-[16px] leading-relaxed text-foreground-600">
            При длительном употреблении алкоголя, ухудшении самочувствия и признаках зависимости
            важно своевременно получить профессиональную медицинскую оценку.
          </p>
        </div>

        <div className="mt-8 md:mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
          {situations.map((item, index) => (
            <div
              key={item.title}
              className="flex flex-col rounded-lg border border-background-200 bg-background-50 p-4 md:p-5 hover:border-primary-300 transition-colors"
            >
              <div className="flex items-center justify-between">
                <span className="w-10 h-10 rounded-md bg-accent-100 flex items-center justify-center">
                  <i className={`${item.icon} text-accent-800 text-lg`} aria-hidden="true" />
                </span>
                <span className="font-heading text-[12px] font-semibold text-background-400">
                  0{index + 1}
                </span>
              </div>
              <h3 className="mt-4 font-heading font-bold text-[15px] leading-snug text-foreground-950">
                {item.title}
              </h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-foreground-600 flex-1">
                {item.description}
              </p>
              <Link
                to={item.href}
                onClick={() => trackServiceClick('situations', item.title)}
                className="mt-3 inline-flex items-center gap-1.5 text-[12.5px] font-medium text-primary-700 hover:text-primary-800 transition-colors"
              >
                {item.linkLabel}
                <i className="ri-arrow-right-line" aria-hidden="true" />
              </Link>
            </div>
          ))}
        </div>

        <div className="mt-8 rounded-lg bg-primary-900 px-5 py-6 md:px-8 md:py-7 flex flex-col md:flex-row md:items-center gap-4 md:gap-8">
          <div className="min-w-0 flex-1">
            <h3 className="font-heading font-bold text-[17px] md:text-[19px] text-background-50">
              Получить консультацию нарколога
            </h3>
            <p className="mt-1.5 text-[13px] leading-relaxed text-primary-100">
              Специалист уточнит ситуацию и расскажет о возможных вариантах обращения
              за медицинской помощью.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 shrink-0">
            <button
              type="button"
              onClick={() => openRequest('situations')}
              className="h-12 px-5 rounded-md bg-background-50 text-primary-900 text-[14px] font-medium flex items-center justify-center gap-2 hover:bg-primary-50 transition-colors whitespace-nowrap cursor-pointer"
            >
              <i className="ri-send-plane-line" aria-hidden="true" />
              Оставить заявку
            </button>
            <Link
              to="/konsultaciya-narkologa/"
              className="h-12 px-5 rounded-md border border-primary-300/60 text-background-50 text-[14px] font-medium flex items-center justify-center gap-2 hover:bg-primary-800 transition-colors whitespace-nowrap"
            >
              О консультации
            </Link>
          </div>
        </div>

        <p className="mt-4 text-[12px] leading-relaxed text-foreground-500 max-w-3xl">
          Информация на странице носит справочный характер и не заменяет консультацию врача.
          Решение о лечении принимается добровольно: медицинское вмешательство проводится только
          с информированного согласия пациента в соответствии с законодательством.
        </p>
      </div>
    </section>
  );
}