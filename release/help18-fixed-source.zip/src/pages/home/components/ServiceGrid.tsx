import { Link } from 'react-router-dom';
import SectionHeading from '@/components/base/SectionHeading';
import { services } from '@/mocks/home';
import { trackPricesClick, trackServiceClick } from '@/lib/analytics';

export default function ServiceGrid() {
  return (
    <section id="uslugi" className="bg-background-100 py-14 md:py-20">
      <div className="max-w-content mx-auto px-4 md:px-6">
        <SectionHeading
          eyebrow="Направления помощи"
          title="Наркологические услуги в Ижевске"
          description="Помогаем пациентам при состояниях, связанных с употреблением алкоголя и психоактивных веществ. Доступны консультации специалистов и различные форматы медицинской помощи. Необходимость процедур и условия лечения определяются врачом."
          action={
            <Link
              to="/ceny/"
              onClick={() => trackPricesClick('services_grid', 'services_all_prices')}
              className="inline-flex items-center gap-2 text-[14px] font-medium text-primary-700 hover:text-primary-800 transition-colors whitespace-nowrap"
            >
              Смотреть все цены
              <i className="ri-arrow-right-line" aria-hidden="true" />
            </Link>
          }
        />

        <div className="mt-8 md:mt-10 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 md:gap-4">
          {services.map((service) => (
            <Link
              key={service.href}
              to={service.href}
              onClick={() => trackServiceClick('services_grid', service.title)}
              className="group flex flex-col bg-background-50 border border-background-200 rounded-lg p-4 md:p-5 hover:border-primary-300 hover:bg-primary-50/40 transition-colors"
            >
              <div className="flex items-start justify-between gap-2">
                <span className="w-11 h-11 rounded-md bg-primary-50 flex items-center justify-center group-hover:bg-primary-100 transition-colors">
                  <i className={`${service.icon} text-primary-700 text-xl`} aria-hidden="true" />
                </span>
                {service.priority && (
                  <span className="shrink-0 rounded-full bg-accent-100 px-2.5 py-1 text-[10.5px] font-medium uppercase tracking-wide text-accent-900">
                    Основное
                  </span>
                )}
              </div>
              <h3 className="mt-4 font-heading font-bold text-[15.5px] leading-snug text-foreground-950 group-hover:text-primary-900 transition-colors">
                {service.title}
              </h3>
              <p className="mt-2 text-[12.5px] leading-relaxed text-foreground-600 flex-1">
                {service.description}
              </p>
              <span className="mt-4 flex items-center justify-between gap-2 pt-3 border-t border-background-200 text-[12.5px] font-medium text-primary-700">
                <span>{service.linkLabel}</span>
                <i
                  className="ri-arrow-right-line text-base group-hover:translate-x-0.5 transition-transform"
                  aria-hidden="true"
                />
              </span>
            </Link>
          ))}
        </div>

        <p className="mt-6 flex items-start gap-2 text-[12.5px] leading-relaxed text-foreground-600">
          <i className="ri-information-line text-primary-600 mt-0.5" aria-hidden="true" />
          Указанные услуги оказываются по медицинским показаниям и при добровольном согласии
          пациента. Итоговая стоимость зависит от состояния пациента, объёма процедур и условий
          оказания помощи и согласуется до начала лечения.
        </p>
      </div>
    </section>
  );
}