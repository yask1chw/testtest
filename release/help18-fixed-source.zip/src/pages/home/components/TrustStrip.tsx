import { trustPoints } from '@/mocks/home';

export default function TrustStrip() {
  return (
    <section className="bg-background-50">
      <div className="max-w-content mx-auto px-4 md:px-6">
        <div className="border-y border-background-200 py-6 md:py-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6">
          {trustPoints.map((point) => (
            <div key={point.title} className="flex items-start gap-3">
              <span className="w-9 h-9 shrink-0 rounded-md bg-primary-50 flex items-center justify-center">
                <i className={`${point.icon} text-primary-700 text-lg`} aria-hidden="true" />
              </span>
              <div className="min-w-0">
                <p className="text-[13.5px] font-medium leading-snug text-foreground-950">
                  {point.title}
                </p>
                <p className="mt-1 text-[12.5px] leading-snug text-foreground-600">
                  {point.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}