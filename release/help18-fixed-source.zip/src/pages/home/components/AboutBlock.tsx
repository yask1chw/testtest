import { Link } from 'react-router-dom';

const principles = [
  {
    title: 'Без осуждения',
    description: 'Общаемся уважительно и не используем формулировки, которые унижают пациента.',
    icon: 'ri-heart-2-line',
  },
  {
    title: 'По показаниям',
    description: 'Назначаем только те процедуры, которые обоснованы результатами осмотра.',
    icon: 'ri-file-list-3-line',
  },
  {
    title: 'С объяснением',
    description: 'Рассказываем, что происходит, зачем нужна процедура и какие есть варианты.',
    icon: 'ri-chat-check-line',
  },
];

export default function AboutBlock() {
  return (
    <section className="bg-background-50 py-14 md:py-20">
      <div className="max-w-content mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          <div className="relative w-full h-[300px] md:h-[400px] rounded-lg overflow-hidden bg-background-200">
            <img
              src="https://readdy.ai/api/search-image?query=Clean%20quiet%20medical%20consultation%20room%20interior%20with%20a%20wooden%20desk%2C%20two%20soft%20chairs%2C%20muted%20sage%20green%20walls%20and%20warm%20natural%20light%20through%20sheer%20curtains%2C%20minimal%20calm%20healthcare%20design%2C%20no%20people%2C%20editorial%20interior%20photography%2C%20high%20detail&width=1000&height=800&seq=clinic-interior-01&orientation=landscape"
              alt="Кабинет консультации в наркологической клинике в Ижевске"
              title="Кабинет консультации нарколога в Ижевске"
              className="w-full h-full object-cover object-top"
            />
          </div>

          <div>
            <span className="inline-flex items-center gap-2 text-[12.5px] font-medium uppercase tracking-[0.16em] text-primary-700">
              <span className="w-6 h-px bg-primary-400" aria-hidden="true" />
              Наш подход
            </span>
            <h2 className="mt-3 font-heading font-extrabold text-[26px] md:text-[34px] leading-[1.16] text-foreground-950">
              Медицинская помощь, о которой можно спросить
            </h2>
            <p className="mt-3 text-[15px] leading-relaxed text-foreground-600">
              Обращение за наркологической помощью — сложный шаг. Мы объясняем, как всё
              устроено, до того как вы что-то решите, и не торопим с выбором.
            </p>

            <div className="mt-6 space-y-4">
              {principles.map((item) => (
                <div key={item.title} className="flex items-start gap-3">
                  <span className="w-10 h-10 shrink-0 rounded-md bg-primary-50 flex items-center justify-center">
                    <i className={`${item.icon} text-primary-700 text-lg`} aria-hidden="true" />
                  </span>
                  <div>
                    <h3 className="font-heading font-bold text-[14.5px] text-foreground-950">
                      {item.title}
                    </h3>
                    <p className="mt-1 text-[13px] leading-relaxed text-foreground-600">
                      {item.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-7 flex flex-col sm:flex-row gap-3">
              <Link
                to="/o-klinike/"
                className="h-11 px-5 rounded-md bg-primary-600 text-background-50 text-[14px] font-medium flex items-center justify-center gap-2 hover:bg-primary-700 transition-colors whitespace-nowrap"
              >
                О клинике
              </Link>
              <Link
                to="/kontakty/"
                className="h-11 px-5 rounded-md border border-background-300 text-foreground-900 text-[14px] font-medium flex items-center justify-center gap-2 hover:bg-background-100 transition-colors whitespace-nowrap"
              >
                <i className="ri-phone-line text-primary-600" aria-hidden="true" />
                Связаться с клиникой
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}