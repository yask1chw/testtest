import { processSteps } from '@/mocks/home';

export default function ProcessBlock() {
  return (
    <section className="bg-background-100 py-14 md:py-20">
      <div className="max-w-content mx-auto px-4 md:px-6">
        <div className="max-w-2xl">
          <span className="inline-flex items-center gap-2 text-[12.5px] font-medium uppercase tracking-[0.16em] text-primary-700">
            <span className="w-6 h-px bg-primary-400" aria-hidden="true" />
            Порядок работы
          </span>
          <h2 className="mt-3 font-heading font-extrabold text-[26px] md:text-[34px] leading-[1.16] text-foreground-950">
            Как проходит вызов врача на дом
          </h2>
          <p className="mt-3 text-[15px] leading-relaxed text-foreground-600">
            Никакой регистрации и длинных анкет. Достаточно звонка или заявки, чтобы специалист
            уточнил ситуацию и организовал выезд.
          </p>
        </div>

        <div className="mt-9 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 md:gap-4">
          {processSteps.map((step, index) => (
            <div
              key={step.title}
              className="relative bg-background-50 border border-background-200 rounded-lg p-5"
            >
              <div className="flex items-center gap-3">
                <span className="w-9 h-9 rounded-full bg-primary-600 text-background-50 font-heading font-bold text-[14px] flex items-center justify-center">
                  {index + 1}
                </span>
                <span className="h-px flex-1 bg-background-300/70" aria-hidden="true" />
              </div>
              <h3 className="mt-4 font-heading font-bold text-[15px] text-foreground-950">
                {step.title}
              </h3>
              <p className="mt-2 text-[13px] leading-relaxed text-foreground-600">
                {step.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-6 flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-5 rounded-lg border border-background-300/70 bg-background-50 px-4 md:px-5 py-4">
          <p className="flex items-start gap-2.5 text-[13px] leading-relaxed text-foreground-700 flex-1">
            <i className="ri-time-line text-primary-600 text-lg mt-0.5" aria-hidden="true" />
            Время прибытия врача зависит от адреса, загруженности службы и состояния пациента.
            Точное время специалист подтверждает во время разговора.
          </p>
          <a
            href="#zayavka"
            className="inline-flex items-center justify-center gap-2 h-10 px-5 rounded-md bg-primary-600 text-background-50 text-[14px] font-medium hover:bg-primary-700 transition-colors whitespace-nowrap cursor-pointer"
          >
            Оставить заявку
          </a>
        </div>
      </div>
    </section>
  );
}