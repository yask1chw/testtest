import { Link } from 'react-router-dom';
import { clinic } from '@/mocks/home';
import useLeadForm from '@/hooks/useLeadForm';
import { LEAD_FORM_ENDPOINT } from '@/lib/lead';
import { trackPhoneClick } from '@/lib/analytics';

export default function CallbackSection() {
  const { status, errorMessage, successMessage, handleSubmit } = useLeadForm({
    formId: 'home-callback-form',
    formName: 'Заявка на консультацию (главная)',
    sectionId: 'zayavka',
  });

  return (
    <section id="zayavka" className="bg-background-50 py-14 md:py-20 scroll-mt-24">
      <div className="max-w-content mx-auto px-4 md:px-6">
        <div className="rounded-lg bg-primary-900 overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-[0.95fr_1.05fr]">
            <div className="p-6 md:p-9 lg:p-10">
              <span className="inline-flex items-center gap-2 rounded-full bg-primary-800 px-3 py-1.5 text-[12px] text-primary-100">
                <i className="ri-phone-line" aria-hidden="true" />
                Обратный звонок
              </span>
              <h2 className="mt-4 font-heading font-extrabold text-[25px] md:text-[32px] leading-[1.16] text-background-50">
                Не знаете, с чего начать?
              </h2>
              <p className="mt-3 text-[14.5px] leading-relaxed text-primary-100 max-w-md">
                Оставьте номер — специалист перезвонит, задаст несколько вопросов о состоянии
                человека и подскажет, какая помощь возможна в вашей ситуации.
              </p>

              <a
                href={clinic.phoneHref}
                onClick={() => trackPhoneClick('callback_section', 'callback_section_phone')}
                className="mt-6 inline-flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 font-heading font-extrabold text-[24px] md:text-[28px] text-background-50 hover:text-primary-100 transition-colors"
              >
                {clinic.phone}
                <span className="text-[12px] font-normal uppercase tracking-wide text-primary-200">
                  {clinic.phoneLabel}
                </span>
              </a>

              <ul className="mt-7 space-y-3">
                {[
                  'Не нужно проходить регистрацию',
                  'Разговор конфиденциален',
                  'Навязчивые звонки исключены',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-[13.5px] text-primary-100">
                    <i className="ri-check-double-line text-accent-300 mt-0.5" aria-hidden="true" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-background-50 p-5 md:p-8">
              <h3 className="font-heading font-bold text-[17px] text-foreground-950">
                Заявка на консультацию
              </h3>
              <p className="mt-1.5 text-[13px] leading-relaxed text-foreground-600">
                Поля, отмеченные звёздочкой, обязательны.
              </p>

              <form
                id="callback-form"
                data-readdy-form
                action={LEAD_FORM_ENDPOINT}
                method="post"
                onSubmit={handleSubmit}
                className="mt-5 space-y-4"
              >
                <input
                  type="text"
                  name="website_alt"
                  className="honeypot-field"
                  tabIndex={-1}
                  autoComplete="off"
                  aria-hidden="true"
                  readOnly
                />

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
                  <div className="min-w-0">
                    <label htmlFor="callback-name" className="block text-[12.5px] text-foreground-700 mb-1.5">
                      Как к вам обращаться *
                    </label>
                    <input
                      id="callback-name"
                      name="name"
                      type="text"
                      required
                      autoComplete="name"
                      placeholder="Имя"
                      className="w-full box-border h-11 px-3.5 rounded-md border border-background-300 bg-background-50 text-[14px] text-foreground-950 placeholder:text-foreground-400 focus:outline-none focus:border-primary-400"
                    />
                  </div>
                  <div className="min-w-0">
                    <label htmlFor="callback-phone" className="block text-[12.5px] text-foreground-700 mb-1.5">
                      Телефон *
                    </label>
                    <input
                      id="callback-phone"
                      name="phone"
                      type="tel"
                      required
                      autoComplete="tel"
                      placeholder="+7 (___) ___-__-__"
                      className="w-full box-border h-11 px-3.5 rounded-md border border-background-300 bg-background-50 text-[14px] text-foreground-950 placeholder:text-foreground-400 focus:outline-none focus:border-primary-400"
                    />
                  </div>
                </div>

                <div className="min-w-0">
                  <label htmlFor="callback-topic" className="block text-[12.5px] text-foreground-700 mb-1.5">
                    Что вас беспокоит
                  </label>
                  <select
                    id="callback-topic"
                    name="topic"
                    defaultValue=""
                    className="w-full box-border h-11 px-3 rounded-md border border-background-300 bg-background-50 text-[14px] text-foreground-950 focus:outline-none focus:border-primary-400 cursor-pointer"
                  >
                    <option value="">Выберите ситуацию</option>
                    <option value="zapoy">Человек в запое</option>
                    <option value="pohmelye">Тяжёлое похмелье</option>
                    <option value="intoksikaciya">Алкогольная интоксикация</option>
                    <option value="kodirovanie">Кодирование</option>
                    <option value="lechenie">Плановое лечение</option>
                    <option value="konsultaciya">Нужна консультация</option>
                  </select>
                </div>

                <div className="min-w-0">
                  <label htmlFor="callback-comment" className="block text-[12.5px] text-foreground-700 mb-1.5">
                    Комментарий
                  </label>
                  <textarea
                    id="callback-comment"
                    name="comment"
                    rows={3}
                    maxLength={500}
                    placeholder="Коротко опишите ситуацию, если считаете нужным"
                    className="w-full box-border px-3.5 py-2.5 rounded-md border border-background-300 bg-background-50 text-[14px] text-foreground-950 placeholder:text-foreground-400 focus:outline-none focus:border-primary-400 resize-none"
                  />
                  <p className="mt-1 text-[11.5px] text-foreground-500">До 500 символов</p>
                </div>

                <label className="flex items-start gap-2.5 text-[12px] leading-relaxed text-foreground-600">
                  <input
                    type="checkbox"
                    name="consent"
                    value="yes"
                    required
                    className="mt-0.5 w-4 h-4 shrink-0 accent-primary-600"
                  />
                  <span>
                    Согласен с{' '}
                    <Link to="/privacy-policy/" className="text-primary-700 underline">
                      политикой обработки персональных данных
                    </Link>{' '}
                    и на обратный звонок по указанному номеру.
                  </span>
                </label>

                <button
                  type="submit"
                  disabled={status === 'sending'}
                  className="w-full h-12 rounded-md bg-primary-600 text-background-50 text-[15px] font-medium flex items-center justify-center gap-2 hover:bg-primary-700 transition-colors disabled:opacity-70 whitespace-nowrap cursor-pointer"
                >
                  {status === 'sending' ? (
                    <>
                      <i className="ri-loader-4-line animate-spin" aria-hidden="true" />
                      Отправляем
                    </>
                  ) : (
                    <>
                      <i className="ri-send-plane-line" aria-hidden="true" />
                      Отправить заявку
                    </>
                  )}
                </button>

                {status === 'success' && (
                  <p
                    role="status"
                    className="flex items-start gap-2 rounded-md bg-primary-50 border border-primary-200 px-3.5 py-3 text-[13px] leading-snug text-primary-900"
                  >
                    <i className="ri-checkbox-circle-line mt-0.5" aria-hidden="true" />
                    {successMessage}
                  </p>
                )}

                {status === 'error' && (
                  <p
                    role="alert"
                    className="flex items-start gap-2 rounded-md bg-accent-50 border border-accent-300 px-3.5 py-3 text-[13px] leading-snug text-accent-900"
                  >
                    <i className="ri-error-warning-line mt-0.5" aria-hidden="true" />
                    {errorMessage}
                  </p>
                )}

                <p className="text-[11.5px] leading-relaxed text-foreground-500">
                  Медицинская информация передаётся только специалистам клиники и не публикуется.
                  Обращения без согласия пациента носят консультационный характер.
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}