import { Link } from 'react-router-dom';
import { clinic } from '@/mocks/home';
import { useRequestModal } from '@/hooks/useRequestModal';
import { trackPhoneClick } from '@/lib/analytics';

const contactRows = [
  {
    icon: 'ri-time-line',
    label: 'Режим работы',
    value: clinic.workHours,
    note: 'Выезд врача — по согласованию со специалистом',
  },
  {
    icon: 'ri-chat-3-line',
    label: 'Формат обращения',
    value: 'Звонок или заявка на сайте',
    note: 'Специалист уточнит ситуацию и условия помощи',
  },
];

const contactSteps = [
  {
    title: 'Звонок или заявка',
    text: 'Специалист уточнит ситуацию и состояние человека, ответит на вопросы.',
  },
  {
    title: 'Согласование помощи',
    text: 'Обсуждаются возможные варианты обращения, объём помощи и стоимость.',
  },
  {
    title: 'Осмотр врача',
    text: 'Врач оценивает состояние и определяет, какая помощь показана.',
  },
];

export default function ContactsSection() {
  const { openRequest } = useRequestModal();

  return (
    <section id="kontakty" className="bg-background-50 py-14 md:py-20 scroll-mt-24">
      <div className="max-w-content mx-auto px-4 md:px-6">
        <span className="inline-flex items-center gap-2 text-[12.5px] font-medium uppercase tracking-[0.16em] text-primary-700">
          <span className="w-6 h-px bg-primary-400" aria-hidden="true" />
          Контакты
        </span>
        <h2 className="mt-3 font-heading font-extrabold text-[26px] md:text-[34px] leading-[1.16] text-foreground-950 max-w-2xl">
          Как связаться с наркологической клиникой в Ижевске
        </h2>
        <p className="mt-3 text-[15px] leading-relaxed text-foreground-600 max-w-2xl">
          Позвоните, чтобы уточнить условия обращения и возможность выезда врача.
        </p>

        <div className="mt-8 md:mt-10 grid grid-cols-1 lg:grid-cols-[0.95fr_1.05fr] gap-6 lg:gap-8 items-start">
          <div className="rounded-lg border border-background-200 bg-background-50 p-5 md:p-7">
            <a
              href={clinic.phoneHref}
              onClick={() => trackPhoneClick('contacts_section', 'contacts_phone_big')}
              className="flex items-center gap-3 group"
            >
              <span className="w-12 h-12 rounded-lg bg-primary-50 flex items-center justify-center shrink-0">
                <i className="ri-phone-line text-primary-700 text-xl" aria-hidden="true" />
              </span>
              <span>
                <span className="block font-heading font-extrabold text-[22px] md:text-[26px] text-foreground-950 group-hover:text-primary-700 transition-colors whitespace-nowrap">
                  {clinic.phone}
                </span>
                <span className="block text-[12px] text-foreground-600 mt-0.5">
                  {clinic.phoneLabel}
                </span>
              </span>
            </a>

            <dl className="mt-6 space-y-4">
              {contactRows.map((row) => (
                <div key={row.label} className="flex items-start gap-3">
                  <span className="w-8 h-8 shrink-0 rounded-md bg-background-100 flex items-center justify-center">
                    <i className={`${row.icon} text-foreground-700`} aria-hidden="true" />
                  </span>
                  <div className="min-w-0">
                    <dt className="text-[11.5px] uppercase tracking-wide text-foreground-500">
                      {row.label}
                    </dt>
                    <dd className="text-[14px] leading-snug text-foreground-900 select-all break-words">
                      {row.value}
                    </dd>
                    <dd className="mt-0.5 text-[11.5px] leading-snug text-foreground-500">
                      {row.note}
                    </dd>
                  </div>
                </div>
              ))}
            </dl>

            <div className="mt-6 pt-5 border-t border-background-200 flex flex-col sm:flex-row gap-2.5">
              <a
                href={clinic.phoneHref}
                onClick={() => trackPhoneClick('contacts_section', 'contacts_call_button')}
                className="flex-1 h-11 rounded-md bg-primary-600 text-background-50 text-[14px] font-medium flex items-center justify-center gap-2 hover:bg-primary-700 transition-colors whitespace-nowrap"
              >
                <i className="ri-phone-line" aria-hidden="true" />
                Позвонить
              </a>
              <button
                type="button"
                onClick={() => openRequest('contacts_section')}
                className="flex-1 h-11 rounded-md border border-background-300 text-foreground-900 text-[14px] font-medium flex items-center justify-center gap-2 hover:bg-background-100 transition-colors whitespace-nowrap cursor-pointer"
              >
                <i className="ri-send-plane-line text-primary-600" aria-hidden="true" />
                Оставить заявку
              </button>
            </div>

            <Link
              to="/kontakty/"
              className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-medium text-primary-700 hover:text-primary-900 transition-colors"
            >
              Подробнее о контактах
              <i className="ri-arrow-right-line" aria-hidden="true" />
            </Link>
          </div>

          <div className="rounded-lg border border-background-200 bg-background-100 p-5 md:p-7">
            <h3 className="font-heading font-bold text-[17px] text-foreground-950">
              Как проходит обращение
            </h3>
            <ol className="mt-4 space-y-4">
              {contactSteps.map((step, index) => (
                <li key={step.title} className="flex items-start gap-3">
                  <span className="w-7 h-7 shrink-0 rounded-full bg-background-50 text-primary-800 font-heading font-bold text-[12.5px] flex items-center justify-center">
                    {index + 1}
                  </span>
                  <div className="min-w-0">
                    <p className="font-heading font-semibold text-[14px] text-foreground-950">
                      {step.title}
                    </p>
                    <p className="mt-1 text-[12.5px] leading-relaxed text-foreground-600">
                      {step.text}
                    </p>
                  </div>
                </li>
              ))}
            </ol>
            <p className="mt-5 pt-4 border-t border-background-200 flex items-start gap-2 text-[12px] leading-relaxed text-foreground-600">
              <i className="ri-information-line text-primary-600 mt-0.5" aria-hidden="true" />
              Возможность помощи на дому определяется состоянием пациента и медицинскими
              показаниями.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}