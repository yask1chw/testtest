import { Link } from 'react-router-dom';
import SectionHeading from '@/components/base/SectionHeading';
import { doctors } from '@/mocks/home';
import { trackDoctorClick } from '@/lib/analytics';

export default function DoctorsTeaser() {
  return (
    <section className="bg-background-100 py-14 md:py-20">
      <div className="max-w-content mx-auto px-4 md:px-6">
        <SectionHeading
          eyebrow="Специалисты"
          title="Приём ведут врачи психиатры-наркологи"
          description="Специалисты с подтверждённой медицинской квалификацией и действующими сертификатами. На странице каждого врача указаны направление работы и стаж."
          action={
            <Link
              to="/vrachi/"
              onClick={() => trackDoctorClick('doctors_section', 'doctors_all')}
              className="inline-flex items-center gap-2 text-[14px] font-medium text-primary-700 hover:text-primary-800 transition-colors whitespace-nowrap"
            >
              Все врачи клиники
              <i className="ri-arrow-right-line" aria-hidden="true" />
            </Link>
          }
        />

        <div className="mt-8 md:mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
          {doctors.map((doctor) => (
            <article
              key={doctor.name}
              className="group bg-background-50 border border-background-200 rounded-lg overflow-hidden hover:border-primary-300 transition-colors"
            >
              <div className="w-full h-[260px] md:h-[300px] bg-background-200 overflow-hidden">
                <img
                  src={doctor.photo}
                  alt={`${doctor.name} — ${doctor.role}`}
                  title={`${doctor.name} — ${doctor.focus}`}
                  width={600}
                  height={700}
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover object-top group-hover:scale-[1.02] transition-transform duration-500"
                />
              </div>
              <div className="p-4 md:p-5">
                <h3 className="font-heading font-bold text-[15.5px] leading-snug text-foreground-950">
                  {doctor.name}
                </h3>
                <p className="mt-1 text-[13px] text-primary-800">{doctor.role}</p>
                <p className="mt-3 text-[12.5px] leading-relaxed text-foreground-600">
                  {doctor.focus}
                </p>
                <p className="mt-3 pt-3 border-t border-background-200 text-[12px] text-foreground-500">
                  {doctor.experience}
                </p>
              </div>
            </article>
          ))}
        </div>

        <p className="mt-6 flex items-start gap-2 text-[12.5px] leading-relaxed text-foreground-600 max-w-3xl">
          <i className="ri-file-shield-2-line text-primary-600 mt-0.5" aria-hidden="true" />
          Сведения об образовании и сертификатах специалистов предоставляются по запросу и
          размещены в разделе «Врачи». Сведения о специалистах предоставляются по запросу.
        </p>
      </div>
    </section>
  );
}