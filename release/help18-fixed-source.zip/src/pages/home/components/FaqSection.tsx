import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import Accordion, { type AccordionItem } from '@/components/base/Accordion';
import { faqItems } from '@/mocks/home';

export default function FaqSection() {
  useEffect(() => {
    const scriptId = 'faq-page-schema';
    document.getElementById(scriptId)?.remove();

    const schema = {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: faqItems.map((item) => ({
        '@type': 'Question',
        name: item.question,
        acceptedAnswer: {
          '@type': 'Answer',
          text: item.answer,
        },
      })),
    };

    const script = document.createElement('script');
    script.id = scriptId;
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(schema);
    document.head.appendChild(script);

    return () => {
      document.getElementById(scriptId)?.remove();
    };
  }, []);

  const items: AccordionItem[] = faqItems.map((item) => ({
    id: item.id,
    question: item.question,
    answer: (
      <>
        <p>{item.answer}</p>
        {item.linkHref && (
          <Link
            to={item.linkHref}
            className="mt-2.5 inline-flex items-center gap-1.5 text-[13.5px] font-medium text-primary-700 hover:text-primary-900 transition-colors"
          >
            {item.linkLabel}
            <i className="ri-arrow-right-line" aria-hidden="true" />
          </Link>
        )}
      </>
    ),
  }));

  return (
    <section id="faq" className="bg-background-100 py-14 md:py-20 scroll-mt-24">
      <div className="max-w-[900px] mx-auto px-4 md:px-6">
        <div className="text-center">
          <span className="inline-flex items-center gap-2 text-[12px] font-medium uppercase tracking-[0.16em] text-primary-700">
            <span className="w-6 h-px bg-primary-400" aria-hidden="true" />
            Отвечаем на вопросы
            <span className="w-6 h-px bg-primary-400" aria-hidden="true" />
          </span>
          <h2 className="mt-3 font-heading font-extrabold text-[26px] md:text-[34px] leading-[1.16] text-foreground-950">
            Частые вопросы о наркологической помощи
          </h2>
          <p className="mt-3 text-[14.5px] md:text-[15.5px] leading-relaxed text-foreground-600">
            Собрали ответы на вопросы о вызове нарколога, выводе из запоя, стоимости медицинских
            услуг и условиях лечения в Ижевске.
          </p>
        </div>

        <div className="mt-8 md:mt-10">
          <Accordion items={items} allowMultiple />
        </div>

        <p className="mt-6 text-center text-[12.5px] leading-relaxed text-foreground-500">
          Ответы носят справочный характер и не заменяют консультацию врача. Тактика помощи
          определяется индивидуально после осмотра.
        </p>
      </div>
    </section>
  );
}