import { Link } from 'react-router-dom';
import { clinic } from '@/mocks/home';
import useLeadForm from '@/hooks/useLeadForm';

export default function FinalCta() {
  const { status, errorMessage, successMessage, handleSubmit } = useLeadForm({
    formId: 'final-cta-form',
    formName: 'Заключительный блок — обратный звонок',
    sectionId: 'final-cta',
  });

  return (
    <section id="final-cta" className="bg-primary-600 py-14 md:py-20 scroll-mt-20">
      <div className="max-w-content mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-[1.1fr_0.9fr] gap-8 lg:gap-12 items-center">
          <div>
            <span className="inline-flex items-center gap-2 text-[12px] font-medium uppercase tracking-[0.16em] text-primary-100">
              <span className="w-6 h-px bg-primary-200" aria-hidden="true" />
              Свяжитесь с клиникой
            </span>
            <h2 className="mt-3 font-heading font-extrabold text-[27px] md:text-[36px] leading-[1.14] text-background-50">
              Нужна помощь нарколога в Ижевске?
            </h2>
            <p className="mt-4 text-[14.5px] md:text-[16px] leading-relaxed text-primary-50 max-w-xl">
              Если вам или близкому человеку требуется наркологическая помощь, свяжитесь с клиникой.
              Специалист уточнит ситуацию, расскажет о доступных вариантах обращения и условиях
              вызова врача на дом.
            </p>
            <p className="mt-3 text-[13px] leading-relaxed text-primary-100 max-w-xl">
              Возможность лечения на дому определяется состоянием пациента и медицинскими
              показаниями.
            </p>

            <div className="mt-6 md:mt-7">
              <a
                href={clinic.phoneHref}
                className="inline-flex items-center gap-3 font-heading font-extrabold text-[25px] md:text-[32px] text-background-50 hover:text-primary-50 transition-colors"
              >
                <span className="w-11 h-11 rounded-full bg-primary-500 flex items-center justify-center shrink-0">
                  <i className="ri-phone-fill text-background-50 text-lg" aria-hidden="true" />
                </span>
                {clinic.phone}
              </a>
              <p className="mt-2 text-[12.5px] text-primary-100">
                Позвоните, чтобы уточнить условия обращения.
              </p>
            </div>
          </div>

          <div className="bg-background-50 rounded-lg p-5 md:p-8 border border-primary-500/30">
            <h3 className="font-heading font-bold text-[18px] md:text-[20px] text-foreground-950">
              Запросить обратный звонок
            </h3>
            <p className="mt-1.5 text-[13px] leading-relaxed text-foreground-600">
              Оставьте контактный номер для связи со специалистом клиники.
            </p>

            {status === 'success' ? (
              <div className="mt-5 rounded-md bg-primary-50 border border-primary-200 px-4 py-4">
                <p className="flex items-start gap-2 text-[13.5px] leading-relaxed text-primary-900">
                  <i className="ri-checkbox-circle-line mt-0.5" aria-hidden="true" />
                  {successMessage}
                </p>
                <a
                  href={clinic.phoneHref}
                  className="mt-3 inline-flex items-center gap-2 text-[13.5px] font-medium text-primary-800 hover:text-primary-900"
                >
                  <i className="ri-phone-line" aria-hidden="true" />
                  {clinic.phone}
                </a>
              </div>
            ) : (
              <form
                id="final-cta-form"
                data-readdy-form
                action="https://readdy.ai/api/form/dbfkamgob50fdbpndc8g"
                method="post"
                onSubmit={handleSubmit}
                className="mt-5 space-y-3.5"
                noValidate={false}
              >
                <input
                  type="text"
                  name="website_alt"
                  className="honeypot-field"
                  tabIndex={-1}
                  autoComplete="off"
                  aria-hidden="true"
                  readOnly
                />

                <div className="min-w-0">
                  <label
                    htmlFor="final-cta-phone"
                    className="block text-[12.5px] text-foreground-700 mb-1.5"
                  >
                    Ваш номер телефона *
                  </label>
                  <input
                    id="final-cta-phone"
                    name="phone"
                    type="tel"
                    required
                    placeholder="+7 (___) ___-__-__"
                    autoComplete="tel"
                    aria-describedby="final-cta-phone-hint"
                    className="w-full box-border h-12 px-3.5 rounded-md border border-background-300 bg-background-50 text-[15px] text-foreground-950 placeholder:text-foreground-400 focus:outline-none focus:border-primary-500 focus:ring-2 focus:ring-primary-200"
                  />
                  <p id="final-cta-phone-hint" className="mt-1 text-[11.5px] text-foreground-500">
                    Формат: +7 (965) 840-70-03
                  </p>
                </div>

                <label className="flex items-start gap-2.5 text-[12px] leading-relaxed text-foreground-600">
                  <input
                    type="checkbox"
                    name="consent"
                    value="yes"
                    required
                    className="mt-0.5 w-4 h-4 shrink-0 accent-primary-600"
                  />
                  <span>
                    Согласен с{' '}
                    <Link
                      to="/privacy-policy/"
                      className="text-primary-700 underline hover:text-primary-900"
                    >
                      политикой обработки персональных данных
                    </Link>{' '}
                    и на обратный звонок по указанному номеру.
                  </span>
                </label>

                <button
                  type="submit"
                  disabled={status === 'sending'}
                  className="w-full h-12 rounded-md bg-primary-600 text-background-50 text-[15px] font-medium flex items-center justify-center gap-2 hover:bg-primary-700 transition-colors disabled:opacity-70 whitespace-nowrap cursor-pointer"
                >
                  {status === 'sending' ? (
                    <>
                      <i className="ri-loader-4-line animate-spin" aria-hidden="true" />
                      Отправляем
                    </>
                  ) : (
                    <>
                      <i className="ri-send-plane-line" aria-hidden="true" />
                      Оставить заявку
                    </>
                  )}
                </button>

                {status === 'error' && (
                  <p
                    role="alert"
                    className="flex items-start gap-2 rounded-md bg-accent-50 border border-accent-300 px-3.5 py-3 text-[12.5px] leading-snug text-accent-900"
                  >
                    <i className="ri-error-warning-line mt-0.5" aria-hidden="true" />
                    {errorMessage}
                  </p>
                )}

                <p className="text-[11.5px] leading-relaxed text-foreground-500">
                  Подробную медицинскую информацию по телефону не собираем. Конкретное время
                  прибытия врача не гарантируется.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}