import { Link } from 'react-router-dom';
import { priceFactors, priceGroups } from '@/mocks/prices';
import { trackPricesClick } from '@/lib/analytics';

export default function PricesTeaser() {
  return (
    <section id="ceny" className="bg-background-50 py-14 md:py-20 scroll-mt-24">
      <div className="max-w-content mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-[1.25fr_0.75fr] gap-8 lg:gap-10 items-start">
          <div>
            <span className="inline-flex items-center gap-2 text-[12.5px] font-medium uppercase tracking-[0.16em] text-primary-700">
              <span className="w-6 h-px bg-primary-400" aria-hidden="true" />
              Стоимость
            </span>
            <h2 className="mt-3 font-heading font-extrabold text-[26px] md:text-[34px] leading-[1.16] text-foreground-950">
              Цены по направлениям
            </h2>
            <p className="mt-3 text-[15px] leading-relaxed text-foreground-600 max-w-xl">
              Мы не скрываем платные процедуры за формулировкой «бесплатная помощь».
              Стоимость обсуждается до начала лечения.
            </p>

            <ul className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3">
              {priceGroups.map((group) => (
                <li key={group.id}>
                  <Link
                    to={`/ceny/#${group.id}`}
                    onClick={() => trackPricesClick('prices_section', group.id)}
                    className="group h-full rounded-lg border border-background-200 bg-background-50 p-4 flex flex-col hover:border-primary-300 transition-colors"
                  >
                    <span className="flex items-start gap-2.5">
                      <span className="w-8 h-8 shrink-0 rounded-md bg-primary-50 flex items-center justify-center">
                        <i className={`${group.icon} text-primary-700`} aria-hidden="true" />
                      </span>
                      <span className="min-w-0">
                        <span className="block font-heading font-semibold text-[13.5px] leading-snug text-foreground-950 group-hover:text-primary-800 transition-colors">
                          {group.title}
                        </span>
                        <span className="mt-1 block text-[11.5px] leading-snug text-foreground-500">
                          {group.hint}
                        </span>
                      </span>
                    </span>
                    <span className="mt-3 pt-2.5 border-t border-background-200 font-heading font-bold text-[15px] text-primary-800">
                      {group.fromPrice}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>

            <Link
              to="/ceny/"
              onClick={() => trackPricesClick('prices_section', 'prices_full_list')}
              className="mt-5 inline-flex items-center gap-2 text-[14px] font-medium text-primary-700 hover:text-primary-800 transition-colors"
            >
              Полный прайс-лист клиники
              <i className="ri-arrow-right-line" aria-hidden="true" />
            </Link>
          </div>

          <div className="rounded-lg bg-secondary-100 p-5 md:p-6 lg:sticky lg:top-24">
            <span className="w-10 h-10 rounded-md bg-background-50 flex items-center justify-center">
              <i className="ri-calculator-line text-secondary-800 text-xl" aria-hidden="true" />
            </span>
            <h3 className="mt-4 font-heading font-bold text-[17px] text-secondary-950">
              От чего зависит стоимость
            </h3>
            <ul className="mt-3 space-y-2.5">
              {priceFactors.map((factor) => (
                <li key={factor} className="flex items-start gap-2 text-[13.5px] leading-snug text-secondary-900">
                  <i className="ri-check-line text-primary-700 mt-0.5" aria-hidden="true" />
                  {factor}
                </li>
              ))}
            </ul>
            <div className="mt-5 pt-4 border-t border-secondary-200">
              <p className="text-[12.5px] leading-relaxed text-secondary-800">
                Точную стоимость специалист называет после уточнения ситуации. Оплата — после
                согласования объёма помощи.
              </p>
              <a
                href="#zayavka"
                onClick={() => trackPricesClick('prices_section', 'prices_ask')}
                className="mt-4 flex items-center justify-center gap-2 h-11 rounded-md bg-secondary-900 text-background-50 text-[14px] font-medium hover:bg-secondary-800 transition-colors whitespace-nowrap cursor-pointer"
              >
                Узнать стоимость
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}