import { Link } from 'react-router-dom';

const rows = [
  {
    label: 'Где оказывается помощь',
    home: 'По месту нахождения пациента',
    clinic: 'В медицинской организации, круглосуточно',
  },
  {
    label: 'Когда подходит',
    home: 'Состояние допускает лечение вне стационара',
    clinic: 'Нужно постоянное наблюдение или процедуры в особых условиях',
  },
  {
    label: 'Наблюдение',
    home: 'Врач контролирует состояние во время помощи',
    clinic: 'Круглосуточный медицинский контроль',
  },
  {
    label: 'Ограничения',
    home: 'Не всё можно выполнить вне клиники, часть препаратов не применяется на дому',
    clinic: 'Требуется госпитализация и оформление документов',
  },
  {
    label: 'Ориентировочная стоимость',
    home: 'от 4 500 ₽ за базовую программу',
    clinic: 'от 6 200 ₽ за сутки пребывания',
  },
];

export default function HomeClinicCompare() {
  return (
    <section className="bg-background-50 py-14 md:py-20">
      <div className="max-w-content mx-auto px-4 md:px-6">
        <div className="max-w-2xl">
          <span className="inline-flex items-center gap-2 text-[12.5px] font-medium uppercase tracking-[0.16em] text-primary-700">
            <span className="w-6 h-px bg-primary-400" aria-hidden="true" />
            Формат помощи
          </span>
          <h2 className="mt-3 font-heading font-extrabold text-[26px] md:text-[34px] leading-[1.16] text-foreground-950">
            Помощь на дому или в стационаре
          </h2>
          <p className="mt-3 text-[15px] leading-relaxed text-foreground-600">
            Формат выбирает врач с учётом состояния пациента и медицинских показаний.
            Ниже — основные различия, чтобы вы понимали, чего ожидать.
          </p>
        </div>

        <div className="mt-8 rounded-lg border border-background-200 overflow-hidden">
          <div className="hidden md:grid grid-cols-[1.1fr_1fr_1fr] bg-background-100 text-[12px] uppercase tracking-wide text-foreground-500">
            <div className="px-5 py-3">Параметр</div>
            <div className="px-5 py-3 border-l border-background-200">На дому</div>
            <div className="px-5 py-3 border-l border-background-200">В стационаре</div>
          </div>
          <ul>
            {rows.map((row) => (
              <li
                key={row.label}
                className="border-t border-background-200 first:border-t-0 md:first:border-t-0 bg-background-50"
              >
                <div className="grid grid-cols-1 md:grid-cols-[1.1fr_1fr_1fr]">
                  <div className="px-5 pt-3.5 md:py-3.5 font-heading font-semibold text-[13.5px] text-foreground-950">
                    {row.label}
                  </div>
                  <div className="px-5 py-1.5 md:py-3.5 md:border-l border-background-200">
                    <span className="md:hidden block text-[11px] uppercase tracking-wide text-foreground-500">
                      На дому
                    </span>
                    <span className="text-[13.5px] leading-snug text-foreground-700">{row.home}</span>
                  </div>
                  <div className="px-5 pt-1.5 pb-3.5 md:py-3.5 md:border-l border-background-200">
                    <span className="md:hidden block text-[11px] uppercase tracking-wide text-foreground-500">
                      В стационаре
                    </span>
                    <span className="text-[13.5px] leading-snug text-foreground-700">{row.clinic}</span>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-5 flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
          <p className="text-[12.5px] leading-relaxed text-foreground-600 max-w-xl">
            Решение о формате принимается после осмотра врача и с учётом медицинских показаний.
          </p>
          <div className="flex flex-wrap gap-2.5">
            <Link
              to="/vyvod-iz-zapoya/"
              className="h-10 px-4 rounded-md border border-background-300 text-foreground-900 text-[13.5px] font-medium flex items-center justify-center hover:bg-background-100 transition-colors whitespace-nowrap"
            >
              Помощь на дому
            </Link>
            <Link
              to="/stacionar/"
              className="h-10 px-4 rounded-md bg-primary-600 text-background-50 text-[13.5px] font-medium flex items-center justify-center hover:bg-primary-700 transition-colors whitespace-nowrap"
            >
              Условия стационара
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}