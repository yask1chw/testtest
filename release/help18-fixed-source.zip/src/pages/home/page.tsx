import SiteHeader from '@/components/feature/SiteHeader';
import SiteFooter from '@/components/feature/SiteFooter';
import MobileActionBar from '@/components/feature/MobileActionBar';
import Hero from '@/pages/home/components/Hero';
import TrustStrip from '@/pages/home/components/TrustStrip';
import ServiceGrid from '@/pages/home/components/ServiceGrid';
import SituationBlock from '@/pages/home/components/SituationBlock';
import ProcessBlock from '@/pages/home/components/ProcessBlock';
import AboutBlock from '@/pages/home/components/AboutBlock';
import PricesTeaser from '@/pages/home/components/PricesTeaser';
import DoctorsTeaser from '@/pages/home/components/DoctorsTeaser';
import HomeClinicCompare from '@/pages/home/components/HomeClinicCompare';
import CallbackSection from '@/pages/home/components/CallbackSection';
import FaqSection from '@/pages/home/components/FaqSection';
import FinalCta from '@/pages/home/components/FinalCta';
import ContactsSection from '@/pages/home/components/ContactsSection';
import useDocumentMeta from '@/hooks/useDocumentMeta';

export default function Home() {
  useDocumentMeta({
    title: 'Наркологическая помощь в Ижевске — нарколог на дом, вывод из запоя | Хелп18',
    description:
      'Наркологическая помощь в Ижевске: вызов врача на дом, вывод из запоя, капельницы, кодирование и лечение зависимостей. Информация об услугах, врачах, ценах и условиях обращения.',
    canonicalPath: '/',
  });

  return (
    <div className="min-h-screen bg-background-50 pb-[76px] lg:pb-0">
      <a href="#main-content" className="skip-link">
        Перейти к основному содержанию
      </a>
      <SiteHeader />
      <main id="main-content" tabIndex={-1}>
        <Hero />
        <TrustStrip />
        <ServiceGrid />
        <SituationBlock />
        <ProcessBlock />
        <AboutBlock />
        <PricesTeaser />
        <DoctorsTeaser />
        <HomeClinicCompare />
        <CallbackSection />
        <FaqSection />
        <FinalCta />
        <ContactsSection />
      </main>
      <SiteFooter />
      <MobileActionBar />
    </div>
  );
}