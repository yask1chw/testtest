import { useCallback, useRef, useState, type FormEvent } from 'react';
import { submitLead, type LeadContext, type LeadStatus } from '@/lib/lead';
import { trackEvent } from '@/lib/analytics';

export interface LeadFormState {
  status: LeadStatus;
  errorMessage: string;
  successMessage: string;
  handleSubmit: (event: FormEvent<HTMLFormElement>) => Promise<void>;
  reset: () => void;
}

export default function useLeadForm(context: LeadContext): LeadFormState {
  const [status, setStatus] = useState<LeadStatus>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const inFlight = useRef(false);

  const reset = useCallback(() => {
    setStatus('idle');
    setErrorMessage('');
    setSuccessMessage('');
    inFlight.current = false;
  }, []);

  const { formId, formName, sectionId } = context;
  const handleSubmit = useCallback(
    async (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      if (inFlight.current) {
        return;
      }

      const form = event.currentTarget;
      inFlight.current = true;

      setStatus('sending');
      setErrorMessage('');
      setSuccessMessage('');

      const baseParams = {
        form_id: formId,
        form_name: formName,
        section_id: sectionId,
      };

      trackEvent('submit_callback', baseParams);

      try {
        const result = await submitLead(form, { formId, formName, sectionId });

        if (result.ok) {
          form.reset();
          setStatus('success');
          setSuccessMessage(result.message);
          // Цель «успешная заявка» отправляется только после подтверждения сервера.
          trackEvent('callback_success', baseParams);
          return;
        }

        setStatus('error');
        setErrorMessage(result.message);
        trackEvent('callback_error', baseParams);
      } finally {
        inFlight.current = false;
      }
    },
    [formId, formName, sectionId],
  );

  return { status, errorMessage, successMessage, handleSubmit, reset };
}