import { DocumentMetaContext } from './documentMetaContext';
import { useContext, useEffect } from 'react';

export interface DocumentMeta {
  title: string;
  description: string;
  /** Путь без домена. Для 404 и служебных страниц не передаётся. */
  canonicalPath?: string;
  ogImage?: string;
  noindex?: boolean;
}

const DEFAULT_OG_IMAGE =
  'https://readdy.ai/api/search-image?query=Calm%20medical%20scene%20with%20a%20doctor%20in%20white%20coat%20holding%20a%20medical%20bag%20in%20a%20bright%20neutral%20interior%2C%20soft%20muted%20teal%20and%20warm%20beige%20tones%2C%20natural%20daylight%2C%20clean%20minimal%20editorial%20photography%2C%20professional%20and%20reassuring%20atmosphere&width=1200&height=630&seq=og-narkomed-izhevsk&orientation=landscape';

function readBasePath(): string {
  const value = (window as unknown as { __BASE_PATH__?: string }).__BASE_PATH__ || '';
  return value.endsWith('/') && value !== '/' ? value.slice(0, -1) : value;
}

export function buildAbsoluteUrl(path: string): string {
  const origin = import.meta.env.VITE_SITE_ORIGIN || window.location.origin;
  const basePath = readBasePath();
  const normalized = path.startsWith('/') ? path : `/${path}`;
  return `${origin}${basePath}${normalized === '/' ? '/' : normalized}`;
}

function setMetaTag(attribute: 'name' | 'property', key: string, content: string): void {
  let tag = document.head.querySelector<HTMLMetaElement>(`meta[${attribute}="${key}"]`);
  if (!tag) {
    tag = document.createElement('meta');
    tag.setAttribute(attribute, key);
    document.head.appendChild(tag);
  }
  tag.setAttribute('content', content);
}

export default function useDocumentMeta({
  title,
  description,
  canonicalPath,
  ogImage,
  noindex = false,
}: DocumentMeta): void {
  const collect = useContext(DocumentMetaContext);
  collect?.({ title, description, canonicalPath, ogImage, noindex });
  useEffect(() => {
    document.title = title;

    setMetaTag('name', 'description', description);
    setMetaTag('property', 'og:type', 'website');
    setMetaTag('property', 'og:site_name', 'Хелп18 · Ижевск');
    setMetaTag('property', 'og:locale', 'ru_RU');
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:image', ogImage || DEFAULT_OG_IMAGE);
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', title);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', ogImage || DEFAULT_OG_IMAGE);

    if (noindex) {
      setMetaTag('name', 'robots', 'noindex, follow');
    } else {
      setMetaTag('name', 'robots', 'index, follow');
    }

    let link = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');

    if (!canonicalPath) {
      if (link) {
        link.remove();
      }
      return;
    }

    const absolute = buildAbsoluteUrl(canonicalPath);
    if (!link) {
      link = document.createElement('link');
      link.rel = 'canonical';
      document.head.appendChild(link);
    }
    link.href = absolute;
    setMetaTag('property', 'og:url', absolute);
  }, [title, description, canonicalPath, ogImage, noindex]);
}