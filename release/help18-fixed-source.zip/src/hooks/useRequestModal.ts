import { createContext, useContext } from 'react';
interface RequestModalContextValue {
  /** sectionId нужен только для аналитики — откуда открыли форму. */
  openRequest: (sectionId?: string) => void;
  closeRequest: () => void;
  isOpen: boolean;
}

export const RequestModalContext = createContext<RequestModalContextValue | null>(null);

export function useRequestModal() {
  const context = useContext(RequestModalContext);
  if (!context) {
    throw new Error('useRequestModal must be used inside RequestModalProvider');
  }
  return context;
}

