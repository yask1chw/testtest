import { createContext } from 'react';
import type { DocumentMeta } from './useDocumentMeta';
export const DocumentMetaContext = createContext<((meta: DocumentMeta) => void) | null>(null);
