import { renderToString } from 'react-dom/server';
import App from './App';
import routes from './router/config';
import { DocumentMetaContext } from './hooks/documentMetaContext';
import type { DocumentMeta } from './hooks/useDocumentMeta';
import { faqItems } from './mocks/home';

export const publicPaths = routes.map(route => route.path).filter(
  (path): path is string => Boolean(path && path !== '*' && path !== '/politika-konfidencialnosti/'),
);
export function render(path: string) {
  let meta: DocumentMeta | undefined;
  const html = renderToString(
    <DocumentMetaContext.Provider value={value => { meta = value; }}>
      <App url={path} />
    </DocumentMetaContext.Provider>,
  );
  if (!meta) throw new Error(`Missing page metadata: ${path}`);
  return { html, meta, faq: path === '/' ? faqItems : [] };
}
