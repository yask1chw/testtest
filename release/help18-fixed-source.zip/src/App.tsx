import { useEffect } from "react";
import { BrowserRouter, StaticRouter } from "react-router-dom";
import { AppRoutes } from "./router";
import { I18nextProvider } from "react-i18next";
import i18n from "./i18n";
import { RequestModalProvider } from "./components/feature/RequestModal";
import ScrollManager from "./components/feature/ScrollManager";
import PageViewTracker from "./components/feature/PageViewTracker";
import { initAnalytics } from "./lib/analytics";


function App({ url }: { url?: string }) {
  const Router = url === undefined ? BrowserRouter : StaticRouter;
  useEffect(() => {
    initAnalytics();
  }, []);

  return (
    <I18nextProvider i18n={i18n}>
      <Router basename={__BASE_PATH__} location={url}>
        <ScrollManager />
        <PageViewTracker />
        <RequestModalProvider>
          <AppRoutes />
        </RequestModalProvider>
      </Router>
    </I18nextProvider>
  );
}

export default App;
