export const clinic = {
  name: 'Хелп18',
  logoMark: '18',
  city: 'Ижевск',
  tagline: 'Наркологическая помощь в Ижевске',
  phone: '+7 (965) 840-70-03',
  phoneHref: 'tel:+79658407003',
  phoneLabel: 'Приём обращений круглосуточно',
  workHours: 'Приём обращений — круглосуточно',
  legalName: 'ООО «Хелп18»',
  inn: '1831000000',
  ogrn: '0000000000000',
};

export const requisites = {
  legalName: clinic.legalName,
  inn: clinic.inn,
  ogrn: clinic.ogrn,
};

/**
 * Демонстрационные реквизиты. Перед публикацией заменить на фактические данные
 * медицинской организации — они не должны расходиться с регистрационными сведениями.
 */
export const isDemoData = true;

export const navigation = [
  { label: 'Услуги', href: '/uslugi/', hasDropdown: true },
  { label: 'Цены', href: '/ceny/' },
  { label: 'Врачи', href: '/vrachi/' },
  { label: 'О клинике', href: '/o-klinike/' },
  { label: 'Статьи', href: '/stati/' },
  { label: 'Контакты', href: '/kontakty/' },
];

export const serviceMenu = [
  {
    title: 'Нарколог на дом',
    href: '/narkolog-na-dom/',
    icon: 'ri-home-heart-line',
    description: 'Выезд врача по Ижевску',
  },
  {
    title: 'Вывод из запоя',
    href: '/vyvod-iz-zapoya/',
    icon: 'ri-heart-pulse-line',
    description: 'Помощь на дому и в стационаре',
  },
  {
    title: 'Капельницы',
    href: '/kapelnicy/',
    icon: 'ri-drop-line',
    description: 'Инфузионная терапия по показаниям',
  },
  {
    title: 'Кодирование от алкоголизма',
    href: '/kodirovanie/',
    icon: 'ri-shield-check-line',
    description: 'Медикаментозные методы',
  },
  {
    title: 'Лечение алкоголизма',
    href: '/lechenie-alkogolizma/',
    icon: 'ri-mental-health-line',
    description: 'Программа с наблюдением врача',
  },
  {
    title: 'Лечение наркомании',
    href: '/lechenie-narkomanii/',
    icon: 'ri-medicine-bottle-line',
    description: 'Диагностика и сопровождение',
  },
  {
    title: 'Стационар',
    href: '/stacionar/',
    icon: 'ri-hospital-line',
    description: 'Круглосуточное медицинское наблюдение',
  },
  {
    title: 'Консультация нарколога',
    href: '/konsultaciya-narkologa/',
    icon: 'ri-chat-3-line',
    description: 'Ответы врача на ваши вопросы',
  },
];

export const services = [
  {
    title: 'Нарколог на дом',
    href: '/narkolog-na-dom/',
    icon: 'ri-home-heart-line',
    description:
      'Вызов врача-нарколога для осмотра и оказания медицинской помощи по месту нахождения пациента, если его состояние допускает лечение вне стационара.',
    linkLabel: 'Подробнее об услуге',
    priority: true,
  },
  {
    title: 'Вывод из запоя',
    href: '/vyvod-iz-zapoya/',
    icon: 'ri-heart-pulse-line',
    description:
      'Медицинская помощь при прекращении длительного употребления алкоголя. Врач оценивает состояние, риски осложнений и необходимость лечения дома или в стационаре.',
    linkLabel: 'Подробнее о выводе из запоя',
    priority: true,
  },
  {
    title: 'Капельницы при алкогольной интоксикации',
    href: '/kapelnicy/',
    icon: 'ri-drop-line',
    description:
      'Инфузионная терапия по медицинским показаниям. Необходимость процедуры, состав растворов и условия проведения определяются врачом после осмотра.',
    linkLabel: 'Подробнее о капельницах',
  },
  {
    title: 'Кодирование от алкоголизма',
    href: '/kodirovanie/',
    icon: 'ri-shield-check-line',
    description:
      'Консультация врача по доступным методам лечения алкогольной зависимости. Выбор метода проводится с учётом показаний, противопоказаний и информированного согласия пациента.',
    linkLabel: 'Узнать о методах',
  },
  {
    title: 'Лечение алкоголизма',
    href: '/lechenie-alkogolizma/',
    icon: 'ri-mental-health-line',
    description:
      'Диагностика алкогольной зависимости, разработка индивидуального плана лечения и рекомендации по дальнейшей медицинской и психологической помощи.',
    linkLabel: 'Подробнее о лечении',
  },
  {
    title: 'Лечение наркомании',
    href: '/lechenie-narkomanii/',
    icon: 'ri-medicine-bottle-line',
    description:
      'Медицинская помощь пациентам с наркотической зависимостью, оценка состояния и подбор дальнейшего лечения с учётом клинической ситуации.',
    linkLabel: 'Подробнее об услуге',
  },
  {
    title: 'Наркологический стационар',
    href: '/stacionar/',
    icon: 'ri-hospital-line',
    description:
      'Наблюдение и лечение в медицинской организации при состояниях, требующих круглосуточного контроля или проведения процедур в условиях стационара.',
    linkLabel: 'Условия стационара',
  },
  {
    title: 'Консультация нарколога',
    href: '/konsultaciya-narkologa/',
    icon: 'ri-chat-3-line',
    description:
      'Консультация специалиста по вопросам алкогольной и наркотической зависимости, оценке состояния пациента и выбору дальнейшей тактики медицинской помощи.',
    linkLabel: 'Записаться на консультацию',
  },
];

export const trustPoints = [
  {
    title: 'Помощь на дому и в стационаре',
    description: 'Формат помощи определяется состоянием пациента и показаниями.',
    icon: 'ri-home-heart-line',
  },
  {
    title: 'Специалисты с подтверждённой квалификацией',
    description: 'Приём ведут врачи психиатры-наркологи с действующими сертификатами.',
    icon: 'ri-user-star-line',
  },
  {
    title: 'Врачебная тайна',
    description: 'Соблюдаем требования законодательства о защите медицинских данных.',
    icon: 'ri-lock-2-line',
  },
  {
    title: 'Прозрачные условия',
    description: 'Стоимость и объём помощи обсуждаются до начала лечения.',
    icon: 'ri-file-list-3-line',
  },
];

export const situations = [
  {
    title: 'Человек находится в запое',
    description:
      'Употребление алкоголя продолжается несколько дней, возникают трудности с прекращением употребления или выраженное ухудшение самочувствия. В такой ситуации необходима оценка состояния и рисков осложнений.',
    linkLabel: 'Помощь при запое',
    href: '/vyvod-iz-zapoya/',
    icon: 'ri-time-line',
  },
  {
    title: 'Сильное недомогание после алкоголя',
    description:
      'После употребления спиртного беспокоят тошнота, головная боль, слабость и другие симптомы. Врач поможет оценить состояние и определить, требуется ли медицинская помощь.',
    linkLabel: 'Подробнее о помощи',
    href: '/kapelnicy/',
    icon: 'ri-thermometer-line',
  },
  {
    title: 'Тяжело прекратить употребление алкоголя',
    description:
      'После уменьшения дозы или прекращения употребления возникают дрожь, потливость, тревога, нарушения сна и другие симптомы. Алкогольная абстиненция может сопровождаться опасными осложнениями.',
    linkLabel: 'Вывод из запоя',
    href: '/vyvod-iz-zapoya/',
    icon: 'ri-pulse-line',
  },
  {
    title: 'Нужна помощь близкому человеку',
    description:
      'Родственник употребляет алкоголь, отказывается обсуждать лечение или не знает, как обратиться за медицинской помощью. Близкие могут получить консультацию о возможных дальнейших действиях.',
    linkLabel: 'Консультация нарколога',
    href: '/konsultaciya-narkologa/',
    icon: 'ri-hand-heart-line',
  },
  {
    title: 'Необходимо лечение зависимости',
    description:
      'Человек хочет сократить или прекратить употребление алкоголя и получить профессиональную помощь. Нарколог может оценить состояние и обсудить варианты дальнейшего лечения.',
    linkLabel: 'Лечение алкоголизма',
    href: '/lechenie-alkogolizma/',
    icon: 'ri-mental-health-line',
  },
  {
    title: 'Нужна консультация по формату помощи',
    description:
      'Не всегда понятно, достаточно ли помощи дома или необходимо лечение в стационаре. Решение зависит от состояния пациента, медицинских показаний и возможных осложнений.',
    linkLabel: 'Получить консультацию',
    href: '/konsultaciya-narkologa/',
    icon: 'ri-question-line',
  },
];

export const processSteps = [
  {
    title: 'Обращение',
    description:
      'Вы звоните или оставляете заявку. Специалист уточняет ситуацию, состояние человека и адрес выезда.',
  },
  {
    title: 'Согласование',
    description:
      'Обсуждаются условия выезда, объём помощи и ориентировочная стоимость. Решение остаётся за вами.',
  },
  {
    title: 'Осмотр врача',
    description:
      'Врач приезжает, измеряет показатели, собирает анамнез и оценивает, какая помощь показана.',
  },
  {
    title: 'Медицинская помощь',
    description:
      'Процедуры выполняются по медицинским показаниям и с согласия пациента, в том числе информированного.',
  },
  {
    title: 'Рекомендации',
    description:
      'Врач объясняет дальнейшие шаги: наблюдение, консультация, стационар или план лечения.',
  },
];

export const doctors = [
  {
    name: 'Андрей Валерьевич Ковалёв',
    role: 'Психиатр-нарколог, высшая категория',
    experience: 'Стаж более 18 лет',
    focus: 'Помощь на дому, вывод из запоя, кодирование',
    photo:
      'https://readdy.ai/api/search-image?query=Professional%20portrait%20of%20a%20calm%20male%20doctor%20of%20Eastern%20European%20Slavic%20appearance%20in%20his%20late%20forties%2C%20light%20brown%20hair%2C%20light%20eyes%2C%20wearing%20a%20white%20medical%20coat%20over%20a%20light%20shirt%2C%20soft%20teal%20studio%20background%2C%20natural%20window%20light%2C%20clean%20modern%20medical%20editorial%20photography%2C%20neutral%20expression%2C%20high%20detail&width=600&height=700&seq=doctor-kovalev-01&orientation=portrait&nocache=true',
  },
  {
    name: 'Марина Сергеевна Игнатьева',
    role: 'Психиатр-нарколог, кандидат медицинских наук',
    experience: 'Стаж более 14 лет',
    focus: 'Консультации, лечение алкогольной зависимости',
    photo:
      'https://readdy.ai/api/search-image?query=Professional%20portrait%20of%20a%20friendly%20female%20doctor%20of%20Eastern%20European%20Slavic%20appearance%20in%20her%20early%20forties%2C%20light%20brown%20hair%20pulled%20back%2C%20fair%20skin%2C%20wearing%20a%20white%20medical%20coat%2C%20soft%20teal%20studio%20background%2C%20natural%20window%20light%2C%20clean%20modern%20medical%20editorial%20photography%2C%20warm%20confident%20expression%2C%20high%20detail&width=600&height=700&seq=doctor-ignatyeva-01&orientation=portrait&nocache=true',
  },
  {
    name: 'Дмитрий Александрович Соколов',
    role: 'Врач психиатр-нарколог',
    experience: 'Стаж более 11 лет',
    focus: 'Стационар, помощь при интоксикации',
    photo:
      'https://readdy.ai/api/search-image?query=Professional%20portrait%20of%20a%20male%20doctor%20of%20Eastern%20European%20Slavic%20appearance%20in%20his%20late%20thirties%2C%20short%20dark%20blond%20hair%2C%20fair%20skin%2C%20wearing%20a%20white%20medical%20coat%2C%20soft%20teal%20studio%20background%2C%20natural%20window%20light%2C%20clean%20modern%20medical%20editorial%20photography%2C%20thoughtful%20calm%20expression%2C%20high%20detail&width=600&height=700&seq=doctor-sokolov-01&orientation=portrait&nocache=true',
  },
];

export const footerServiceLinks = [
  { label: 'Нарколог на дом', href: '/narkolog-na-dom/' },
  { label: 'Вывод из запоя', href: '/vyvod-iz-zapoya/' },
  { label: 'Капельницы', href: '/kapelnicy/' },
  { label: 'Кодирование от алкоголизма', href: '/kodirovanie/' },
  { label: 'Лечение алкоголизма', href: '/lechenie-alkogolizma/' },
  { label: 'Лечение наркомании', href: '/lechenie-narkomanii/' },
  { label: 'Наркологический стационар', href: '/stacionar/' },
  { label: 'Консультация нарколога', href: '/konsultaciya-narkologa/' },
];

export const footerInfoLinks = [
  { label: 'Цены', href: '/ceny/' },
  { label: 'Врачи', href: '/vrachi/' },
  { label: 'О клинике', href: '/o-klinike/' },
  { label: 'Отзывы', href: '/otzyvy/' },
  { label: 'Статьи', href: '/stati/' },
  { label: 'Контакты', href: '/kontakty/' },
];

export const footerDocumentLinks = [
  { label: 'Сведения о медицинской организации', href: '/o-klinike/' },
  { label: 'Политика обработки персональных данных', href: '/privacy-policy/' },
  { label: 'Согласия и информация об обработке данных', href: '/privacy-policy/#consent' },
  { label: 'Информация о платных медицинских услугах', href: '/platnye-uslugi/' },
];

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  linkLabel?: string;
  linkHref?: string;
}

export const faqItems: FaqItem[] = [
  {
    id: 'faq-home-visit',
    question: 'Можно ли вызвать нарколога на дом в Ижевске?',
    answer:
      'Да, клиника предусматривает возможность вызова врача-нарколога на дом. Специалист уточнит адрес, состояние пациента и обстоятельства обращения. Возможность оказания помощи вне стационара определяется медицинскими показаниями и доступностью выезда по указанному адресу.',
  },
  {
    id: 'faq-zapoy-home',
    question: 'Можно ли вывести человека из запоя на дому?',
    answer:
      'В некоторых случаях медицинская помощь при прекращении длительного употребления алкоголя может оказываться на дому. Врач оценивает состояние пациента, выраженность симптомов и риски осложнений. Если требуется постоянное наблюдение или лечение в специальных условиях, может быть рекомендован стационар.',
  },
  {
    id: 'faq-price',
    question: 'Сколько стоит вызвать нарколога на дом?',
    answer:
      'Стоимость зависит от действующего прайс-листа клиники, условий выезда, осмотра и согласованного объёма медицинской помощи. Уточнить актуальные цены можно по телефону или на странице стоимости услуг.',
    linkLabel: 'Посмотреть цены',
    linkHref: '/ceny/',
  },
  {
    id: 'faq-drip',
    question: 'Обязательно ли ставить капельницу при запое?',
    answer:
      'Нет. Инфузионная терапия требуется не во всех случаях. Необходимость капельницы, состав препаратов и объём процедуры определяет врач после оценки состояния пациента и возможных противопоказаний.',
  },
  {
    id: 'faq-relative',
    question: 'Можно ли вызвать нарколога для родственника?',
    answer:
      'Родственники могут обратиться в клинику, получить информацию о доступных вариантах помощи и согласовать порядок консультации. Медицинское вмешательство, как правило, требует информированного добровольного согласия пациента. Исключения предусмотрены законодательством.',
  },
  {
    id: 'faq-privacy',
    question: 'Сохраняется ли конфиденциальность обращения?',
    answer:
      'Сведения об обращении за медицинской помощью и состоянии здоровья пациента защищаются законодательством о врачебной тайне и персональных данных. Условия оформления медицинской документации и предоставления сведений можно уточнить в клинике.',
  },
  {
    id: 'faq-format',
    question: 'Как понять, нужна помощь дома или в стационаре?',
    answer:
      'Формат помощи определяется врачом с учётом состояния пациента, тяжести симптомов, сопутствующих заболеваний и необходимости постоянного медицинского наблюдения. При определённых состояниях лечение на дому может быть небезопасным.',
  },
];