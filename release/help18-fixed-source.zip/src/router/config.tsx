import type { RouteObject } from 'react-router-dom';
import NotFound from '../pages/NotFound';
import Home from '../pages/home/page';
import ServicePage from '../pages/service/page';
import InfoPage from '../pages/info/page';
import PrivacyPolicy from '../pages/legal/PrivacyPolicy';
import PaidServices from '../pages/legal/PaidServices';
import { serviceDetails } from '@/mocks/services';

const routes: RouteObject[] = [
  {
    path: '/',
    element: <Home />,
  },
  {
    path: '/uslugi/',
    element: <InfoPage kind="services" />,
  },
  ...serviceDetails.map<RouteObject>((service) => ({
    path: service.slug,
    element: <ServicePage slug={service.slug} />,
  })),
  {
    path: '/ceny/',
    element: <InfoPage kind="prices" />,
  },
  {
    path: '/vrachi/',
    element: <InfoPage kind="doctors" />,
  },
  {
    path: '/o-klinike/',
    element: <InfoPage kind="about" />,
  },
  {
    path: '/otzyvy/',
    element: <InfoPage kind="reviews" />,
  },
  {
    path: '/stati/',
    element: <InfoPage kind="articles" />,
  },
  {
    path: '/kontakty/',
    element: <InfoPage kind="contacts" />,
  },
  {
    path: '/privacy-policy/',
    element: <PrivacyPolicy />,
  },
  {
    path: '/politika-konfidencialnosti/',
    element: <PrivacyPolicy />,
  },
  {
    path: '/platnye-uslugi/',
    element: <PaidServices />,
  },
  {
    path: '*',
    element: <NotFound />,
  },
];

export default routes;