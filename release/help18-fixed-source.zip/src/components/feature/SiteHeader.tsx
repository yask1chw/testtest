import { useEffect, useRef, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { clinic, navigation, serviceMenu } from '@/mocks/home';
import { useRequestModal } from '@/hooks/useRequestModal';
import { trackPhoneClick } from '@/lib/analytics';

export default function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mobileServicesOpen, setMobileServicesOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement | null>(null);
  const closeButtonRef = useRef<HTMLButtonElement | null>(null);
  const { openRequest } = useRequestModal();
  const location = useLocation();

  const isServicePath = serviceMenu.some(
    (item) => location.pathname === item.href || location.pathname.startsWith(item.href),
  );

  const isActive = (href: string) => location.pathname === href;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const onClick = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setServicesOpen(false);
      }
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  useEffect(() => {
    if (!mobileOpen) {
      return undefined;
    }

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setMobileOpen(false);
      }
    };

    document.addEventListener('keydown', onKeyDown);
    const timer = window.setTimeout(() => closeButtonRef.current?.focus(), 60);

    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener('keydown', onKeyDown);
      window.clearTimeout(timer);
    };
  }, [mobileOpen]);

  useEffect(() => {
    setMobileOpen(false);
    setServicesOpen(false);
  }, [location.pathname]);

  const handleOpenRequest = (sectionId: string) => {
    setMobileOpen(false);
    setServicesOpen(false);
    openRequest(sectionId);
  };

  return (
    <header className="sticky top-0 z-50">
      <div
        className={`hidden md:block bg-background-100 border-b border-background-200 overflow-hidden transition-all duration-300 ${
          scrolled ? 'max-h-0 opacity-0 border-transparent' : 'max-h-9 opacity-100'
        }`}
      >
        <div className="w-full px-4 md:px-8 xl:px-12 flex items-center justify-between h-9 text-[13px] text-foreground-600">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5">
              <i className="ri-stethoscope-line text-primary-600" aria-hidden="true" />
              Консультации специалистов
            </span>
            <span className="flex items-center gap-1.5">
              <i className="ri-time-line text-primary-600" aria-hidden="true" />
              {clinic.workHours}
            </span>
          </div>
          <div className="flex items-center gap-6">
            <Link to="/vrachi/" className="hover:text-primary-700 transition-colors">
              Врачи
            </Link>
            <Link to="/otzyvy/" className="hover:text-primary-700 transition-colors">
              Отзывы пациентов
            </Link>
          </div>
        </div>
      </div>

      <div
        className={`bg-background-50 border-b transition-all duration-300 ease-smooth ${
          scrolled ? 'border-background-200' : 'border-transparent'
        }`}
      >
        <div
          className={`w-full px-4 md:px-8 xl:px-12 flex items-center justify-between gap-4 transition-all duration-300 ease-smooth ${
            scrolled ? 'h-[64px]' : 'h-[72px] md:h-[78px]'
          }`}
        >
          <Link to="/" aria-label={`${clinic.name} — на главную`} className="flex items-center gap-2.5 shrink-0">
            <span className="w-10 h-10 rounded-lg bg-primary-600 flex items-center justify-center">
              <i className="ri-heart-pulse-line text-background-50 text-xl" aria-hidden="true" />
            </span>
            <span className="leading-tight">
              <span className="block font-heading font-extrabold text-[17px] text-foreground-950 tracking-tight">
                {clinic.name}
              </span>
              <span className="hidden sm:block text-[11.5px] text-foreground-600">
                Наркологическая помощь в Ижевске
              </span>
            </span>
          </Link>

          <nav className="hidden xl:flex items-center gap-1" aria-label="Основная навигация">
            <div
              className="relative"
              ref={dropdownRef}
              onMouseEnter={() => setServicesOpen(true)}
              onMouseLeave={() => setServicesOpen(false)}
            >
              <button
                type="button"
                onClick={() => setServicesOpen((prev) => !prev)}
                aria-expanded={servicesOpen}
                aria-haspopup="true"
                className={`flex items-center gap-1 px-3 py-2 text-[15px] transition-colors whitespace-nowrap cursor-pointer ${
                  isServicePath ? 'text-primary-800 font-medium' : 'text-foreground-800 hover:text-primary-700'
                }`}
              >
                Услуги
                <i
                  className={`ri-arrow-down-s-line text-base transition-transform ${
                    servicesOpen ? 'rotate-180' : ''
                  }`}
                  aria-hidden="true"
                />
              </button>

              {servicesOpen && (
                <div className="absolute left-0 top-full pt-3 w-[600px]">
                  <div className="bg-background-50 border border-background-200 rounded-lg p-3">
                    <div className="grid grid-cols-2 gap-1">
                    {serviceMenu.map((item) => (
                      <Link
                        key={item.href}
                        to={item.href}
                        onClick={() => setServicesOpen(false)}
                        className={`flex items-start gap-3 rounded-md p-2.5 hover:bg-primary-50 transition-colors group ${
                          location.pathname === item.href ? 'bg-primary-50' : ''
                        }`}
                      >
                        <span className="w-9 h-9 shrink-0 rounded-md bg-primary-100 flex items-center justify-center">
                          <i className={`${item.icon} text-primary-700 text-lg`} aria-hidden="true" />
                        </span>
                        <span className="min-w-0">
                          <span className="block text-[14px] font-medium text-foreground-950 group-hover:text-primary-800">
                            {item.title}
                          </span>
                          <span className="block text-[12px] text-foreground-600 mt-0.5 leading-snug">
                            {item.description}
                          </span>
                        </span>
                      </Link>
                    ))}
                    </div>
                    <Link
                      to="/uslugi/"
                      onClick={() => setServicesOpen(false)}
                      className="mt-2 flex items-center justify-between gap-2 border-t border-background-200 px-3 pt-3 pb-1 text-[13px] font-medium text-primary-800 hover:text-primary-900 transition-colors"
                    >
                      Все направления и услуги
                      <i className="ri-arrow-right-line" aria-hidden="true" />
                    </Link>
                  </div>
                </div>
              )}
            </div>

            {navigation.slice(1).map((item) => {
              const active = isActive(item.href);
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  aria-current={active ? 'page' : undefined}
                  className={`px-3 py-2 text-[15px] transition-colors whitespace-nowrap ${
                    active
                      ? 'text-primary-800 font-medium'
                      : 'text-foreground-800 hover:text-primary-700'
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="hidden xl:flex items-center gap-4 shrink-0">
            <a
              href={clinic.phoneHref}
              onClick={() => trackPhoneClick('header', 'header_phone')}
              className="text-right group"
            >
              <span className="block text-[11.5px] text-foreground-600">Круглосуточно</span>
              <span className="block font-heading font-bold text-[16px] text-foreground-950 group-hover:text-primary-700 transition-colors whitespace-nowrap">
                {clinic.phone}
              </span>
            </a>
            <button
              type="button"
              onClick={() => handleOpenRequest('header')}
              className="h-11 px-5 rounded-md bg-primary-600 text-background-50 text-[15px] font-medium flex items-center gap-2 hover:bg-primary-700 transition-colors whitespace-nowrap cursor-pointer"
            >
              <i className="ri-phone-line" aria-hidden="true" />
              Вызвать врача
            </button>
          </div>

          <div className="flex xl:hidden items-center gap-2">
            <a
              href={clinic.phoneHref}
              onClick={() => trackPhoneClick('mobile_header', 'mobile_header_phone')}
              aria-label={`Позвонить по номеру ${clinic.phone}`}
              className="w-11 h-11 rounded-md bg-primary-600 text-background-50 flex items-center justify-center"
            >
              <i className="ri-phone-line text-lg" aria-hidden="true" />
            </a>
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-label="Открыть меню"
              aria-expanded={mobileOpen}
              aria-controls="mobile-menu"
              className="w-11 h-11 rounded-md border border-background-300 flex items-center justify-center text-foreground-900 cursor-pointer"
            >
              <i className="ri-menu-2-line text-xl" aria-hidden="true" />
            </button>
          </div>
        </div>
      </div>

      {mobileOpen && (
        <div
          id="mobile-menu"
          role="dialog"
          aria-modal="true"
          aria-label="Меню сайта"
          className="xl:hidden fixed inset-0 z-[65] bg-background-50 flex flex-col"
        >
          <div className="flex items-center justify-between gap-3 px-4 h-[72px] border-b border-background-200 shrink-0">
            <Link to="/" onClick={() => setMobileOpen(false)} className="flex items-center gap-2.5">
              <span className="w-10 h-10 rounded-lg bg-primary-600 flex items-center justify-center">
                <span className="font-heading font-extrabold text-background-50 text-[15px] leading-none">
                  {clinic.logoMark}
                </span>
              </span>
              <span className="leading-tight">
                <span className="block font-heading font-extrabold text-[16px] text-foreground-950">
                  {clinic.name}
                </span>
                <span className="block text-[11px] text-foreground-600">Наркологическая помощь</span>
              </span>
            </Link>
            <button
              ref={closeButtonRef}
              type="button"
              onClick={() => setMobileOpen(false)}
              aria-label="Закрыть меню"
              className="w-11 h-11 rounded-md border border-background-300 flex items-center justify-center text-foreground-900 cursor-pointer"
            >
              <i className="ri-close-line text-xl" aria-hidden="true" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-4 py-3">
            <button
              type="button"
              onClick={() => setMobileServicesOpen((prev) => !prev)}
              aria-expanded={mobileServicesOpen}
              className="w-full flex items-center justify-between px-3 py-3.5 rounded-md text-[15.5px] font-medium text-foreground-950 cursor-pointer"
            >
              Услуги
              <i
                className={`ri-arrow-down-s-line text-xl transition-transform ${
                  mobileServicesOpen ? 'rotate-180' : ''
                }`}
                aria-hidden="true"
              />
            </button>
            {mobileServicesOpen && (
              <div className="pl-1 pb-2 space-y-0.5">
                <Link
                  to="/uslugi/"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-2.5 px-3 py-3 rounded-md text-[14px] font-medium text-primary-800 hover:bg-primary-50"
                >
                  <i className="ri-grid-line text-primary-700" aria-hidden="true" />
                  Все направления
                </Link>
                {serviceMenu.map((item) => (
                  <Link
                    key={item.href}
                    to={item.href}
                    onClick={() => setMobileOpen(false)}
                    className="flex items-center gap-2.5 px-3 py-3 rounded-md text-[14px] text-foreground-800 hover:bg-primary-50"
                  >
                    <i className={`${item.icon} text-primary-700`} aria-hidden="true" />
                    {item.title}
                  </Link>
                ))}
              </div>
            )}

            <nav aria-label="Разделы сайта" className="mt-1 border-t border-background-200 pt-1">
              {navigation.slice(1).map((item) => (
                <Link
                  key={item.href}
                  to={item.href}
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center justify-between px-3 py-3.5 rounded-md text-[15.5px] text-foreground-900 hover:bg-primary-50"
                >
                  {item.label}
                  <i className="ri-arrow-right-s-line text-foreground-400" aria-hidden="true" />
                </Link>
              ))}
              <Link
                to="/otzyvy/"
                onClick={() => setMobileOpen(false)}
                className="flex items-center justify-between px-3 py-3.5 rounded-md text-[15.5px] text-foreground-900 hover:bg-primary-50"
              >
                Отзывы
                <i className="ri-arrow-right-s-line text-foreground-400" aria-hidden="true" />
              </Link>
            </nav>
          </div>

          <div className="shrink-0 border-t border-background-200 px-4 py-3 space-y-2 bg-background-50">
            <p className="flex items-center gap-1.5 text-[11.5px] text-foreground-600">
              <i className="ri-time-line text-primary-600" aria-hidden="true" />
              {clinic.workHours}
            </p>
            <a
              href={clinic.phoneHref}
              onClick={() => trackPhoneClick('mobile_menu', 'mobile_menu_phone')}
              className="flex items-center justify-center gap-2 h-12 rounded-md border border-primary-300 text-primary-800 text-[15px] font-medium whitespace-nowrap"
            >
              <i className="ri-phone-line" aria-hidden="true" />
              {clinic.phone}
            </a>
            <button
              type="button"
              onClick={() => handleOpenRequest('mobile_menu')}
              className="w-full flex items-center justify-center gap-2 h-12 rounded-md bg-primary-600 text-background-50 text-[15px] font-medium whitespace-nowrap cursor-pointer"
            >
              Вызвать врача
            </button>
          </div>
        </div>
      )}
    </header>
  );
}