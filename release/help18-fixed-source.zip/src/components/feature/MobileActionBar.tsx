import { useEffect, useState } from 'react';
import { clinic } from '@/mocks/home';
import { useRequestModal } from '@/hooks/useRequestModal';
import { trackPhoneClick } from '@/lib/analytics';

/** Секции, рядом с которыми нижняя панель убирается, чтобы не закрывать формы. */
const HIDE_NEAR_SELECTOR = '#zayavka, #final-cta';

export default function MobileActionBar() {
  const { openRequest, isOpen } = useRequestModal();
  const [formVisible, setFormVisible] = useState(false);

  useEffect(() => {
    if (typeof IntersectionObserver === 'undefined') {
      return undefined;
    }

    const targets = Array.from(document.querySelectorAll<HTMLElement>(HIDE_NEAR_SELECTOR));
    if (targets.length === 0) {
      return undefined;
    }

    const visibleIds = new Set<Element>();

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            visibleIds.add(entry.target);
          } else {
            visibleIds.delete(entry.target);
          }
        });
        setFormVisible(visibleIds.size > 0);
      },
      { rootMargin: '0px 0px -12% 0px', threshold: 0.05 },
    );

    targets.forEach((target) => observer.observe(target));
    return () => observer.disconnect();
  }, []);

  // Панель скрывается, когда открыта модальная форма или видна форма в контенте.
  const hidden = formVisible || isOpen;

  return (
    <div
      className={`lg:hidden fixed bottom-0 left-0 right-0 z-40 border-t border-background-200 bg-background-50 transition-transform duration-300 ease-smooth ${
        hidden ? 'translate-y-full pointer-events-none' : 'translate-y-0'
      }`}
      aria-hidden={hidden}
    >
      <div className="flex items-center gap-2 px-3 py-2.5 pb-[max(10px,env(safe-area-inset-bottom))]">
        <a
          href={clinic.phoneHref}
          onClick={() => trackPhoneClick('mobile_bar', 'mobile_bar_call')}
          tabIndex={hidden ? -1 : undefined}
          className="flex-1 h-12 rounded-md border border-primary-300 bg-background-50 text-primary-800 text-[14.5px] font-medium flex items-center justify-center gap-2 whitespace-nowrap active:bg-primary-50 transition-colors"
        >
          <i className="ri-phone-line text-lg" aria-hidden="true" />
          Позвонить
        </a>
        <button
          type="button"
          onClick={() => openRequest('mobile_bar')}
          tabIndex={hidden ? -1 : undefined}
          className="flex-1 h-12 rounded-md bg-primary-600 text-background-50 text-[14.5px] font-medium flex items-center justify-center gap-2 whitespace-nowrap active:bg-primary-700 transition-colors cursor-pointer"
        >
          <i className="ri-send-plane-line text-base" aria-hidden="true" />
          Оставить заявку
        </button>
      </div>
    </div>
  );
}