import { RequestModalContext } from '@/hooks/useRequestModal';
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { Link } from 'react-router-dom';
import { clinic } from '@/mocks/home';
import useLeadForm from '@/hooks/useLeadForm';
import { LEAD_FORM_ENDPOINT } from '@/lib/lead';
import { trackOpenCallback, trackPhoneClick } from '@/lib/analytics';

export function RequestModalProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const phoneRef = useRef<HTMLInputElement | null>(null);
  const { status, errorMessage, successMessage, handleSubmit, reset } = useLeadForm({
    formId: 'request-modal-form',
    formName: 'Вызов нарколога на дом (модальное окно)',
    sectionId: 'request-modal',
  });

  const openRequest = useCallback(
    (sectionId?: string) => {
      reset();
      setIsOpen(true);
      trackOpenCallback(sectionId || 'request-modal', 'open_request_modal');
    },
    [reset],
  );

  const closeRequest = useCallback(() => {
    setIsOpen(false);
  }, []);

  useEffect(() => {
    if (!isOpen) {
      return undefined;
    }

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
      }
    };

    document.addEventListener('keydown', onKeyDown);
    const timer = window.setTimeout(() => phoneRef.current?.focus(), 80);

    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener('keydown', onKeyDown);
      window.clearTimeout(timer);
    };
  }, [isOpen]);

  const value = useMemo(
    () => ({ openRequest, closeRequest, isOpen }),
    [openRequest, closeRequest, isOpen],
  );

  return (
    <RequestModalContext.Provider value={value}>
      {children}

      {isOpen && (
        <div className="fixed inset-0 z-[70] flex items-start sm:items-center justify-center px-3 py-6 sm:p-4 overflow-y-auto">
          <button
            type="button"
            aria-label="Закрыть окно заявки"
            onClick={closeRequest}
            className="fixed inset-0 bg-foreground-950/55 cursor-pointer"
          />

          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="request-modal-title"
            className="relative w-full max-w-[460px] bg-background-50 rounded-lg border border-background-200 overflow-hidden animate-fade-up"
          >
            <button
              type="button"
              onClick={closeRequest}
              aria-label="Закрыть"
              className="absolute top-3 right-3 w-9 h-9 rounded-md flex items-center justify-center text-foreground-600 hover:bg-background-100 transition-colors cursor-pointer"
            >
              <i className="ri-close-line text-xl" aria-hidden="true" />
            </button>

            <div className="p-5 sm:p-6">
              <span className="inline-flex items-center gap-2 rounded-full bg-primary-50 px-3 py-1.5 text-[12px] font-medium text-primary-800">
                <i className="ri-phone-line" aria-hidden="true" />
                Обратный звонок
              </span>
              <h2
                id="request-modal-title"
                className="mt-3 font-heading font-extrabold text-[21px] leading-tight text-foreground-950 pr-8"
              >
                Вызов нарколога на дом
              </h2>
              <p className="mt-2 text-[13.5px] leading-relaxed text-foreground-600">
                Оставьте контактный номер. Специалист клиники свяжется с вами, уточнит ситуацию
                и расскажет об условиях выезда врача.
              </p>

              {status === 'success' ? (
                <div className="mt-5 rounded-md bg-primary-50 border border-primary-200 px-4 py-4">
                  <p className="flex items-start gap-2 text-[13.5px] leading-snug text-primary-900">
                    <i className="ri-checkbox-circle-line mt-0.5" aria-hidden="true" />
                    {successMessage}
                  </p>
                  <a
                    href={clinic.phoneHref}
                    className="mt-3 inline-flex items-center gap-2 text-[13.5px] font-medium text-primary-800 hover:text-primary-900"
                  >
                    <i className="ri-phone-line" aria-hidden="true" />
                    {clinic.phone}
                  </a>
                </div>
              ) : (
                <form
                  id="request-modal-form"
                  data-readdy-form
                  action={LEAD_FORM_ENDPOINT}
                  method="post"
                  onSubmit={handleSubmit}
                  className="mt-5 space-y-3.5"
                >
                  <input
                    type="text"
                    name="website_alt"
                    className="honeypot-field"
                    tabIndex={-1}
                    autoComplete="off"
                    aria-hidden="true"
                    readOnly
                  />

                  <div className="min-w-0">
                    <label
                      htmlFor="request-phone"
                      className="block text-[12.5px] text-foreground-700 mb-1.5"
                    >
                      Ваш телефон *
                    </label>
                    <input
                      ref={phoneRef}
                      id="request-phone"
                      name="phone"
                      type="tel"
                      required
                      autoComplete="tel"
                      placeholder="+7 (___) ___-__-__"
                      className="w-full box-border h-12 px-3.5 rounded-md border border-background-300 bg-background-50 text-[15px] text-foreground-950 placeholder:text-foreground-400 focus:outline-none focus:border-primary-400 focus:ring-2 focus:ring-primary-200"
                    />
                  </div>

                  <div className="min-w-0">
                    <label
                      htmlFor="request-comment"
                      className="block text-[12.5px] text-foreground-700 mb-1.5"
                    >
                      Комментарий
                    </label>
                    <textarea
                      id="request-comment"
                      name="comment"
                      rows={2}
                      maxLength={500}
                      placeholder="Коротко о ситуации, если считаете нужным"
                      className="w-full box-border px-3.5 py-2.5 rounded-md border border-background-300 bg-background-50 text-[14px] text-foreground-950 placeholder:text-foreground-400 focus:outline-none focus:border-primary-400 resize-none"
                    />
                  </div>

                  <label className="flex items-start gap-2.5 text-[12px] leading-relaxed text-foreground-600">
                    <input
                      type="checkbox"
                      name="consent"
                      value="yes"
                      required
                      className="mt-0.5 w-4 h-4 shrink-0 accent-primary-600"
                    />
                    <span>
                      Согласен с{' '}
                      <Link to="/privacy-policy/" className="text-primary-700 underline">
                        политикой обработки персональных данных
                      </Link>{' '}
                      и на обратный звонок по указанному номеру.
                    </span>
                  </label>

                  <button
                    type="submit"
                    disabled={status === 'sending'}
                    className="w-full h-12 rounded-md bg-primary-600 text-background-50 text-[15px] font-medium flex items-center justify-center gap-2 hover:bg-primary-700 transition-colors disabled:opacity-70 whitespace-nowrap cursor-pointer"
                  >
                    {status === 'sending' ? (
                      <>
                        <i className="ri-loader-4-line animate-spin" aria-hidden="true" />
                        Отправляем
                      </>
                    ) : (
                      <>
                        <i className="ri-send-plane-line" aria-hidden="true" />
                        Оставить заявку
                      </>
                    )}
                  </button>

                  {status === 'error' && (
                    <p
                      role="alert"
                      className="flex items-start gap-2 rounded-md bg-accent-50 border border-accent-300 px-3 py-2.5 text-[12.5px] leading-snug text-accent-900"
                    >
                      <i className="ri-error-warning-line mt-0.5" aria-hidden="true" />
                      {errorMessage}
                    </p>
                  )}

                  <p className="text-[11.5px] leading-relaxed text-foreground-500">
                    Конкретное время прибытия врача не гарантируется: оно зависит от загрузки
                    службы и адреса выезда. Возможность помощи на дому определяется состоянием
                    пациента.
                  </p>
                </form>
              )}
            </div>

            <div className="px-5 sm:px-6 py-3 bg-background-100 border-t border-background-200 flex items-center justify-between gap-3">
              <span className="text-[11.5px] text-foreground-600">{clinic.phoneLabel}</span>
              <a
                href={clinic.phoneHref}
                onClick={() => trackPhoneClick('request-modal', 'modal_phone')}
                className="inline-flex items-center gap-1.5 text-[13px] font-medium text-primary-800 hover:text-primary-900 whitespace-nowrap"
              >
                <i className="ri-phone-line" aria-hidden="true" />
                {clinic.phone}
              </a>
            </div>
          </div>
        </div>
      )}
    </RequestModalContext.Provider>
  );
}