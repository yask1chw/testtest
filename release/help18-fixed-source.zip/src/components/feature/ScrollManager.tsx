import { useLayoutEffect } from 'react';
import { useLocation } from 'react-router-dom';

export default function ScrollManager() {
  const { pathname, hash, search } = useLocation();
  useLayoutEffect(() => {
    const previous = window.history.scrollRestoration;
    window.history.scrollRestoration = 'manual';
    // CSS smooth scrolling must not carry the previous page position across navigation.
    const style = document.documentElement.style;
    const oldBehavior = style.scrollBehavior;
    style.scrollBehavior = 'auto';
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    style.scrollBehavior = oldBehavior;
    let frame = 0;
    if (hash) {
      frame = window.requestAnimationFrame(() => {
        let id = hash.slice(1);
        try { id = decodeURIComponent(id); } catch { /* Keep a malformed hash literal. */ }
        document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }
    return () => {
      window.cancelAnimationFrame(frame);
      window.history.scrollRestoration = previous;
    };
  }, [pathname, hash, search]);
  return null;
}
