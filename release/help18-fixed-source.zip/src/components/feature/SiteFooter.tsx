import { Link } from 'react-router-dom';
import {
  clinic,
  footerDocumentLinks,
  footerInfoLinks,
  footerServiceLinks,
  requisites,
} from '@/mocks/home';

export default function SiteFooter() {
  return (
    <footer className="bg-primary-950 text-background-100">
      <div className="max-w-content mx-auto px-4 md:px-6 pt-14 md:pt-16 pb-8 md:pb-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
          <div className="lg:pr-4">
            <Link to="/" className="flex items-center gap-2.5 group">
              <span className="w-10 h-10 rounded-lg bg-primary-600 flex items-center justify-center shrink-0">
                <span className="font-heading font-extrabold text-background-50 text-[15px] leading-none">
                  {clinic.logoMark}
                </span>
              </span>
              <span className="leading-tight">
                <span className="block font-heading font-extrabold text-[17px] text-background-50">
                  {clinic.name}
                </span>
                <span className="block text-[11.5px] text-primary-200">
                  Наркологическая помощь в Ижевске
                </span>
              </span>
            </Link>
            <p className="mt-4 text-[13px] leading-relaxed text-background-200">
              Наркологическая помощь в Ижевске. Консультации специалистов, помощь при запое
              и лечение зависимостей в рамках оказываемых медицинских услуг.
            </p>
            <a
              href={clinic.phoneHref}
              className="mt-5 inline-flex items-center gap-2 font-heading font-bold text-[19px] text-background-50 hover:text-primary-200 transition-colors whitespace-nowrap"
            >
              <i className="ri-phone-line text-primary-300" aria-hidden="true" />
              {clinic.phone}
            </a>
            <p className="mt-1.5 flex items-center gap-1.5 text-[12px] text-background-300">
              <i className="ri-time-line text-primary-300" aria-hidden="true" />
              {clinic.workHours}
            </p>

          </div>

          <div>
            <h4 className="font-heading font-semibold text-[13px] uppercase tracking-[0.12em] text-background-50">
              Услуги
            </h4>
            <ul className="mt-4 space-y-2.5">
              {footerServiceLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    to={link.href}
                    className="text-[13px] leading-snug text-background-200 hover:text-primary-200 transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-heading font-semibold text-[13px] uppercase tracking-[0.12em] text-background-50">
              Информация
            </h4>
            <ul className="mt-4 space-y-2.5">
              {footerInfoLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    to={link.href}
                    className="text-[13px] leading-snug text-background-200 hover:text-primary-200 transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-heading font-semibold text-[13px] uppercase tracking-[0.12em] text-background-50">
              Документы
            </h4>
            <ul className="mt-4 space-y-2.5">
              {footerDocumentLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    to={link.href}
                    className="text-[13px] leading-snug text-background-200 hover:text-primary-200 transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-primary-800">
          <div className="rounded-md bg-primary-900 px-4 py-3">
            <p className="text-[12.5px] leading-snug text-background-100">
              Имеются противопоказания. Необходима консультация специалиста.
            </p>
          </div>

          <dl className="mt-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-2 text-[11.5px] leading-snug text-background-300">
            <div>
              <dt className="inline text-background-400">Юридическое наименование: </dt>
              <dd className="inline">{requisites.legalName}</dd>
            </div>
            <div>
              <dt className="inline text-background-400">ИНН: </dt>
              <dd className="inline">{requisites.inn}</dd>
            </div>
            <div>
              <dt className="inline text-background-400">ОГРН: </dt>
              <dd className="inline">{requisites.ogrn}</dd>
            </div>

          </dl>

          <p className="mt-4 text-[11.5px] leading-relaxed text-background-400">
            Информация на сайте носит справочный характер и не является публичной офертой.
            Указанные цены не являются окончательными: объём помощи и стоимость согласуются
            после осмотра врача.
          </p>

          <div className="mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11.5px] text-background-400">
            <span>© 2026 {clinic.name}. Все права защищены.</span>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
              <Link to="/privacy-policy/" className="hover:text-primary-200 transition-colors">
                Политика обработки данных
              </Link>
              <Link to="/platnye-uslugi/" className="hover:text-primary-200 transition-colors">
                Платные услуги
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}