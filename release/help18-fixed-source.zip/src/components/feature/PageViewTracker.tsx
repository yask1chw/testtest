import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { trackPageView } from '@/lib/analytics';

/**
 * Отправляет просмотр виртуальной страницы при каждой смене маршрута SPA.
 * Заголовок берётся после того, как страница обновила метатеги.
 */
export default function PageViewTracker() {
  const { pathname, search } = useLocation();

  useEffect(() => {
    const path = `${pathname}${search}`;
    const timer = window.setTimeout(() => {
      trackPageView(path, document.title);
    }, 0);

    return () => window.clearTimeout(timer);
  }, [pathname, search]);

  return null;
}