import { useEffect, type ReactNode } from 'react';
import SiteHeader from '@/components/feature/SiteHeader';
import SiteFooter from '@/components/feature/SiteFooter';
import MobileActionBar from '@/components/feature/MobileActionBar';
import Breadcrumbs, { type BreadcrumbItem } from '@/components/base/Breadcrumbs';
import useDocumentMeta, { buildAbsoluteUrl } from '@/hooks/useDocumentMeta';
import { clinic } from '@/mocks/home';

interface PageShellProps {
  title: string;
  eyebrow?: string;
  description?: string;
  breadcrumbs: BreadcrumbItem[];
  metaTitle?: string;
  metaDescription?: string;
  canonicalPath?: string;
  children: ReactNode;
}

export default function PageShell({
  title,
  eyebrow,
  description,
  breadcrumbs,
  metaTitle,
  metaDescription,
  canonicalPath,
  children,
}: PageShellProps) {
  useDocumentMeta({
    title: metaTitle || `${title} | ${clinic.name}`,
    description:
      metaDescription ||
      description ||
      `${title} — наркологическая клиника ${clinic.name} в Ижевске. Консультация специалиста, условия и порядок обращения.`,
    canonicalPath,
  });

  const breadcrumbKey = JSON.stringify(breadcrumbs);

  useEffect(() => {
    const scriptId = 'breadcrumb-schema';
    document.getElementById(scriptId)?.remove();

    const items = JSON.parse(breadcrumbKey) as BreadcrumbItem[];
    if (items.length === 0) {
      return undefined;
    }

    const schema = {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: items.map((item, index) => ({
        '@type': 'ListItem',
        position: index + 1,
        name: item.label,
        ...(item.href ? { item: buildAbsoluteUrl(item.href) } : {}),
      })),
    };

    const script = document.createElement('script');
    script.id = scriptId;
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(schema);
    document.head.appendChild(script);

    return () => {
      document.getElementById(scriptId)?.remove();
    };
  }, [breadcrumbKey]);

  return (
    <div className="min-h-screen bg-background-50 flex flex-col pb-[76px] lg:pb-0">
      <a href="#main-content" className="skip-link">
        Перейти к основному содержанию
      </a>
      <SiteHeader />
      <main id="main-content" className="flex-1" tabIndex={-1}>
        <div className="bg-background-100 border-b border-background-200">
          <div className="max-w-content mx-auto px-4 md:px-6 py-6 md:py-8">
            <Breadcrumbs items={breadcrumbs} />
            {eyebrow && (
              <span className="mt-4 inline-flex items-center gap-2 text-[12px] font-medium uppercase tracking-[0.16em] text-primary-700">
                <span className="w-6 h-px bg-primary-400" aria-hidden="true" />
                {eyebrow}
              </span>
            )}
            <h1 className="mt-2.5 font-heading font-extrabold text-[26px] md:text-[36px] leading-[1.16] text-foreground-950 max-w-3xl">
              {title}
            </h1>
            {description && (
              <p className="mt-3 text-[14.5px] md:text-[16px] leading-relaxed text-foreground-600 max-w-2xl">
                {description}
              </p>
            )}
          </div>
        </div>

        <div className="max-w-content mx-auto px-4 md:px-6 py-10 md:py-14">{children}</div>
      </main>
      <SiteFooter />
      <MobileActionBar />
    </div>
  );
}