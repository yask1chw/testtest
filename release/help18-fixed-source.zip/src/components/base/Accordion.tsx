import { useState, type ReactNode } from 'react';

export interface AccordionItem {
  id: string;
  question: string;
  answer: ReactNode;
}

interface AccordionProps {
  items: AccordionItem[];
  /** Разрешить несколько открытых элементов одновременно */
  allowMultiple?: boolean;
}

export default function Accordion({ items, allowMultiple = true }: AccordionProps) {
  const [openIds, setOpenIds] = useState<string[]>([]);

  const toggle = (id: string) => {
    setOpenIds((prev) => {
      if (prev.includes(id)) {
        return prev.filter((item) => item !== id);
      }
      return allowMultiple ? [...prev, id] : [id];
    });
  };

  return (
    <div className="space-y-2.5 md:space-y-3">
      {items.map((item) => {
        const isOpen = openIds.includes(item.id);
        return (
          <div
            key={item.id}
            className="bg-background-50 border border-background-200 rounded-lg overflow-hidden transition-colors hover:border-primary-200"
          >
            <h3>
              <button
                type="button"
                onClick={() => toggle(item.id)}
                aria-expanded={isOpen}
                aria-controls={`accordion-panel-${item.id}`}
                id={`accordion-button-${item.id}`}
                className="w-full flex items-start justify-between gap-4 px-5 py-4 md:px-6 md:py-5 text-left cursor-pointer"
              >
                <span className="font-heading font-semibold text-[15px] md:text-[16px] leading-snug text-foreground-950">
                  {item.question}
                </span>
                <span
                  className={`w-7 h-7 shrink-0 rounded-full flex items-center justify-center transition-colors ${
                    isOpen ? 'bg-primary-100 text-primary-800' : 'bg-background-100 text-foreground-600'
                  }`}
                  aria-hidden="true"
                >
                  <i className={isOpen ? 'ri-subtract-line' : 'ri-add-line'} />
                </span>
              </button>
            </h3>
            <div
              id={`accordion-panel-${item.id}`}
              role="region"
              aria-labelledby={`accordion-button-${item.id}`}
              className={`grid transition-all duration-300 ease-smooth ${
                isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
              }`}
            >
              <div className="overflow-hidden">
                <div className="px-5 pb-5 md:px-6 md:pb-6 -mt-1 text-[13.5px] md:text-[14.5px] leading-relaxed text-foreground-700">
                  {item.answer}
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}