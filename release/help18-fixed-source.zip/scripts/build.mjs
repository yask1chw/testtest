import { build, loadEnv } from 'vite';
import { readFile, writeFile, mkdir, rm } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { pathToFileURL } from 'node:url';

const env = { ...loadEnv('production', process.cwd(), ''), ...process.env };
if (!env.VITE_SITE_ORIGIN) throw new Error('Set VITE_SITE_ORIGIN=https://your-domain in .env.production before building.');
const site = new URL(env.VITE_SITE_ORIGIN);
if (site.protocol !== 'https:' || site.pathname !== '/' || site.search || site.hash || site.username || site.password || site.hostname === 'example.com') {
  throw new Error('VITE_SITE_ORIGIN must be the real HTTPS origin without path/query/credentials.');
}
const origin = site.origin; // WHATWG URL converts Cyrillic hosts to ASCII punycode.
process.env.VITE_SITE_ORIGIN = origin;
if (env.BASE_PATH && env.BASE_PATH !== '/') throw new Error('This build deploys at the domain root: BASE_PATH must be /.');
const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
await build();
await build({ build: { ssr: 'src/entry-static.tsx', outDir: '.ssr', copyPublicDir: false, sourcemap: false } });
try {
  const { render, publicPaths } = await import(pathToFileURL(resolve('.ssr/entry-static.js')).href);
  const template = await readFile('out/index.html', 'utf8');
  const urls = [];
  const titles = new Set();
  const descriptions = new Set();
  for (const path of [...publicPaths, '/404.html']) {
    const { html, meta, faq } = render(path);
    if (!/<h1[\s>]/.test(html) || !/<h2[\s>]/.test(html)) throw new Error(`Incomplete HTML: ${path}`);
    const indexable = !meta.noindex && meta.canonicalPath === path;
    if (path !== '/404.html' && !indexable) throw new Error(`Unexpected noncanonical public page: ${path}`);
    if (indexable) {
      if (titles.has(meta.title) || descriptions.has(meta.description)) throw new Error(`Duplicate SEO: ${path}`);
      titles.add(meta.title); descriptions.add(meta.description); urls.push(origin + path);
    }
    let page = template.replace('<div id="root"></div>', `<div id="root">${html}</div>`);
    page = page.replace(/<title>[\s\S]*?<\/title>/, `<title>${escape(meta.title)}</title>`);
    function tag(attribute, key, value) {
      const pattern = new RegExp(`<meta\\s+${attribute}="${key}"[^>]*>`, 'g');
      const markup = `<meta ${attribute}="${key}" content="${escape(value)}" />`;
      page = pattern.test(page) ? page.replace(pattern, markup) : page.replace('</head>', `    ${markup}\n  </head>`);
    }
    tag('name', 'description', meta.description);
    tag('name', 'robots', indexable ? 'index, follow' : 'noindex, follow');
    for (const [prefix, attribute] of [['og', 'property'], ['twitter', 'name']]) {
      tag(attribute, `${prefix}:title`, meta.title);
      tag(attribute, `${prefix}:description`, meta.description);
    }
    page = page.replace(/<link rel="canonical"[^>]*>/g, indexable ? `<link rel="canonical" href="${escape(origin + path)}" />` : '');
    if (indexable) tag('property', 'og:url', origin + path);
    else page = page.replace(/<meta property="og:url"[^>]*>/g, '');
    if (env.VITE_PUBLIC_YANDEX_VERIFICATION) tag('name', 'yandex-verification', env.VITE_PUBLIC_YANDEX_VERIFICATION);
    const counter = env.VITE_PUBLIC_YANDEX_METRIKA_ID;
    if (counter) {
      if (!/^\d+$/.test(counter)) throw new Error('Invalid Metrika counter ID');
      page = page.replace('<body>', `<body>\n    <noscript><div><img src="https://mc.yandex.ru/watch/${counter}" style="position:absolute;left:-9999px" alt="" /></div></noscript>`);
    }
    if (faq.length) {
      const schema = { '@context':'https://schema.org', '@type':'FAQPage', mainEntity:faq.map(item => ({'@type':'Question',name:item.question,acceptedAnswer:{'@type':'Answer',text:item.answer}})) };
      page = page.replace('</head>', `<script id="faq-page-schema" type="application/ld+json">${JSON.stringify(schema).replace(/</g, '\\u003c')}</script>\n</head>`);
    }
    const file = path === '/404.html' ? 'out/404.html' : `out${path}index.html`;
    await mkdir(dirname(file), { recursive: true });
    await writeFile(file, page);
  }
  await writeFile('out/sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(url => `  <url><loc>${escape(url)}</loc></url>`).join('\n')}\n</urlset>\n`);
  await writeFile('out/urls-for-indexing.txt', urls.join('\n') + '\n');
  await writeFile('out/robots.txt', `User-agent: *\nAllow: /\nDisallow: /404.html\nDisallow: /search\n\nClean-param: utm_source&utm_medium&utm_campaign&utm_content&utm_term&yclid&gclid\n\nSitemap: ${origin}/sitemap.xml\n`);
  // Retain the old policy URL only as a redirect, never as an indexed duplicate.
  await mkdir('out/politika-konfidencialnosti', { recursive: true });
  await writeFile('out/politika-konfidencialnosti/index.html', `<!doctype html><html lang="ru"><head><meta charset="UTF-8"><meta name="robots" content="noindex, follow"><meta http-equiv="refresh" content="0;url=/privacy-policy/"><link rel="canonical" href="${origin}/privacy-policy/"><title>Переход к политике обработки персональных данных</title></head><body><a href="/privacy-policy/">Политика обработки персональных данных</a></body></html>`);
  console.log(`Static generation complete: ${urls.length} public pages + 404 + policy redirect. Origin: ${origin}`);
} finally {
  await rm('.ssr', { recursive: true, force: true });
}
