import json
from pathlib import Path
from playwright.sync_api import sync_playwright
base='http://127.0.0.1:8081'
results=[]
import xml.etree.ElementTree as ET
from urllib.parse import urlsplit
paths=[urlsplit(e.text).path for e in ET.parse('out/sitemap.xml').findall('.//{*}loc')]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 context=browser.new_context(viewport={'width':1440,'height':1000})
 # Network integrations are not invoked by these UI checks.
 context.route('https://**/*',lambda route: route.abort())
 page=context.new_page();errors=[]
 page.on('pageerror',lambda error:errors.append(str(error)))
 page.on('console',lambda msg: errors.append(msg.text) if msg.type=='error' and 'Failed to load resource' not in msg.text else None)
 for path in paths:
  response=page.goto(base+path,wait_until='networkidle')
  assert response.status==200
  assert page.locator('h1').count()==1
  assert page.locator('link[rel="canonical"]').get_attribute('href').startswith('https://xn--18-mlcyu7a.xn--p1ai/')
  results.append({'path':path,'hydrated':True,'h1':page.locator('h1').inner_text()})
 page.goto(base+'/',wait_until='networkidle')
 first=page.locator('#faq button[aria-expanded]').first
 first.click();assert first.get_attribute('aria-expanded')=='true'
 first.click();assert first.get_attribute('aria-expanded')=='false'
 # Navigate from the bottom using the actual React footer link.
 page.evaluate("document.documentElement.style.scrollBehavior='auto'; window.scrollTo(0,document.body.scrollHeight)")
 assert page.evaluate('window.scrollY')>1000
 link=page.locator('footer a[href="/ceny/"]').first
 link.click();page.wait_for_url('**/ceny/');page.wait_for_timeout(300)
 assert page.evaluate('window.scrollY')==0,page.evaluate('window.scrollY')
 # Direct refresh must preserve the page and hydrate again.
 page.reload(wait_until='networkidle');assert 'Цены' in page.locator('h1').inner_text()
 # Anchor navigation still works.
 page.locator('a[href^="#"]').filter(has_text='Вызов').first.click()
 page.wait_for_timeout(700)
 assert page.evaluate('window.scrollY')>0
 # Request modal remains interactive; do not send a real lead.
 page.goto(base+'/narkolog-na-dom/',wait_until='networkidle')
 page.get_by_role('button',name='Оставить заявку',exact=True).click()
 assert page.get_by_role('dialog').is_visible()
 page.keyboard.press('Escape');assert page.get_by_role('dialog').count()==0
 assert not errors,errors
 context.close()
 context=browser.new_context(java_script_enabled=False)
 page=context.new_page()
 for path in paths:
  page.goto(base+path,wait_until='domcontentloaded')
  assert page.locator('h1').count()==1
  assert len(page.locator('main').inner_text())>500
 browser.close()
print(json.dumps({'pages':results,'errors':errors,'faq':'passed','scroll_to_top':'passed','anchors':'passed','modal':'passed','no_javascript':'passed'},ensure_ascii=False,indent=2))
