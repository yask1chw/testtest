import urllib.request,urllib.error,urllib.parse,json,xml.etree.ElementTree as ET
from pathlib import Path
base='http://127.0.0.1:8082'
urls=[e.text for e in ET.parse('out/sitemap.xml').findall('.//{*}loc')]
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs): return None
opener=urllib.request.build_opener(NoRedirect)
def request(path,expected,location=None):
 try:r=opener.open(base+path)
 except urllib.error.HTTPError as e:r=e
 html=r.read().decode(errors='replace')
 assert r.code==expected,(path,r.code,html[:400])
 if location:assert urllib.parse.urlsplit(r.headers['Location']).path==location,(path,r.headers)
 return {'path':path,'status':r.code,'location':r.headers.get('Location')}
results=[]
for url in urls:
 path=urllib.parse.urlsplit(url).path
 results.append(request(path,200))
 if path!='/':results.append(request(path.rstrip('/'),301,path))
 results.append(request(path+'index.html',301,path))
for path in ['/does-not-exist/','/stati/not-a-real-article/','/assets/missing.js']:
 results.append(request(path,404))
results.append(request('/politika-konfidencialnosti/',301,'/privacy-policy/'))
results.append(request('/politika-konfidencialnosti',301,'/privacy-policy/'))
for p in Path('out/assets').rglob('*'):
 if p.is_file():results.append(request('/'+p.relative_to('out').as_posix(),200))
Path('validation-apache.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(f'Apache checks passed: {len(urls)} public pages return 200; canonical 301 redirects, trailing slashes, assets and true 404 checked ({len(results)} requests).')
