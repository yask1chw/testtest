import os,json,re,urllib.request,urllib.parse,xml.etree.ElementTree as ET
from pathlib import Path
from html.parser import HTMLParser
class Page(HTMLParser):
 def __init__(self):
  super().__init__(); self.tags=[];self.text=[]
 def handle_starttag(self,tag,attrs): self.tags.append((tag,dict(attrs)))
 def handle_data(self,data): self.text.append(data)
root=Path(__file__).resolve().parents[1]/'out'
base=os.environ.get('CHECK_BASE_URL','http://127.0.0.1:8081').rstrip('/')
urls=[e.text for e in ET.parse(root/'sitemap.xml').findall('.//{*}loc')]
assert len(urls)==len(set(urls))
assert urls==(root/'urls-for-indexing.txt').read_text().splitlines()
results=[];external=set();assets=set(); titles=set();descriptions=set()
for url in urls:
 path=urllib.parse.urlsplit(url).path
 response=urllib.request.urlopen(base+path);assert response.status==200
 html=response.read().decode(); p=Page();p.feed(html)
 assert html.lower().startswith('<!doctype html>') and '<html lang="ru">' in html
 assert '<div id="root"></div>' not in html
 assert sum(t=='h1' for t,a in p.tags)==1
 assert any(t=='h2' for t,a in p.tags)
 assert len(' '.join(p.text))>1000 and 'Страница не найдена' not in html
 title=re.search('<title>(.*?)</title>',html).group(1);assert title not in titles;titles.add(title)
 desc=[a['content'] for t,a in p.tags if t=='meta' and a.get('name')=='description'];assert len(desc)==1 and desc[0] not in descriptions;descriptions.add(desc[0])
 assert [a['href'] for t,a in p.tags if t=='link' and a.get('rel')=='canonical']==[url]
 assert [a['content'] for t,a in p.tags if t=='meta' and a.get('name')=='robots']==['index, follow']
 for tag,a in p.tags:
  value=a.get('src') or (a.get('href') if tag in ('a','link') else None)
  if not value or value.startswith(('tel:','mailto:','#','data:')):continue
  target=urllib.parse.urlsplit(urllib.parse.urljoin(url,value))
  if target.netloc!=urllib.parse.urlsplit(url).netloc: external.add(value);continue
  local=target.path
  if local.startswith('/assets/'): assets.add(local)
  elif tag=='a':
   assert local in [urllib.parse.urlsplit(u).path for u in urls]+['/politika-konfidencialnosti/'],(path,local)
   if target.fragment:
    linked=Page();linked.feed((root/local.lstrip('/')/'index.html').read_text() if local!='/' else (root/'index.html').read_text())
    assert any(a.get('id')==urllib.parse.unquote(target.fragment) for t,a in linked.tags),(path,value)
 for asset in assets:
  assert (root/asset.lstrip('/')).is_file(),asset
  assert urllib.request.urlopen(base+asset).status==200
 results.append({'url':url,'http':response.status,'h1':1,'title':title,'html_bytes':len(html.encode())})
print(json.dumps({'pages':results,'local_assets':sorted(assets),'external_resources':sorted(external)},ensure_ascii=False,indent=2))
(root.parent/'validation-http.json').write_text(json.dumps({'pages':results,'local_assets':sorted(assets),'external_resources':sorted(external)},ensure_ascii=False,indent=2))
