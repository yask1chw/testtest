<?php
// REG.RU: PHP 8+, local mail transport. Recipient is fixed on the server.
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
function respond(int $status, string $code, string $message): void {
    http_response_code($status);
    echo json_encode(['code'=>$code,'data'=>null,'meta'=>['message'=>$message]], JSON_UNESCAPED_UNICODE);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST'); respond(405,'METHOD','Используйте форму на сайте.');
}
if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0)>16384) respond(413,'SIZE','Слишком длинное сообщение.');
$contentType = strtolower(explode(';', $_SERVER['CONTENT_TYPE'] ?? '')[0]);
if ($contentType !== 'application/x-www-form-urlencoded') respond(415,'TYPE','Неподдерживаемый формат.');
$host = strtolower(explode(':', $_SERVER['HTTP_HOST'] ?? '')[0]);
if (!preg_match('/^[a-z0-9.-]+$/', $host)) respond(400,'HOST','Некорректный адрес сайта.');
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin !== '' && strtolower((string)parse_url($origin,PHP_URL_HOST)) !== $host) respond(403,'ORIGIN','Отправьте форму с сайта.');
function field(string $name, int $max=500): string {
    $value = $_POST[$name] ?? '';
    if (!is_string($value) || strlen($value)>$max*4 || !preg_match('//u',$value)) respond(422,'FIELD','Проверьте заполненные поля.');
    return trim(str_replace("\0",'', $value));
}
if (field('website_alt') !== '') respond(422,'SPAM','Не удалось отправить заявку.');
$phone = field('phone',40);
$digits = preg_replace('/\D/','',$phone);
if (!preg_match('/^[+\d\s()\-]+$/',$phone) || strlen($digits)<10 || strlen($digits)>15) respond(422,'PHONE','Укажите корректный номер телефона.');
$name = field('name',100);
$form = field('form_key',40);
$allowedForms = ['lead','consultation','product-inquiry','leasing','delivery','service','contact','quick-select','parts'];
if (!in_array($form,$allowedForms,true)) respond(422,'FORM','Неизвестная форма.');
$labels=['name'=>'Имя','phone'=>'Телефон','comment'=>'Комментарий','topic'=>'Тема','equipment_type'=>'Тип техники','task'=>'Задача','product'=>'Модель','category'=>'Категория','product_name'=>'Модель','product_id'=>'ID товара','product_slug'=>'Адрес товара','product_url'=>'Страница товара','page_url'=>'Страница','page_title'=>'Заголовок страницы'];
$body="Новая заявка с сайта РусТрак Трейд\nФорма: ".$form."\nДата UTC: ".gmdate('c')."\n";
foreach ($labels as $key=>$label) {
    $value=field($key,$key==='page_url'||$key==='product_url'?2000:500);
    if ($value!=='') $body.=$label.': '.$value."\n";
}
foreach (['utm_source','utm_medium','utm_campaign','utm_content','utm_term'] as $key) {
    $value=field($key,200); if ($value!=='') $body.=$key.': '.$value."\n";
}
// Lock per IP across requests; store only a hash/timestamp outside the public root.
$dir=sys_get_temp_dir().'/rustrak-lead-'.hash('sha256', __DIR__);
if (!is_dir($dir) && !@mkdir($dir,0700,true) && !is_dir($dir)) respond(503,'STORAGE','Отправка временно недоступна. Позвоните 8 800 777-36-07.');
$file=$dir.'/'.hash('sha256',$_SERVER['REMOTE_ADDR']??'unknown');
$lock=@fopen($file,'c+');
if (!$lock || !flock($lock,LOCK_EX)) respond(503,'LOCK','Попробуйте позже.');
$last=(int)stream_get_contents($lock);
if ($last>time()-30) {fclose($lock);respond(429,'RATE','Подождите 30 секунд перед повторной отправкой.');}
$recipient='rustrak@valmo.trade';
$sender='noreply@xn-----8kc4aadmjclgjxdzd.xn--p1ai';
$subject='=?UTF-8?B?'.base64_encode('Заявка с сайта РусТрак Трейд').'?=';
$headers=['From'=>'=?UTF-8?B?'.base64_encode('РусТрак Трейд').'?= <'.$sender.'>','MIME-Version'=>'1.0','Content-Type'=>'text/plain; charset=UTF-8','Content-Transfer-Encoding'=>'base64'];
$ok=function_exists('mail') && @mail($recipient,$subject,chunk_split(base64_encode($body)),$headers);
if ($ok) {rewind($lock);ftruncate($lock,0);fwrite($lock,(string)time());}
flock($lock,LOCK_UN);fclose($lock);
if (!$ok) respond(503,'MAIL','Не удалось отправить заявку. Позвоните 8 800 777-36-07.');
respond(200,'OK','Заявка передана почтовому серверу.');
