from pathlib import Path
from lxml import html,etree
import json,hashlib,gzip
root=Path(__file__).resolve().parents[1];site=root/'site';origin='https://xn--18-6kcd5a6i.xn--p1ai'
# Do not fabricate lastmod dates: no durable record history was supplied.
urls=[];rows=[]
for file in sorted(site.rglob('index.html')):
 route='/'+str(file.parent.relative_to(site)).replace('\\','/').strip('.')
 route=route.rstrip('/')+'/' if route!='/' else '/'
 doc=html.fromstring(file.read_text())
 robots=doc.xpath('//meta[@name="robots"]/@content')[0]
 canon=doc.xpath('//link[@rel="canonical"]/@href')[0]
 if 'noindex' not in robots and canon==origin+route:urls.append(canon)
 rows.append({'url':route,'title':doc.xpath('string(//title)'),'h1':doc.xpath('string(//h1)'),'robots':robots,'canonical':canon})
ns='http://www.sitemaps.org/schemas/sitemap/0.9';tree=etree.Element('{'+ns+'}urlset',nsmap={None:ns})
for url in urls:
 e=etree.SubElement(tree,'{'+ns+'}url');etree.SubElement(e,'{'+ns+'}loc').text=url
(site/'sitemap.xml').write_bytes(etree.tostring(tree,encoding='utf-8',xml_declaration=True,pretty_print=True))
(site/'urls-for-indexing.txt').write_text('\n'.join(urls)+'\n')
(site/'robots.txt').write_text('User-agent: *\nAllow: /\n\nUser-agent: Yandex\nAllow: /\nClean-param: utm_source&utm_medium&utm_campaign&utm_content&utm_term&yclid&gclid&fbclid\n\nSitemap: '+origin+'/sitemap.xml\n')
ht=(root/'original/.htaccess').read_text()
ht=ht.replace('RewriteEngine On','''RewriteEngine On

# Keep the canonical host in ASCII (IDN: базы18.рф).
RewriteCond %{HTTP_HOST} ^www\\.xn--18-6kcd5a6i\\.xn--p1ai(?::[0-9]+)?$ [NC]
RewriteRule ^ https://xn--18-6kcd5a6i.xn--p1ai%{REQUEST_URI} [R=301,L,NE]
''',1)
ht+='''
# Filter combinations remain crawlable so robots can read noindex.
# Tracking-only queries use the clean canonical page. Do not Disallow them.
<IfModule mod_headers.c>
  Header always set X-Robots-Tag "noindex, follow" "expr=%{QUERY_STRING} != '' && %{QUERY_STRING} !~ m#^(?:(?:utm_[a-z_]+|yclid|gclid|fbclid|_ym_uid|_ym_d)=[^&]*&?)*$#"
</IfModule>

# Cache policy: HTML must be revalidated; only the content-hashed JS is immutable.
<IfModule mod_headers.c>
  <FilesMatch "\\.html$">
    Header set Cache-Control "no-cache"
  </FilesMatch>
  <FilesMatch "^site-[a-f0-9]{12}\\.js$">
    Header set Cache-Control "public, max-age=31536000, immutable"
  </FilesMatch>
  <FilesMatch "\\.(css|svg)$">
    Header set Cache-Control "public, max-age=3600, must-revalidate"
  </FilesMatch>
</IfModule>
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/css application/javascript application/json application/ld+json application/xml image/svg+xml
</IfModule>
'''
(site/'.htaccess').write_text(ht)
(root/'reports/routes-after.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
print(f'Sitemap: {len(urls)} canonical indexable pages. Excluded: {len(rows)-len(urls)} routes.')
# Static hosting needs readable files; no executables or writable public files are added.
for item in site.rglob('*'):
 item.chmod(0o755 if item.is_dir() else 0o644)
site.chmod(0o755)
