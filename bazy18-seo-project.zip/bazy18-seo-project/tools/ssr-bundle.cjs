const path = require("node:path");
module.exports = async function () {
  const root = path.resolve(__dirname, "..");
  const result = await require("esbuild").build({
    stdin: {
      contents:
        "const {renderToString}=require('react-dom/server.browser');window.__SEO_RENDER_TO_STRING__=renderToString;",
      resolveDir: root,
    },
    bundle: true,
    platform: "browser",
    format: "iife",
    write: false,
    minify: true,
    charset: "utf8",
    legalComments: "inline",
    define: { "process.env.NODE_ENV": '"production"' },
    plugins: [
      {
        name: "same-react-instance",
        setup(build) {
          build.onResolve({ filter: /^react$/ }, () => ({
            path: "same-react-instance",
            namespace: "bridge",
          }));
          build.onLoad({ filter: /.*/, namespace: "bridge" }, () => ({
            contents: "module.exports=window.__SEO_REACT__;",
            loader: "js",
          }));
        },
      },
    ],
  });
  return result.outputFiles[0].text;
};
