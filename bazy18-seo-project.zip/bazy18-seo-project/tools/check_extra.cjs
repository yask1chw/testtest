const { chromium } = require("playwright");
const assert = require("node:assert/strict");
const fs = require("node:fs");
(async () => {
  const b = await chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
    args: ["--no-sandbox"],
  });
  const p = await b.newPage();
  await p.route("**/*", (r) =>
    r.request().url().startsWith("http://localhost:8766")
      ? r.continue()
      : r.abort(),
  );
  const counts = {};
  for (const [q, n] of [
    ["district=" + encodeURIComponent("Воткинский район"), 5],
    ["features=pets", 21],
    ["overnight=yes", 62],
    ["season=year", 69],
  ]) {
    await p.goto("http://localhost:8766/katalog/?" + q);
    await p.waitForFunction(() => window.REACT_APP_NAVIGATE);
    const count = Number(
      await p.locator("[data-result-count]").getAttribute("data-result-count"),
    );
    assert.equal(count, n, q);
    counts[q] = count;
  }
  await p.goto("http://localhost:8766/katalog/?capacity=20");
  await p.waitForFunction(() => window.REACT_APP_NAVIGATE);
  const count = Number(
    await p.locator("[data-result-count]").getAttribute("data-result-count"),
  );
  const data = JSON.parse(fs.readFileSync("reports/data-before.json"));
  assert.equal(count, data.details.filter((d) => d.capacityMax >= 20).length);
  assert.equal(await p.locator("main article").count(), count);
  counts["capacity=20"] = count;
  await b.close();
  fs.writeFileSync(
    "reports/extra-filter-checks.json",
    JSON.stringify({ passed: true, counts }, null, 2),
  );
  console.log(counts);
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
