const { spawn, spawnSync } = require("node:child_process");
const http = require("node:http");
const run = (command, args) => {
  const r = spawnSync(command, args, { stdio: "inherit" });
  if (r.status !== 0)
    throw Error(`${command} ${args.join(" ")} failed: ${r.status}`);
};
(async () => {
  run(process.execPath, ["tools/build.cjs"]);
  const server = spawn("python", ["tools/serve.py", "--port", "8766"], {
    stdio: ["ignore", "ignore", "pipe"],
  });
  let stderr = "";
  server.stderr.on("data", (b) => (stderr += b));
  try {
    await new Promise((resolve, reject) => {
      const start = Date.now();
      const poll = () => {
        if (server.exitCode !== null)
          return reject(Error("Preview server failed: " + stderr));
        http
          .get("http://localhost:8766/favicon.svg", (r) => {
            r.resume();
            resolve();
          })
          .on("error", () =>
            Date.now() - start > 10000
              ? reject(Error("Preview server not ready"))
              : setTimeout(poll, 150),
          );
      };
      poll();
    });
    run(process.execPath, ["tools/prerender.cjs"]);
    run("python", ["tools/finalize.py"]);
    run("python", ["tools/check_static.py"]);
  } finally {
    server.kill();
  }
})().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
