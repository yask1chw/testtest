from pathlib import Path
import json,csv,hashlib,gzip
root=Path(__file__).resolve().parents[1];out=root/'reports';before=json.loads((out/'data-before.json').read_text());after=json.loads((out/'data-after.json').read_text())
queries={'pool':'базы отдыха с бассейном Удмуртия','kids':'базы отдыха с детьми Удмуртия','banya':'базы отдыха с баней Удмуртия','water':'базы отдыха у воды Удмуртия','fishing':'базы отдыха с рыбалкой Удмуртия','hot-tub':'базы отдыха с чаном Удмуртия','pets':'отдых с собакой Удмуртия','budget':'недорогие базы отдыха Удмуртии','romance':'романтический отдых вдвоём Удмуртия','large-group':'базы отдыха для большой компании','weekend':'базы отдыха на выходные Удмуртия','glamping':'глэмпинги Удмуртии','forest':'домик в лесу Удмуртия','kama':'базы отдыха на Каме','near':'базы отдыха недалеко от Ижевска','near-votkinsk':'базы отдыха Воткинский район','near-sarapul':'базы отдыха Сарапул','daily-houses':'снять домик посуточно Удмуртия','winter':'базы отдыха зимой Удмуртия'}
with (out/'SEO-карта.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f,delimiter=';');w.writerow(['URL','Тип','Поисковый интент / гипотеза запроса','Подробных карточек','Кратких карточек','Индексация','Действие / ограничение'])
 w.writerow(['/','Главная','базы отдыха Удмуртия; куда поехать отдыхать в Удмуртии',10,59,'index','Основной общий кластер; без заявления о лидерстве'])
 w.writerow(['/katalog/','Каталог','подобрать базу отдыха по параметрам',10,59,'index только без функциональных параметров','Фильтры с canonical на /katalog/; noindex'])
 for c in after['configs']:
  w.writerow([c['slug'],'Существующая категория',queries.get(c['themeKey'],c['h1']),len(c['primary']),len(c['extra']),'index' if c['count'] else 'noindex','Сохранён URL; признаки из исходных данных' if c['count'] else 'Данные недостаточны; уточнить до включения в sitemap'])
 for b in after['details']:w.writerow([f"/bazy/{b['slug']}/",'Карточка',f"база отдыха {b['name']}; условия; фото; контакты",1,0,'index','Цены из исходного каталога; без гарантии актуальности'])
 for url,intent,action in [('/s-nochevkoy/','отдых с ночёвкой','Сначала уточнить тарифы и минимальный срок; оценить отличие от /domiki-posutochno/'),('/bazy-s-detskoy-ploshchadkoy/','базы отдыха с детской площадкой','Тег «Для детей» не подтверждает площадку: собрать отдельное поле'),('/ryadom-s-glazovom/','базы отдыха Глазов','Пока не создавать: нет достаточных структурированных сведений'),('/bazy-u-reki/','базы отдыха у реки','Расширить тип водоёма и подтверждения; не дублировать /bazy-na-kame/'),('/otdyh-na-sutki/','базы отдыха на сутки','Не создавать дубль /domiki-posutochno/ без самостоятельного интента')]:w.writerow([url,'Рекомендация, не создана',intent,'','','не создана',action])
issues=[
 ('Подборки показывали все 10 объектов независимо от темы, плюс фиксированные рекомендации','P0','70 тематических URL','Централизованный отбор по структурированным данным/тегам; удалён блок обязательного топ‑5','Исправлено в пакете'),
 ('Противоречие «Бассейн есть» / «Не подтверждён источником» и ложные подписи отсутствующих услуг','P0','/bazy/luhari/; все карточки','Единые подписи: true → конкретная услуга, неизвестное → уточнить','Исправлено в пакете'),
 ('Баллы качества и места без воспроизводимых доказательств, тексты о репутации без отзывов','P0','/; /rating/; /bazy/*; /metodika-reytinga/','Публичные баллы и места убраны; нейтральная сортировка; методика переписана','Исправлено в пакете'),
 ('Фильтр цены пропускал 59 дополнительных объектов без цен','P0','/katalog/?price=6000','Неизвестная цена исключает объект из выдачи с ограничением цены','Исправлено; браузерный тест'),
 ('Результаты фильтров могли индексироваться, параметры не отражали изменения UI','P1','/katalog/?*; категории ?scope=*','Состояние в URL, canonical без параметров, noindex в meta и заголовке Apache','Исправлено; Apache ещё проверить на staging'),
 ('Пустые/неподтверждённые сценарии выдавались за полноценные подборки','P1','Список в SEO-карте.csv','Существующие URL сохранены, нет фиктивных объектов, noindex и исключение из sitemap','Исправлено в пакете; перед публикацией сверить GSC/Вебмастер'),
 ('Устаревающие JSON-LD и OG при SPA-переходах','P1','Все маршруты','Очистка разметки при навигации, пересоздание метатегов, отдельные схемы списков/карточек','Исправлено; браузерный тест'),
 ('Некорректные поля checkinTime/checkoutTime с текстом «уточняется» и координаты без доказательств','P1','/bazy/*','В JSON-LD остались подтверждённые типы полей; точные geo исключены','Исправлено; внешняя валидация требуется'),
 ('Синтетические изображения показывались как фотографии 59 объектов','P1','Каталог; тематические страницы','Фото из источника сохранены; вместо генеративных fallback — нейтральная заглушка с подписью','Исправлено в пакете'),
 ('dataLayer не вызывал reachGoal Метрики; нет base_id в кликах','P1','Карточки и фильтры','reachGoal существующему счётчику, id объекта, события без персональных данных, защита StrictMode','Исправлено; получение в интерфейсе Метрики не проверено'),
 ('Карта не соответствовала фильтрованной выдаче; точные точки не подтверждены','P1','Каталог; категории; карточки; /karta/','Списки карты синхронизированы, поиск по названию/адресу; точные координаты не обещаются','Исправлено; подтверждённые координаты — следующий этап'),
 ('Нет исходного репозитория, конфигурации сборки, базы данных и CMS','P1','Архив целиком','Воспроизводимый патч фиксированной production-сборки; вернуть исправления в исходный репозиторий','Ограничение входных данных'),
 ('Нет provenance по отдельным полям; противоречивые theme/table/accommodations/services','P1','10 подробных + 59 кратких объектов','Не использовать неподтверждённые тематические таблицы; вести реестр доказательств по полям','Частично: интерфейс исправлен; редакционная проверка предстоит'),
 ('23 краткие карточки без сайта, нет подтверждённых телефонов объектов','P1','Краткие карточки каталога','Не выдумывать контакты; запросить владельцев и добавить проверенные ссылки/телефоны','Требуются данные'),
 ('HTTP/HTTPS, TLS, www, реальные 404/500 и настройки Apache недоступны live','P1','Production-домен','Подготовлен www→canonical; прямой HTTPS-блок отдельно; проверить TLS/proxy до активации','Не проверено live: прокси среды возвращает 403'),
 ('Нет доступа к Яндекс Вебмастеру, Search Console и статистике Метрики','P1','Production','Проверить фактическую индексацию, дубли, запросы и цели после доступа','Открыто; не подменено предположениями'),
 ('Тяжёлый монолитный JS, отсутствие подтверждённых полевых CWV','P2','/assets/*.js','Удалён неиспользуемый код сборщиком, минификация, lazy images, без тяжёлых карт по умолчанию','Частично: разделение кода и RUM требуют исходников/данных'),
 ('CSS/JS/HTML не имели явной политики кеша/сжатия в архиве','P2','/.htaccess','Хешированный JS immutable; HTML revalidate; CSS/SVG короткий кеш; DEFLATE при модуле','Подготовлено; проверить реальные заголовки на сервере'),
 ('Есть пересекающиеся интенты и страницы с малым числом объектов','P2','/romanticheskiy-otdyh/; /domiki-na-dvoih/ и др.','Сохранить URL; проверить каннибализацию по фактическим запросам до canonical/301','В плане; новых дублей не создано')]
with (out/'SEO-ошибки.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f,delimiter=';');w.writerow(['Проблема','Приоритет','URL','Решение','Статус']);w.writerows(issues)
# Static server redirect map is kept separate from canonical changes.
import re
ht=(root/'original/.htaccess').read_text()
with (out/'301-редиректы.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f,delimiter=';');w.writerow(['Исходный шаблон','Цель','Статус'])
 for a,b in re.findall(r'RewriteRule \^([^ ]+) (/[a-z0-9/-]+) \[R=301,L\]',ht):w.writerow([a,b,'Существовавший редирект сохранён'])
 w.writerow(['www.xn--18-6kcd5a6i.xn--p1ai/*','https://xn--18-6kcd5a6i.xn--p1ai/*','Подготовлен, не развёрнут'])
files=[]
for p in sorted((root/'site').rglob('*')):
 if p.is_file():
  rel=p.relative_to(root/'site');a=root/'original'/rel
  if not a.exists() or a.read_bytes()!=p.read_bytes():files.append({'file':str(rel),'before_sha256':hashlib.sha256(a.read_bytes()).hexdigest() if a.exists() else None,'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'changed-files.json').write_text(json.dumps(files,ensure_ascii=False,indent=2))
for p in sorted((root/'original').rglob('*')):
 if p.is_file() and not (root/'site'/p.relative_to(root/'original')).exists():files.append({'file':str(p.relative_to(root/'original')),'before_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'after_sha256':None,'reason':'Generated asset replaced by content-hashed bundle'})
(out/'changed-files.json').write_text(json.dumps(files,ensure_ascii=False,indent=2))
# Explicitly group semantic hypotheses; no search volume is implied.
geo={'near','near-votkinsk','near-sarapul','kama','forest','water','shore-houses'}
amenities={'pool','banya','hot-tub','sauna-pool','restaurant','breakfast','food','kitchen','bbq','gazebos','beach','private-pool','private-sauna','russian-banya-house','banya-hot-tub','banya-water'}
price={'budget','daily-houses','weekend','premium','day-trip'}
themes={c['slug']:c['themeKey'] for c in after['configs']}
p=out/'SEO-карта.csv'
with p.open(encoding='utf-8-sig',newline='') as f:table=list(csv.reader(f,delimiter=';'))
for n,row in enumerate(table):
 if n==0:group='Кластер поисковых интентов'
 else:
  key=themes.get(row[0]);group='Расположение' if key in geo else 'Удобства' if key in amenities else 'Цена и длительность' if key in price else 'Брендовые запросы' if row[1]=='Карточка' else 'Общие запросы' if row[0] in ['/','/katalog/'] else 'Формат отдыха / гипотеза'
 row.insert(2,group)
 if n and row[0]=='/':row[3]='базы отдыха Удмуртия; базы отдыха Ижевск; лучшие базы отдыха Удмуртии; загородный отдых в Удмуртии; куда поехать отдыхать в Удмуртии'
with p.open('w',encoding='utf-8-sig',newline='') as f:csv.writer(f,delimiter=';').writerows(table)
