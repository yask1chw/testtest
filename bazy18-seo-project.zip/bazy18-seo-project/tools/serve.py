"""Local preview only. Production Apache rules must also be checked on staging."""
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
import argparse
p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8766);args=p.parse_args()
root=Path(__file__).resolve().parents[1]/'site'
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kw):super().__init__(*args,directory=str(root),**kw)
 def log_message(self,*args):pass
 def end_headers(self):
  q=parse_qs(urlsplit(self.path).query,keep_blank_values=True)
  if any(not (k.startswith('utm_') or k in ['yclid','gclid','fbclid','_ym_uid','_ym_d']) for k in q):self.send_header('X-Robots-Tag','noindex, follow')
  super().end_headers()
 def send_error(self,code,message=None,explain=None):
  if code==404:
   content=(root/'404.html').read_bytes();self.send_response(404);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(content)));self.end_headers();self.wfile.write(content)
  else:super().send_error(code,message,explain)
ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
