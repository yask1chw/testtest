const { chromium } = require("playwright");
const fs = require("node:fs");
const path = require("node:path");
(async () => {
  const root = path.resolve(__dirname, ".."),
    site = path.join(root, "site");
  const paths = [];
  function walk(dir) {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) walk(p);
      else if (e.name === "index.html")
        paths.push(
          "/" +
            path.relative(site, dir).split(path.sep).filter(Boolean).join("/") +
            (dir === site ? "" : "/"),
        );
    }
  }
  walk(site);
  const b = await chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
    args: ["--no-sandbox"],
  });
  let failed = [],
    audit;
  const start = Date.now();
  const ssrCode = await require("./ssr-bundle.cjs")();
  // No requests to analytics, forms, image hosts or external sites during the build.
  for (let i = 0; i < paths.length; i++) {
    const context = await b.newContext();
    await context.route("**/*", (r) =>
      r.request().url().startsWith("http://localhost:8766")
        ? r.continue()
        : r.abort(),
    );
    await context.addInitScript(() => {
      window.__SEO_PRERENDER__ = true;
      window.__SEO_TEST__ = true;
    });
    const p = await context.newPage();
    let errors = [];
    p.on("pageerror", (e) => errors.push(String(e)));
    try {
      await p.goto("http://localhost:8766" + paths[i], {
        waitUntil: "domcontentloaded",
      });
      await p.waitForFunction(
        () => window.REACT_APP_NAVIGATE && document.querySelector("h1"),
      );
      await p.waitForTimeout(120);
      if (errors.length) throw Error(errors.join("\n"));
      if (!audit) audit = await p.evaluate(() => window.__SEO_AUDIT__);
      const renderer = await p.addScriptTag({ content: ssrCode });
      await p.evaluate(() => {
        const markup = window.__SEO_RENDER_TO_STRING__(
          window.__SEO_SSR_ELEMENT__,
        );
        document.getElementById("root").innerHTML = markup;
      });
      await renderer.evaluate((e) => e.remove());
      const html = await p.content();
      fs.writeFileSync(path.join(site, paths[i], "index.html"), html);
      if (i % 15 === 0) console.log(`Prerender ${i + 1}/${paths.length}`);
    } catch (e) {
      failed.push({ path: paths[i], error: String(e) });
    }
    await context.close();
  }
  await b.close();
  fs.writeFileSync(
    path.join(root, "reports/prerender.json"),
    JSON.stringify(
      { routes: paths.length, failed, seconds: (Date.now() - start) / 1000 },
      null,
      2,
    ),
  );
  if (audit)
    fs.writeFileSync(
      path.join(root, "reports/data-after.json"),
      JSON.stringify(audit, null, 2),
    );
  if (failed.length) {
    console.error(failed);
    process.exit(1);
  }
  console.log(`Prerendered ${paths.length} routes.`);
})();
