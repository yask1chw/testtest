from pathlib import Path
from lxml import html,etree
from urllib.parse import urlsplit,unquote
from collections import Counter
import json,re,hashlib
root=Path(__file__).resolve().parents[1];site=root/'site';errors=[];warnings=[];links=0;docs={};schemas=0;types=Counter();origin='https://xn--18-6kcd5a6i.xn--p1ai'
for p in sorted(site.rglob('*.html')):
 route='/'+str(p.parent.relative_to(site)).strip('.')+'/' if p.name=='index.html' else '/404.html';route=re.sub('/+','/',route)
 d=html.fromstring(p.read_text());docs[route]=d
 def fail(msg):errors.append(route+': '+msg)
 if len(d.xpath('//h1'))!=1:fail('expected exactly one h1')
 for xp in ['//title','//meta[@name="description"]','//link[@rel="canonical"]','//meta[@name="robots"]','//meta[@property="og:url"]']:
  if len(d.xpath(xp))!=1:fail('missing/duplicate '+xp)
 canonical=d.xpath('//link[@rel="canonical"]/@href')[0]
 if route!='/404.html' and canonical!=origin+route:fail('incorrect canonical '+canonical)
 for a in d.xpath('//a[@href]'):
  u=urlsplit(a.get('href'));links+=1
  if not u.scheme and not u.netloc and u.path:
   dest=site/unquote(u.path).lstrip('/');target=dest/'index.html' if dest.is_dir() else dest
   if not target.is_file():fail('broken internal link '+a.get('href'))
  if u.scheme in ['http','https'] and a.get('target')=='_blank' and 'noopener' not in a.get('rel',''):fail('external target without noopener')
 for img in d.xpath('//img[not(ancestor::noscript)]'):
  if not img.get('alt') and img.get('alt') is None:fail('image without alt')
  if not img.get('width') or not img.get('height'):warnings.append(route+': image without dimensions')
 for s in d.xpath('//script[@type="application/ld+json"]/text()'):
  try:
   obj=json.loads(s);schemas+=1
   def scan(o):
    if isinstance(o,list):
     for x in o:scan(x)
    if isinstance(o,dict):
     if '@type' in o:types[str(o['@type'])]+=1
     if o.get('@type') in ['AggregateRating','Review']:fail('unverified review/rating markup')
     if o.get('@type')=='ItemList':
      pos=[v['position'] for v in o.get('itemListElement',[])];
      if pos!=list(range(1,len(pos)+1)):fail('nonconsecutive ItemList positions')
     if o.get('@type')=='LodgingBusiness':
      if not o.get('name') or not o.get('url') or not o.get('address'):fail('incomplete lodging schema')
      if any(k in o for k in ['geo','checkinTime','checkoutTime','aggregateRating']):fail('unverified or invalid lodging field')
     for v in o.values():scan(v)
   scan(obj)
  except Exception as e:fail('invalid JSON-LD '+str(e))
# Check fragment destinations as well as route files.
for route,d in docs.items():
 for href in d.xpath('//a/@href'):
  u=urlsplit(href)
  if u.fragment and not u.scheme and not u.netloc:
   target_path=unquote(u.path) if u.path else route
   if target_path in docs and not docs[target_path].xpath('//*[@id=$fragment]',fragment=unquote(u.fragment)):
    errors.append(route+': missing fragment '+href)
# Duplicate metadata across indexable routes.
for field in ['title','description']:
 vals=Counter()
 for route,d in docs.items():
  if 'noindex' in d.xpath('string(//meta[@name="robots"]/@content)'):continue
  vals[d.xpath('string(//title)' if field=='title' else 'string(//meta[@name="description"]/@content)')]+=1
 for v,n in vals.items():
  if n>1:errors.append(f'Duplicate {field} ({n}): {v}')
locs=etree.parse(str(site/'sitemap.xml')).xpath('//*[local-name()="loc"]/text()')
if len(locs)!=len(set(locs)):errors.append('Duplicate sitemap URLs')
for u in locs:
 r=u.removeprefix(origin);d=docs.get(r)
 if d is None:errors.append('Unknown sitemap route '+u);continue
 if 'noindex' in d.xpath('string(//meta[@name="robots"]/@content)'):errors.append('noindex sitemap page '+u)
 if d.xpath('string(//link[@rel="canonical"]/@href)')!=u:errors.append('noncanonical sitemap URL '+u)
# Prove source data was retained, beyond a count assertion.
before=json.loads((root/'reports/data-before.json').read_text());after=json.loads((root/'reports/data-after.json').read_text())
for a,b in [('bases','bases'),('details','details'),('extra','extra')]:
 if before[a]!=after[b]:errors.append('Object data changed: '+a)
report={'html_pages':len(docs),'internal_and_external_links':links,'sitemap_urls':len(locs),'jsonld_blocks':schemas,'schema_types':dict(types),'data_records_unchanged':not any('Object data changed' in e for e in errors),'errors':errors,'warnings':warnings}
(root/'reports/static-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2));raise SystemExit(bool(errors))
