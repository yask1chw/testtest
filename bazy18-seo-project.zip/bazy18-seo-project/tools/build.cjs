const fs = require("node:fs");
const path = require("node:path");
const { parse } = require("@babel/parser");
const traverse = require("@babel/traverse").default;
const generate = require("@babel/generator").default;
const t = require("@babel/types");
const root = path.resolve(__dirname, ".."),
  orig = path.join(root, "original"),
  out = path.join(root, "site");
fs.rmSync(out, { recursive: true, force: true });
fs.cpSync(orig, out, { recursive: true });
const name = "index-DyhOV6Jn.js",
  code = fs.readFileSync(path.join(orig, "assets", name), "utf8"),
  ast = parse(code, { sourceType: "module" });
if (
  require("node:crypto").createHash("sha256").update(code).digest("hex") !==
  "f7b9352a9e106e82e9945787a701c14d09341e07cee586af1a90fdfa9384ccfe"
)
  throw Error(
    "This patch only supports the supplied production bundle; audit a new version before rebuilding.",
  );
let configs = [];
for (const n of ast.program.body)
  if (t.isVariableDeclaration(n))
    for (const d of n.declarations)
      if (
        t.isObjectExpression(d.init) &&
        d.init.properties.some((p) => p.key?.name === "themeKey")
      )
        configs.push(d.id.name);
const add = parse(
    fs
      .readFileSync(path.join(root, "src/seo-runtime.js"), "utf8")
      .replace("__SEO_CONFIGS__", `[${configs.join(",")}]`),
    { sourceType: "module" },
  ),
  replacements = new Map(),
  extras = [];
const names = new Set(
  ast.program.body.filter(t.isFunctionDeclaration).map((n) => n.id.name),
);
for (const n of add.program.body) {
  if (t.isFunctionDeclaration(n) && names.has(n.id.name))
    replacements.set(n.id.name, n);
  else extras.push(n);
}
// Only display strings change here. The original data arrays and numbers are retained.
const protectedNames = new Set(["st", "Ih", "pv"]);
traverse(ast, {
  StringLiteral(p) {
    if (p.node.start < 280000) return;
    const owner = p.findParent((x) => x.isVariableDeclarator());
    if (owner && protectedNames.has(owner.node.id.name)) return;
    let s = p.node.value;
    const exact = {
      "Лучшие базы отдыха Удмуртии":
        "Базы отдыха Удмуртии — найдите место для отдыха",
      "Независимый обзор 2026": "Каталог загородного отдыха",
      "Сравниваем домики, базы у воды, SPA-комплексы и свадебные площадки по подтверждённым параметрам.":
        "Выбирайте отдых с бассейном, баней, у воды, для семьи или компании. Сравнивайте условия и связывайтесь с объектами.",
      "Смотреть рейтинг": "Сравнить условия",
      "По рейтингу": "По названию",
      "Рейтинг топ‑10": "Базы с подробными карточками",
      "Базы с рейтингом": "Базы с карточками",
      "Десять баз с полной карточкой и оценкой редакции.":
        "Десять баз с подробными карточками.",
      "Все базы рейтинга": "Все базы каталога",
      Рейтинг: "Каталог",
      "Как составлен рейтинг": "Принципы отбора",
      "как составлен рейтинг": "принципы отбора",
      "Ссылка может носить партнёрский характер. Цены и условия уточняйте у объекта.":
        "Цены и условия уточняйте у объекта.",
      "Рейтинг строится по единой 100-балльной шкале из семи критериев. Мы описываем методику открыто, чтобы подборка не выглядела рекламной. Если сведения вызывают сомнения, мы не ставим отметку «есть», а честно советуем уточнить условия перед бронированием.":
        "Каталог использует нейтральную сортировку по названию. Для проверки прежних редакционных баллов данных недостаточно, поэтому оценки не публикуются. Неизвестные параметры уточняйте у объекта.",
    };
    if (exact[s]) s = exact[s];
    s = s
      .replace(/ТОП базы отдыха Удмуртии(?: 2026)?/g, "Базы отдыха Удмуртии")
      .replace(
        /© 2026 Рейтинг баз отдыха Удмуртии/g,
        "© 2026 Базы отдыха Удмуртии",
      );
    p.node.value = s;
  },
  CallExpression(p) {
    if (
      p.node.start < 280000 ||
      !t.isMemberExpression(p.node.callee) ||
      p.node.callee.object.name !== "l" ||
      !["jsx", "jsxs"].includes(p.node.callee.property.name)
    )
      return;
    const props = p.node.arguments[1];
    if (!t.isObjectExpression(props)) return;
    const child = props.properties.find((v) => v.key?.name === "children");
    if (!child) return;
    const member = (n) =>
      t.isMemberExpression(n) && ["rank", "score"].includes(n.property.name);
    if (member(child.value)) {
      child.value = t.nullLiteral();
      return;
    }
    if (t.isArrayExpression(child.value) && child.value.elements.some(member)) {
      child.value.elements = child.value.elements.filter(
        (n) =>
          !member(n) &&
          !(t.isStringLiteral(n) && /№|\/100|Оценка|в рейтинге/.test(n.value)),
      );
      if (child.value.elements.length === 0) p.replaceWith(t.nullLiteral());
    }
  },
});
traverse(ast, {
  FunctionDeclaration(p) {
    if (p.node.id.name === "Wh")
      p.traverse({
        MemberExpression(q) {
          if (q.node.object.name === "i" && q.node.property.name === "short")
            q.replaceWith(
              t.callExpression(t.identifier("seoSummary"), [t.identifier("i")]),
            );
        },
      });
  },
});
// On the catalog, the mobile action keeps the selected conditions and goes to results.
traverse(ast, {
  FunctionDeclaration(p) {
    if (p.node.id.name === "ht")
      p.traverse({
        CallExpression(q) {
          if (
            q.node.callee?.object?.name !== "l" ||
            q.node.callee?.property?.name !== "jsxs" ||
            q.node.arguments[0]?.name !== "G"
          )
            return;
          const props = q.node.arguments[1];
          if (!t.isObjectExpression(props)) return;
          const to = props.properties.find((p) => p.key?.name === "to");
          const ch = props.properties.find((p) => p.key?.name === "children");
          if (
            !to ||
            to.value.value !== "/katalog/" ||
            !t.isArrayExpression(ch?.value)
          )
            return;
          to.value = parse(
            'i==="/katalog/"?{pathname:i,search:window.location.search,hash:"#results"}:"/katalog/"',
          ).program.body[0].expression;
          ch.value.elements = ch.value.elements.map((n) =>
            t.isStringLiteral(n) && n.value === "Подобрать базу"
              ? parse('i==="/katalog/"?"Показать результаты":"Подобрать базу"')
                  .program.body[0].expression
              : n,
          );
        },
      });
  },
});
let replaced = [];
ast.program.body = ast.program.body.map((n) => {
  if (t.isFunctionDeclaration(n) && replacements.has(n.id.name)) {
    replaced.push(n.id.name);
    return replacements.get(n.id.name);
  }
  return n;
});
if (replaced.length !== replacements.size) throw Error("Replacement mismatch");
// Base templates and a lifecycle component are referenced by the existing React Router.
traverse(ast, {
  FunctionDeclaration(p) {
    if (p.node.id.name === "Z1") {
      traverse(
        p.node,
        {
          noScope: true,
          ArrayExpression(q) {
            if (
              q.node.elements.some(
                (e) => t.isCallExpression(e) && e.arguments[0]?.name === "Y1",
              )
            ) {
              q.node.elements.unshift(
                t.callExpression(
                  t.memberExpression(t.identifier("l"), t.identifier("jsx")),
                  [t.identifier("SeoLifecycle"), t.objectExpression([])],
                ),
              );
              q.stop();
            }
          },
        },
        p.scope,
      );
    }
  },
});
const mount = ast.program.body.findIndex(
  (n) =>
    t.isVariableDeclaration(n) &&
    n.declarations.some((d) => d.id.name === "Vc"),
);
if (mount < 0) throw Error("Mount not found");
ast.program.body.splice(mount, 0, ...extras);
// Build mode renders fresh snapshots; production hydrates the saved HTML.
const last = ast.program.body.at(-1);
ast.program.body[ast.program.body.length - 1] = parse(
  `if(window.__SEO_PRERENDER__){window.__SEO_REACT__=S;window.__SEO_SSR_ELEMENT__=mh;Vc.replaceChildren();Qp.createRoot(Vc).render(mh)}else{Vc.hasChildNodes()?Qp.hydrateRoot(Vc,mh):Qp.createRoot(Vc).render(mh)}`,
  { sourceType: "module" },
).program.body[0];
const generated = generate(ast, { compact: true, comments: false }).code;
const result = require("esbuild").buildSync({
  stdin: { contents: generated },
  bundle: true,
  minify: true,
  charset: "utf8",
  target: "es2020",
  write: false,
  legalComments: "inline",
}).outputFiles[0].text;
const hash = require("node:crypto")
    .createHash("sha256")
    .update(result)
    .digest("hex")
    .slice(0, 12),
  bundle = `site-${hash}.js`;
fs.writeFileSync(path.join(out, "assets", bundle), result);
fs.unlinkSync(path.join(out, "assets", name));
function walk(dir) {
  return fs
    .readdirSync(dir, { withFileTypes: true })
    .flatMap((e) =>
      e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)],
    );
}
for (const file of walk(out).filter((p) => p.endsWith(".html"))) {
  let html = fs
    .readFileSync(file, "utf8")
    .replaceAll(`/assets/${name}`, `/assets/${bundle}`);
  fs.writeFileSync(file, html);
}
fs.appendFileSync(
  path.join(out, "assets/site.css"),
  "\n.grid>div,.grid>section,.grid>article,.grid>aside{min-width:0}.seo-mobile-contact{display:none}@media(max-width:767px){.seo-mobile-contact{display:block;position:fixed;bottom:0;left:0;right:0;z-index:45;padding:12px 16px;background:#f8f7f3;border-top:1px solid #deded7}.seo-mobile-contact>a{width:100%}}\n",
);
fs.writeFileSync(
  path.join(out, "assets/photo-unavailable.svg"),
  '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600" viewBox="0 0 800 600"><rect width="800" height="600" fill="#e7ece2"/><path d="M320 320l80-70 80 70v70H320z" fill="none" stroke="#64795b" stroke-width="6"/><text x="400" y="440" text-anchor="middle" font-family="sans-serif" font-size="24" fill="#45583f">Фото объекта не добавлено</text></svg>',
);
fs.writeFileSync(
  path.join(root, "reports/build.json"),
  JSON.stringify(
    {
      bundle,
      originalBytes: Buffer.byteLength(code),
      modifiedBytes: Buffer.byteLength(result),
      replacedFunctions: replaced,
      categoryCount: configs.length,
    },
    null,
    2,
  ),
);
console.log(
  `Built ${bundle}; ${replaced.length} function corrections, ${configs.length} existing category routes.`,
);
