const { chromium } = require("playwright");
const fs = require("node:fs");
const path = require("node:path");
const assert = require("node:assert/strict");
(async () => {
  const root = path.resolve(__dirname, ".."),
    browser = await chromium.launch({
      executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
      args: ["--no-sandbox"],
    });
  const context = await browser.newContext({
    viewport: { width: 1440, height: 1000 },
  });
  await context.addInitScript(() => {
    window.__SEO_TEST__ = true;
    window.ym = (...args) =>
      (window.__ymCalls = window.__ymCalls || []).push(args);
  });
  await context.route("**/*", (r) =>
    r.request().url().startsWith("http://localhost:8766")
      ? r.continue()
      : r.abort(),
  );
  const page = await context.newPage();
  let pageErrors = [],
    consoleErrors = [],
    passed = [];
  page.on("pageerror", (e) =>
    pageErrors.push({ url: page.url(), error: String(e) }),
  );
  page.on("console", (m) => {
    if (
      m.type() === "error" &&
      !/Failed to load resource|net::ERR/.test(m.text())
    )
      consoleErrors.push(m.text());
  });
  const go = async (route) => {
    const response = await page.goto("http://localhost:8766" + route, {
      waitUntil: "domcontentloaded",
    });
    assert.equal(response.status(), 200, route);
    await page.waitForFunction(() => window.REACT_APP_NAVIGATE);
    await page.waitForTimeout(150);
  };
  const check = async (name, f) => {
    await f();
    passed.push(name);
    console.log("PASS " + name);
  };
  await check("Home hydration and one H1", async () => {
    await go("/");
    assert.equal(await page.locator("h1").count(), 1);
    assert.match(await page.title(), /Базы отдыха Удмуртии/);
  });
  await check("Category membership uses pool, not hot tub", async () => {
    await go("/bazy-otdyha-s-basseynom/");
    const data = await page.evaluate(() => window.__SEO_AUDIT__);
    const c = data.configs.find((c) => c.themeKey === "pool");
    assert.equal(c.primary.length, 7);
    assert(!c.primary.includes("dobroles"));
    assert(!c.primary.includes("kostovaty"));
    const names = await page.locator("#bases article h3").allTextContents();
    assert(!names.includes("Добролес"));
    assert(names.includes("Лухари"));
  });
  await check("Card feature text agrees with data", async () => {
    await go("/bazy/luhari/");
    assert.equal(
      await page
        .getByRole("navigation", { name: "Хлебные крошки" })
        .getByRole("link", { name: "Главная", exact: true })
        .count(),
      1,
    );
    const row = page
      .locator("dl > div")
      .filter({ has: page.getByText("Бассейн", { exact: true }) });
    assert.match(
      await row.innerText(),
      /Не подтверждён источником|Есть|Бассейн/,
    );
    assert(!(await row.innerText()).includes("Не подтверждён источником"));
    assert(!/\b96\/100/.test(await page.locator("body").innerText()));
    assert.equal(
      await page.locator('script[data-jsonld="base-lodging"]').count(),
      1,
    );
  });
  await check(
    "Price filter excludes unknown-priced extra objects",
    async () => {
      await go("/katalog/?price=6000");
      const result = await page
        .locator("[data-result-count]")
        .getAttribute("data-result-count");
      assert.equal(result, "3");
      assert.equal(await page.locator("main article").count(), 3);
      assert.equal(
        await page.locator('meta[name="robots"]').getAttribute("content"),
        "noindex, follow",
      );
      assert(
        (
          await page.locator('link[rel="canonical"]').getAttribute("href")
        ).endsWith("/katalog/"),
      );
    },
  );
  await check(
    "Filter interaction saves URL, reload and reset restore state",
    async () => {
      await go("/katalog/");
      await page
        .getByRole("button", { name: "С бассейном", exact: true })
        .click();
      await page.waitForURL(/features=basseyn/);
      await page.waitForFunction(()=>document.querySelector('[data-result-count]')?.getAttribute('data-result-count')==='34');
      assert.match(await page.locator("[data-result-count]").innerText(), /34/);
      await page.reload();
      await page.waitForFunction(() => window.REACT_APP_NAVIGATE);
      assert(
        await page
          .getByRole("button", { name: "Убрать фильтр: С бассейном" })
          .isVisible(),
      );
      await page
        .getByRole("button", { name: /^Сбросить/ })
        .first()
        .click();
      await page.waitForURL("http://localhost:8766/katalog/");
      await page.waitForFunction(()=>document.querySelector('[data-result-count]')?.getAttribute('data-result-count')==='69');
      assert.equal(
        await page
          .locator("[data-result-count]")
          .getAttribute("data-result-count"),
        "69",
      );
    },
  );
  await check(
    "No results stay noindex and show explicitly labelled alternatives",
    async () => {
      await go(
        "/katalog/?price=6000&features=chan,restoran,pets&format=Коттеджи",
      );
      assert.equal(
        await page
          .locator("[data-result-count]")
          .getAttribute("data-result-count"),
        "0",
      );
      assert.match(
        await page.locator("main").innerText(),
        /Альтернативы ниже не соответствуют/,
      );
      assert.equal(
        await page.locator('meta[name="robots"]').getAttribute("content"),
        "noindex, follow",
      );
    },
  );
  await check("Empty category remains accessible and noindex", async () => {
    await go("/a-frame-domiki/");
    assert.equal(
      await page.locator('meta[name="robots"]').getAttribute("content"),
      "noindex, follow",
    );
    assert.equal(await page.locator("#bases article").count(), 0);
  });
  await check(
    "SPA route transition cleans up previous structured data",
    async () => {
      await go("/bazy/luhari/");
      await page.evaluate(() =>
        window.REACT_APP_NAVIGATE("/bazy-otdyha-s-baney/"),
      );
      await page.waitForTimeout(200);
      assert.equal(
        await page.locator('script[data-jsonld="base-lodging"]').count(),
        0,
      );
      assert.equal(
        await page.locator('script[data-jsonld="collection-items"]').count(),
        1,
      );
      assert.equal(await page.locator('script[data-jsonld="site"]').count(), 1);
    },
  );
  await check("Comparison persists and renders selected records", async () => {
    await go("/bazy/luhari/");
    await page
      .getByRole("button", { name: "Добавить к сравнению", exact: true })
      .click();
    await go("/bazy/dobroles/");
    await page
      .getByRole("button", { name: "Добавить к сравнению", exact: true })
      .click();
    await go("/sravnenie/");
    assert.match(await page.locator("main").innerText(), /Лухари/);
    assert.match(await page.locator("main").innerText(), /Добролес/);
    assert.equal(
      await page.locator('meta[name="robots"]').getAttribute("content"),
      "noindex, follow",
    );
  });
  await check(
    "Outbound event reaches Metrika once and contains object id only",
    async () => {
      await go("/bazy/luhari/");
      await page.evaluate(() => {
        window.dataLayer = [];
        window.__ymCalls = [];
      });
      await page
        .getByRole("link", {
          name: "Связаться на официальном сайте",
          exact: true,
        })
        .first()
        .click({ noWaitAfter: true });
      await page.waitForTimeout(100);
      const d = await page.evaluate(() => ({
        events: window.dataLayer.filter(
          (e) => e.event === "external_site_click",
        ),
        calls: window.__ymCalls.filter((a) => a[1] === "reachGoal"),
      }));
      assert.equal(d.events.length, 1);
      assert.equal(d.events[0].base_id, "lukhari");
      assert.equal(
        d.calls.filter((c) => c[2] === "external_site_click").length,
        1,
      );
      assert(!JSON.stringify(d.events).includes("phone"));
    },
  );
  await check("Phone and booking buttons are not invented", async () => {
    assert.equal(await page.locator('a[href^="tel:"]').count(), 0);
    assert.equal(
      await page
        .getByRole("button", { name: "Забронировать", exact: true })
        .count(),
      0,
    );
  });
  await check(
    "Mobile menu, filters, contact and horizontal overflow",
    async () => {
      await page.setViewportSize({ width: 390, height: 844 });
      for (const route of [
        "/",
        "/katalog/",
        "/bazy/luhari/",
        "/bazy-otdyha-s-basseynom/",
        "/sravnenie/",
      ]) {
        await go(route);
        assert(
          await page.evaluate(
            () => document.documentElement.scrollWidth <= innerWidth + 1,
          ),
          route + " overflows",
        );
      }
      await go("/bazy/luhari/");
      assert(await page.locator(".seo-mobile-contact").isVisible());
      await page.screenshot({
        path: path.join(root, "reports/mobile-card.png"),
        fullPage: false,
      });
      await go("/katalog/");
      await page.getByRole("button", { name: "Открыть меню" }).click();
      assert(
        await page
          .getByRole("link", { name: "Каталог", exact: true })
          .isVisible(),
      );
      await page.getByRole("button", { name: "Открыть меню" }).click();
      await page.getByRole("button", { name: "Фильтры", exact: true }).click();
      await page
        .getByRole("button", { name: "С бассейном", exact: true })
        .click();
      await page
        .getByRole("button", { name: "Показать результаты", exact: true })
        .click();
      assert.match(page.url(), /features=basseyn/);
      const mobileAction = page.getByRole("link", {
        name: "Показать результаты",
        exact: true,
      });
      await mobileAction.click();
      await page.waitForURL(/features=basseyn.*#results/);
      assert.equal(
        await page
          .locator("[data-result-count]")
          .getAttribute("data-result-count"),
        "34",
      );
      await page.waitForTimeout(300);
      await page.bringToFront();
      await page.screenshot({
        path: path.join(root, "reports/mobile-catalog.png"),
        fullPage: false,
      });
    },
  );
  await check("All 113 production route snapshots hydrate", async () => {
    await page.setViewportSize({ width: 1440, height: 1000 });
    const routes = JSON.parse(
      fs.readFileSync(path.join(root, "reports/routes-after.json")),
    );
    for (const r of routes) {
      await go(r.url);
      assert.equal(await page.locator("h1").count(), 1, r.url);
      assert.equal(
        await page.locator('link[rel="canonical"]').getAttribute("href"),
        r.canonical,
        r.url,
      );
    }
  });
  await browser.close();
  assert.deepEqual(pageErrors, []);
  assert.deepEqual(consoleErrors, []);
  const report = { passed, pageErrors, consoleErrors };
  fs.writeFileSync(
    path.join(root, "reports/browser-checks.json"),
    JSON.stringify(report, null, 2),
  );
  console.log("ALL BROWSER CHECKS PASSED");
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
