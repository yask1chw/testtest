export default [
  {
    files: ["src/**/*.js", "tools/**/*.cjs"],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: "script",
      globals: {
        require: "readonly",
        module: "readonly",
        __dirname: "readonly",
        process: "readonly",
        console: "readonly",
        window: "readonly",
        document: "readonly",
        location: "readonly",
      },
    },
    rules: {
      "no-dupe-keys": "error",
      "no-unreachable": "error",
      "valid-typeof": "error",
      "no-constant-condition": "error",
      "no-unsafe-finally": "error",
    },
  },
];
