/* Additive corrections for the supplied production bundle. Original records remain unchanged.
 * Local bindings below intentionally match the supplied compiled React application.
 */
const SeoConfigList = __SEO_CONFIGS__;
const SeoByPath = new Map(SeoConfigList.map((c) => [c.slug, c]));
const SeoClass = "mx-auto w-full px-4 md:px-6 lg:px-10";
const SeoButton =
  "inline-flex items-center justify-center rounded-full bg-primary-500 px-5 py-3 text-sm font-semibold text-background-50";
const SeoPanel =
  "rounded-lg border border-background-200 bg-background-50 p-5 md:p-6";
const SeoSort = (a, b) => a.name.localeCompare(b.name, "ru");
const SeoTag = (b, t) =>
  (b.tags || []).some((v) => v.toLowerCase() === t.toLowerCase());
const SeoPrimary = new Map(dl.map((b) => [b.id, b]));
const SeoFeatureNames = { ...Jx, pets: "С животными" };
const SeoFaq = [
  {
    q: "Как выбрать базу отдыха в Удмуртии?",
    a: "Выберите удобства, формат поездки и расстояние от Ижевска. Сравните карточки и уточните актуальные условия у объекта.",
  },
  {
    q: "Можно ли забронировать отдых на сайте?",
    a: "Каталог помогает выбрать место. Бронирование и оплату согласуйте непосредственно с объектом по ссылке на его официальный сайт.",
  },
  {
    q: "Что означает отсутствие удобства в карточке?",
    a: "Отсутствие подтверждения не означает, что услуги нет. В подборку по этому удобству объект не включается, пока сведения не уточнены.",
  },
  {
    q: "Насколько актуальны цены?",
    a: "Цены из исходного каталога служат ориентиром и могут меняться. Дата из исходных данных указана в карточке; итоговую стоимость и свободные даты подтверждает объект.",
  },
];
function seoFeatures(b) {
  const d = SeoPrimary.get(b.id);
  if (!d)
    return hv(b).concat(
      ie(b, "С животными") ? ["pets"] : [],
      ie(b, "Рыбалка") ? ["fishing"] : [],
      ie(b, "Ресторан") ? ["restoran"] : [],
      ie(b, "Для двоих") ? ["two"] : [],
      ie(b, "Свадьб") ? ["wedding"] : [],
    );
  const s = d.services;
  return [
    d.water.distance !== "—" && "water",
    (s.banya || s.sauna) && "banya",
    s.pool && "basseyn",
    s.chan && "chan",
    d.fishing.available && "fishing",
    s.restaurant && "restoran",
    b.badges.includes("kids") && "kids",
    (b.formats.includes("Для двоих") || b.badges.includes("two")) && "two",
    b.badges.includes("wedding") && "wedding",
    b.badges.includes("pets") && "pets",
  ].filter(Boolean);
}
function seoMatch(b, key) {
  const d = SeoPrimary.get(b.id),
    f = seoFeatures(b),
    has = (k) => f.includes(k),
    tag = (t) => SeoTag(b, t);
  const water = has("water"),
    bath = has("banya"),
    couple = has("two");
  const home = d
    ? b.formats.some((x) => x === "Дома" || x === "Коттеджи")
    : tag("Домики");
  const forest = d ? d.tags.includes("Лес") : tag("Лес");
  const winter = d ? /круглогодич/i.test(d.winterAccess) : tag("Круглый год");
  const wedding = d ? has("wedding") : ie(b, "Свадьб");
  const event = d
    ? b.badges.includes("events") || wedding
    : ie(b, "Корпоратив");
  const daily = d && home && /1 суток/.test(d.minStay);
  const text = d ? [d.units, ...b.formats].join(" ") : b.format;
  switch (key) {
    case "pool":
      return has("basseyn");
    case "kids":
      return has("kids");
    case "banya":
      return bath;
    case "water":
      return water;
    case "romance":
    case "houses-for-two":
      return couple && home;
    case "hot-tub":
      return has("chan");
    case "fishing":
      return has("fishing");
    case "pets":
      return has("pets");
    case "corporate":
    case "birthday":
      return event;
    case "wedding":
      return wedding;
    case "large-group":
      return !!d && home && d.capacityMax >= 10;
    case "budget":
      return !!d && d.priceWeekday !== null && d.priceWeekday <= 6000;
    case "cottages":
      return !!d && b.formats.includes("Коттеджи");
    case "weekend":
    case "daily-houses":
      return !!daily;
    case "glamping":
      return /глэмпинг|сафари-тент|сaфари-тент/i.test(text);
    case "near":
      return (
        (d ? d.distanceKm : b.distanceKm) != null &&
        (d ? d.distanceKm : b.distanceKm) <= 30
      );
    case "summer":
    case "autumn":
    case "spring":
    case "winter":
      return winter;
    case "forest":
      return forest;
    case "kama":
      return (
        water &&
        /кам[аы]/i.test(
          d
            ? d.water.body
            : [b.location, b.settlement, b.district, ...b.tags].join(" "),
        )
      );
    case "near-votkinsk":
      return /воткинск/i.test(
        d ? b.district : [b.district, b.settlement, b.location].join(" "),
      );
    case "near-sarapul":
      return /сарапул/i.test(
        d ? b.district : [b.district, b.settlement, b.location].join(" "),
      );
    case "food":
      return (
        (!!d &&
          (d.services.restaurant || d.services.cafe || d.services.breakfast)) ||
        (!d && (tag("Ресторан") || tag("Завтрак")))
      );
    case "restaurant":
      return has("restoran");
    case "breakfast":
      return d ? d.services.breakfast : tag("Завтрак");
    case "kitchen":
      return d ? d.services.kitchen : tag("Кухня");
    case "four-guests":
      return !!d && home && d.capacityMin <= 4 && d.capacityMax >= 4;
    case "ten-guests":
      return !!d && home && d.capacityMin <= 10 && d.capacityMax >= 10;
    case "sauna-pool":
      return bath && has("basseyn");
    case "beach":
      return d
        ? water &&
            /пляж/.test(d.water.beach) &&
            !/уточн|нет/.test(d.water.beach)
        : tag("Пляж");
    case "bbq":
      return tag("Мангал");
    case "gazebos":
      return tag("Беседки");
    case "active":
      return d ? b.formats.includes("Активный отдых") : tag("Активный отдых");
    case "couple-water":
      return couple && home && water;
    case "couple-forest":
      return couple && home && forest;
    case "couple-hot-tub":
      return couple && home && has("chan");
    case "couple-sauna":
      return couple && home && !!d && d.services.sauna;
    case "shore-houses":
      return home && water && !!d && /выход/.test(d.water.distance);
    case "fishing-boat":
      return has("fishing") && !!d && d.fishing.boat;
    case "russian-banya-house":
      return home && !!d && d.services.banya;
    case "banya-hot-tub":
      return bath && has("chan");
    case "banya-water":
      return bath && water;
    case "wedding-water":
      return wedding && water;
    case "wedding-forest":
      return wedding && forest;
    case "wedding-stay":
      return wedding && home;
    case "wedding-restaurant":
      return wedding && has("restoran");
    case "wedding-tents":
      return wedding && !!d && /шатёр|шатер/.test(d.weddingVenue);
    // General seasonality never proves New Year availability, winter fishing,
    // private amenities, event permissions, beach safety, internet speed or A-frame availability.
    default:
      return false;
  }
}
function seoMembers(c) {
  return {
    primary: st.filter((b) => seoMatch(b, c.themeKey)).sort(SeoSort),
    extra: Wr.filter((b) => seoMatch(b, c.themeKey)).sort(SeoSort),
  };
}
function seoCount(c) {
  const m = seoMembers(c);
  return m.primary.length + m.extra.length;
}
function seoUrl(b) {
  return `/bazy/${SeoPrimary.get(b.id)?.slug || b.id}/`;
}
function seoListSchema(name, bases) {
  return {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name,
    itemListOrder: "https://schema.org/ItemListUnordered",
    numberOfItems: bases.length,
    itemListElement: bases.map((b, n) => ({
      "@type": "ListItem",
      position: n + 1,
      name: b.name,
      url: Be(seoUrl(b)),
    })),
  };
}
function seoLink(to, label, key) {
  return l.jsx(
    G,
    {
      to,
      className:
        "rounded-full border border-background-300 bg-background-50 px-4 py-2 text-sm font-medium text-foreground-800",
      children: label,
    },
    key || to,
  );
}
function SeoShell({ title, lead, children, crumbs }) {
  return l.jsxs("div", {
    className: "min-h-screen bg-background-50 pb-[88px] md:pb-0",
    children: [
      l.jsx(ht, {}),
      l.jsx("header", {
        className:
          "border-b border-background-200 bg-background-100 px-4 pb-10 pt-28 md:px-6 md:pt-32 lg:px-10",
        children: l.jsxs("div", {
          className: "mx-auto max-w-6xl",
          children: [
            crumbs && l.jsx(ds, { items: crumbs.filter((c) => c.to !== "/") }),
            l.jsx("h1", {
              className:
                "mt-3 font-heading text-3xl font-bold text-foreground-950 md:text-5xl",
              children: title,
            }),
            l.jsx("p", {
              className:
                "mt-4 max-w-3xl text-sm leading-relaxed text-foreground-600 md:text-base",
              children: lead,
            }),
          ],
        }),
      }),
      l.jsx("main", {
        className: "flex flex-col gap-12 py-12 md:gap-16",
        children,
      }),
      l.jsx(ft, {}),
    ],
  });
}
function SeoCards({ bases }) {
  return l.jsx("div", {
    className: "grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
    children: bases.map((b) => l.jsx(Wh, { base: b }, b.id)),
  });
}
function SeoFAQ({ items = SeoFaq }) {
  return l.jsxs("section", {
    className: SeoClass,
    children: [
      l.jsx("h2", {
        className: "mb-5 font-heading text-2xl font-bold text-foreground-950",
        children: "Частые вопросы",
      }),
      ...items.map((q) =>
        l.jsxs(
          "details",
          {
            className: SeoPanel,
            children: [
              l.jsx("summary", {
                className: "cursor-pointer font-semibold",
                children: q.q,
              }),
              l.jsx("p", {
                className: "mt-3 text-sm leading-relaxed text-foreground-600",
                children: q.a,
              }),
            ],
          },
          q.q,
        ),
      ),
    ],
  });
}
function Y({ config: c }) {
  const [scope, setScope] = S.useState("all"),
    loc = Nt(),
    navigate = bn();
  const members = seoMembers(c),
    total = members.primary.length + members.extra.length;
  const active =
    scope === "all"
      ? members
      : scope === "cards"
        ? { primary: members.primary, extra: [] }
        : { primary: [], extra: members.extra };
  const h1 = c.h1.replace(/^Лучшие /, "");
  ot({
    title: `${h1} — подбор и условия отдыха`,
    description: `${h1}: ${total ? `объектов по данным каталога — ${total}.` : "Данные по этому сценарию уточняются."} Сравните условия и уточните стоимость у объекта.`,
    canonical: Be(c.slug),
    robots: total ? "index, follow" : "noindex, follow",
  });
  ja("collection-items", seoListSchema(h1, active.primary));
  ja("collection-breadcrumb", {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Главная", item: Be("/") },
      { "@type": "ListItem", position: 2, name: h1, item: Be(c.slug) },
    ],
  });
  S.useEffect(() => {
    const p = new URLSearchParams(loc.search),
      v = p.get("scope");
    setScope(["cards", "extra"].includes(v) ? v : "all");
  }, [loc.search]);
  S.useEffect(() => {
    seoPageEvent("listing_view", { category: c.themeKey, result_count: total });
  }, [c.slug, total]);
  const choose = (v) => {
    const p = new URLSearchParams(loc.search);
    v === "all" ? p.delete("scope") : p.set("scope", v);
    navigate(
      { pathname: c.slug, search: p.toString() ? "?" + p : "" },
      { replace: true },
    );
    vi("filter_apply", { category: c.themeKey, scope: v });
  };
  const related = (Vv[c.themeKey] || []).filter(
    (v) => SeoByPath.has(v.to) && seoCount(SeoByPath.get(v.to)) > 0,
  );
  return l.jsx(SeoShell, {
    title: h1,
    lead: total
      ? "В подборке только объекты с соответствующим признаком в данных каталога. Наличие услуги и её работу в ваши даты подтверждает объект."
      : "В каталоге пока недостаточно данных для этой подборки. Уточните условия у объектов или выберите другую тему.",
    crumbs: [{ label: "Главная", to: "/" }, { label: c.breadcrumbLabel }],
    children: [
      l.jsxs("section", {
        className: SeoClass,
        children: [
          l.jsx("p", {
            className: "mb-4 text-sm text-foreground-600",
            children:
              SeoAdvice[c.themeKey] ||
              "Сравните расположение, состав услуг и условия аренды. Отдельные удобства могут оплачиваться дополнительно.",
          }),
          l.jsx("p", {
            className: "mb-4 text-sm text-foreground-600",
            children: `Найдено объектов: ${total}. Порядок — по названию, без оценки качества.`,
          }),
          total > 0 &&
            l.jsxs("div", {
              className: "flex flex-wrap gap-2",
              children: [
                ["all", "Все объекты"],
                ["cards", "С подробной карточкой"],
                ["extra", "Краткие карточки"],
              ].map(([v, t]) =>
                l.jsx(
                  "button",
                  {
                    type: "button",
                    "aria-pressed": scope === v,
                    onClick: () => choose(v),
                    className: scope === v ? SeoButton : SeoPanel,
                    children: t,
                  },
                  v,
                ),
              ),
            }),
        ],
      }),
      l.jsxs("section", {
        id: "bases",
        className: SeoClass,
        children: [
          l.jsx("h2", {
            className: "mb-5 font-heading text-2xl font-bold",
            children: "Подходящие места",
          }),
          l.jsx(SeoCards, { bases: active.primary }),
          active.extra.length > 0 &&
            l.jsx("div", {
              className: "mt-8",
              children: l.jsx(af, {
                items: active.extra,
                trackPage: c.slug,
                campaign: c.themeKey,
              }),
            }),
          !active.primary.length &&
            !active.extra.length &&
            l.jsxs("div", {
              className: SeoPanel,
              children: [
                l.jsx("p", {
                  children:
                    "По выбранным условиям объектов нет. Можно сбросить фильтр или посмотреть каталог.",
                }),
                l.jsx("div", {
                  className: "mt-4 flex flex-wrap gap-2",
                  children: [
                    l.jsx("button", {
                      className: SeoButton,
                      onClick: () => choose("all"),
                      children: "Сбросить фильтр",
                    }),
                    seoLink("/katalog/", "Открыть каталог"),
                  ],
                }),
              ],
            }),
        ],
      }),
      l.jsxs("section", {
        className: SeoClass,
        children: [
          l.jsx("h2", {
            className: "mb-5 font-heading text-2xl font-bold",
            children: "Расположение объектов",
          }),
          l.jsx(cs, { items: [...active.primary, ...active.extra] }),
        ],
      }),
      l.jsx(SeoFAQ, {}),
      related.length > 0 &&
        l.jsxs("section", {
          className: SeoClass,
          children: [
            l.jsx("h2", {
              className: "mb-5 font-heading text-2xl font-bold",
              children: "Смежные подборки",
            }),
            l.jsx("div", {
              className: "flex flex-wrap gap-3",
              children: related.map((v) => seoLink(v.to, v.label)),
            }),
          ],
        }),
    ],
  });
}
function seoReadFilters(params) {
  const scalar = (key, allowed) =>
    allowed.includes(params.get(key)) ? params.get(key) : "";
  return {
    format: scalar("format", [
      "Дома",
      "Коттеджи",
      "Номера",
      "SPA",
      "Активный отдых",
    ]),
    guests: scalar("guests", ["Для двоих", "Семейный отдых", "Для компании"]),
    area: scalar("area", ["15", "30", "60", "100"]),
    price: scalar("price", ["6000", "8000", "10000", "12000"]),
    district: params.get("district") || "",
    capacity: scalar("capacity", ["2", "4", "10", "20"]),
    overnight: scalar("overnight", ["yes"]),
    season: scalar("season", ["year"]),
    features: [
      ...new Set(
        (params.get("features") || "")
          .split(",")
          .filter((v) => Object.hasOwn(SeoFeatureNames, v)),
      ),
    ].sort(),
  };
}
function jv() {
  const loc = Nt(),
    navigate = bn(),
    params = S.useMemo(() => new URLSearchParams(loc.search), [loc.search]);
  const [ready, setReady] = S.useState(false);
  S.useLayoutEffect(() => setReady(true), []);
  const effectiveParams = ready ? params : new URLSearchParams();
  const filters = seoReadFilters(effectiveParams),
    active = hd(filters),
    sort = ["name", "price-asc", "price-desc", "distance"].includes(
      effectiveParams.get("sort"),
    )
      ? effectiveParams.get("sort")
      : "name";
  const primary = st.filter((b) => ef(b, filters));
  primary.sort(
    sort === "price-asc"
      ? (a, b) => a.priceFrom - b.priceFrom
      : sort === "price-desc"
        ? (a, b) => b.priceFrom - a.priceFrom
        : sort === "distance"
          ? (a, b) => Jc(a) - Jc(b)
          : SeoSort,
  );
  const extra = Wr.filter((b) => yv(b, filters)).sort(SeoSort),
    total = primary.length + extra.length;
  ot({
    title: "Каталог баз отдыха Удмуртии — фильтры, цены и карта",
    description:
      "Выберите базу отдыха по удобствам, формату поездки, расстоянию и цене. Сравните условия и свяжитесь с объектом.",
    canonical: Be("/katalog/"),
  });
  ja("catalog-items", seoListSchema("Каталог баз отдыха Удмуртии", primary));
  const update = (next, order = sort) => {
    const p = new URLSearchParams(loc.search);
    for (const k of [
      "format",
      "guests",
      "area",
      "price",
      "district",
      "capacity",
      "overnight",
      "season",
      "features",
      "sort",
    ])
      p.delete(k);
    for (const k of [
      "format",
      "guests",
      "area",
      "price",
      "district",
      "capacity",
      "overnight",
      "season",
    ])
      if (next[k]) p.set(k, next[k]);
    if (next.features.length)
      p.set("features", [...next.features].sort().join(","));
    if (order !== "name") p.set("sort", order);
    navigate(
      { pathname: "/katalog/", search: p.toString() ? "?" + p : "" },
      { replace: true },
    );
    vi("filter_apply", {
      features: next.features.join(","),
      format: next.format,
      guests: next.guests,
      area: next.area,
      price: next.price,
    });
  };
  S.useEffect(() => {
    if (ready) seoPageEvent("listing_view", { result_count: total });
  }, [loc.pathname, ready]);
  const chips = [
    ...filters.features.map((v) => ({
      key: v,
      label: SeoFeatureNames[v],
      remove: () =>
        update({
          ...filters,
          features: filters.features.filter((k) => k !== v),
        }),
    })),
    ...[
      "format",
      "guests",
      "area",
      "price",
      "district",
      "capacity",
      "overnight",
      "season",
    ]
      .filter((k) => filters[k])
      .map((k) => ({
        key: k,
        label:
          k === "capacity"
            ? `От ${filters[k]} гостей`
            : k === "season"
              ? "Круглогодично"
              : k === "overnight"
                ? "С размещением"
                : k === "price"
                  ? `До ${filters[k]} ₽/сутки`
                  : k === "area"
                    ? `До ${filters[k]} км`
                    : filters[k],
        remove: () => update({ ...filters, [k]: "" }),
      })),
  ];
  return l.jsx(SeoShell, {
    title: "Все базы отдыха Удмуртии",
    lead: "Подберите место по задаче поездки. Неизвестные цены и расстояния не считаются подходящими под заданный предел.",
    children: [
      l.jsx("section", {
        id: "filters",
        className: SeoClass,
        children: l.jsx(uv, {
          filters,
          onChange: update,
          onReset: () =>
            update(
              { format: "", guests: "", area: "", price: "", features: [] },
              "name",
            ),
        }),
      }),
      l.jsx("section", {
        className: SeoClass,
        children: l.jsx(SeoExtraFilters, { filters, onChange: update }),
      }),
      l.jsxs("section", {
        id: "results",
        className: SeoClass,
        children: [
          l.jsx("div", {
            className: "mb-4 flex flex-wrap gap-2",
            children: chips.map((v) =>
              l.jsx(
                "button",
                {
                  type: "button",
                  onClick: v.remove,
                  className: SeoPanel,
                  "aria-label": `Убрать фильтр: ${v.label}`,
                  children: `${v.label} ×`,
                },
                v.key,
              ),
            ),
          }),
          l.jsxs("div", {
            className: "mb-6 flex flex-wrap items-center justify-between gap-4",
            children: [
              l.jsx("p", {
                "aria-live": "polite",
                role: "status",
                "data-result-count": total,
                children: `Найдено объектов: ${total}`,
              }),
              l.jsxs("label", {
                children: [
                  "Сортировка ",
                  l.jsx("select", {
                    value: sort,
                    onChange: (e) => update(filters, e.target.value),
                    className:
                      "rounded-md border border-background-300 bg-background-50 px-3 py-2",
                    children: [
                      ["name", "По названию"],
                      ["price-asc", "Сначала дешевле"],
                      ["price-desc", "Сначала дороже"],
                      ["distance", "Ближе к Ижевску"],
                    ].map(([v, t]) =>
                      l.jsx("option", { value: v, children: t }, v),
                    ),
                  }),
                ],
              }),
              l.jsx("button", {
                type: "button",
                className: SeoButton,
                onClick: async (e) => {
                  try {
                    await navigator.clipboard.writeText(location.href);
                    e.target.textContent = "Ссылка скопирована";
                  } catch {
                    e.target.textContent =
                      "Скопируйте адрес из строки браузера";
                  }
                },
                children: "Поделиться подбором",
              }),
            ],
          }),
          l.jsx("h2", {
            className: "mb-5 font-heading text-2xl font-bold",
            children: "Подробные карточки",
          }),
          l.jsx(SeoCards, { bases: primary }),
          extra.length > 0 &&
            l.jsx("div", {
              className: "mt-8",
              children: l.jsx(af, { items: extra, trackPage: "/katalog/" }),
            }),
          !total &&
            l.jsxs("div", {
              className: SeoPanel,
              children: [
                l.jsx("p", {
                  children:
                    "Совпадений нет. Попробуйте убрать один из фильтров. Альтернативы ниже не соответствуют всем выбранным условиям.",
                }),
                l.jsx("button", {
                  onClick: () =>
                    update(
                      {
                        format: "",
                        guests: "",
                        area: "",
                        price: "",
                        features: [],
                      },
                      "name",
                    ),
                  className: SeoButton,
                  children: "Сбросить фильтры",
                }),
                l.jsx("div", {
                  className: "mt-5",
                  children: l.jsx(SeoCards, {
                    bases: [...st].sort(SeoSort).slice(0, 3),
                  }),
                }),
              ],
            }),
        ],
      }),
      l.jsxs("section", {
        className: SeoClass,
        children: [
          l.jsx("h2", {
            className: "mb-5 font-heading text-2xl font-bold",
            children: "Места на карте",
          }),
          l.jsx(cs, { items: [...primary, ...extra] }),
        ],
      }),
    ],
  });
}
function hd(i) {
  return !!(
    i.format ||
    i.guests ||
    i.area ||
    i.price ||
    i.district ||
    i.capacity ||
    i.overnight ||
    i.season ||
    i.features.length
  );
}
function ef(b, r) {
  const d = SeoPrimary.get(b.id);
  if (
    (r.format && !b.formats.includes(r.format)) ||
    (r.guests && !b.formats.includes(r.guests)) ||
    (r.area && (!d || d.distanceKm == null || d.distanceKm > Number(r.area))) ||
    (r.price &&
      (!d || d.priceWeekday == null || d.priceWeekday > Number(r.price)))
  )
    return false;
  return (
    seoExtraMatch(b, r) && r.features.every((k) => seoFeatures(b).includes(k))
  );
}
function yv(b, r) {
  if (r.price) return false;
  if (r.format) {
    if (["Дома", "Коттеджи"].includes(r.format)) {
      if (!ie(b, "Домики")) return false;
    } else if (r.format === "Номера") {
      if (!/отель|гостинич/i.test(b.format)) return false;
    } else if (r.format === "SPA") {
      if (!/спа/i.test(b.format) && !ie(b, "СПА")) return false;
    } else if (r.format === "Активный отдых") {
      if (!ie(b, "Активный отдых")) return false;
    } else return false;
  }
  if (
    r.guests &&
    ((r.guests === "Для двоих" && !ie(b, "Для двоих")) ||
      (r.guests === "Семейный отдых" && !ie(b, "Для детей")) ||
      (r.guests === "Для компании" && !ie(b, "Для компании")))
  )
    return false;
  if (r.area && (b.distanceKm == null || b.distanceKm > Number(r.area)))
    return false;
  return (
    seoExtraMatch(b, r) && r.features.every((k) => seoFeatures(b).includes(k))
  );
}
function Yt(value, label = "") {
  return value === true
    ? { value: label || "Да", yes: true }
    : { value: "Не подтверждено — уточните у объекта", yes: false };
}
function gv(b) {
  return b.image || "/assets/photo-unavailable.svg";
}
function cs({ items }) {
  const [id, setId] = S.useState("");
  const b = items.find((v) => v.id === id);
  return l.jsxs("div", {
    className: SeoPanel,
    children: [
      l.jsx("p", {
        className: "mb-4 text-sm text-foreground-600",
        children:
          "Откройте поиск объекта на Яндекс Картах. Точные координаты из исходного каталога не подтверждены; адрес и маршрут проверьте перед поездкой.",
      }),
      l.jsx("div", {
        className: "flex flex-wrap gap-2",
        children: items.map((v) =>
          l.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setId(v.id);
                vi("map_open", { base_id: v.id });
              },
              "aria-pressed": id === v.id,
              className:
                id === v.id
                  ? SeoButton
                  : "rounded-full border border-background-300 px-3 py-2 text-sm",
              children: v.name,
            },
            v.id,
          ),
        ),
      }),
      b &&
        l.jsx("a", {
          href: seoMapUrl(b),
          target: "_blank",
          rel: "noopener noreferrer",
          className: SeoButton,
          children: `Открыть «${b.name}» на карте`,
        }),
      !items.length &&
        l.jsx("p", { children: "Нет объектов для выбранных условий." }),
    ],
  });
}
function seoMapUrl(b) {
  const d = SeoPrimary.get(b.id);
  return (
    "https://yandex.ru/maps/?text=" +
    encodeURIComponent(
      [
        b.name,
        "Удмуртская Республика",
        d ? b.address : b.location || b.settlement || b.district,
      ]
        .filter(Boolean)
        .join(", "),
    )
  );
}
function ch() {
  return l.jsxs("div", {
    className: SeoPanel,
    children: [
      l.jsx("h2", {
        className: "font-heading text-lg font-bold",
        children: "Как устроен каталог",
      }),
      l.jsx("p", {
        className: "mt-3 text-sm text-foreground-600",
        children:
          "Надёжных данных для общей оценки качества пока недостаточно. Мы показываем параметры из каталога и не присваиваем объекту балл.",
      }),
      l.jsx("div", {
        className: "mt-4",
        children: seoLink(
          "/metodika-reytinga/",
          "Принципы отбора и сортировки",
        ),
      }),
    ],
  });
}
function Gx() {
  ot({
    title: "Базы отдыха Удмуртии — подбор по удобствам и формату отдыха",
    description:
      "Куда поехать отдыхать в Удмуртии: выбирайте базы с бассейном, баней, у воды, для семьи или компании. Каталог, сравнение и контакты объектов.",
    canonical: Be("/"),
  });
  ja(
    "home-items",
    seoListSchema("Базы отдыха Удмуртии", [...st].sort(SeoSort)),
  );
  const cats = SeoConfigList.filter(
    (c) =>
      [
        "pool",
        "kids",
        "banya",
        "water",
        "fishing",
        "hot-tub",
        "pets",
        "large-group",
        "weekend",
        "budget",
        "forest",
        "glamping",
      ].includes(c.themeKey) && seoCount(c) > 0,
  );
  return l.jsxs("div", {
    className: "min-h-screen bg-background-50 pb-[88px] md:pb-0",
    children: [
      l.jsx(ht, {}),
      l.jsx(xx, {}),
      l.jsxs("main", {
        className: "flex flex-col gap-12 py-12 md:gap-16",
        children: [
          l.jsxs("section", {
            id: "collections",
            className: SeoClass,
            children: [
              l.jsx("h2", {
                className: "mb-5 font-heading text-2xl font-bold",
                children: "Как вы хотите отдохнуть?",
              }),
              l.jsx("div", {
                className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
                children: cats.map((c) =>
                  l.jsx(
                    G,
                    {
                      to: c.slug,
                      onClick: () =>
                        vi("category_select", { category: c.themeKey }),
                      className: SeoPanel,
                      children: `${c.breadcrumbLabel} · ${seoCount(c)}`,
                    },
                    c.slug,
                  ),
                ),
              }),
            ],
          }),
          l.jsxs("section", {
            id: "rating",
            className: SeoClass,
            children: [
              l.jsx("h2", {
                className: "mb-5 font-heading text-2xl font-bold",
                children: "Базы с подробными карточками",
              }),
              l.jsx(SeoCards, { bases: [...st].sort(SeoSort) }),
              l.jsx("div", {
                className: "mt-5",
                children: seoLink("/katalog/", "Все 69 объектов и фильтры"),
              }),
            ],
          }),
          l.jsxs("section", {
            className: SeoClass,
            children: [
              l.jsx("h2", {
                className: "mb-5 font-heading text-2xl font-bold",
                children: "Ориентиры стоимости до 6 000 ₽ в будни",
              }),
              l.jsx(SeoCards, {
                bases: st
                  .filter((b) => seoMatch(b, "budget"))
                  .sort((a, b) => a.priceFrom - b.priceFrom),
              }),
              l.jsx("p", {
                className: "mt-3 text-sm text-foreground-600",
                children:
                  "Цены взяты из исходного каталога. Итоговую стоимость на выбранные даты уточняйте у объектов.",
              }),
            ],
          }),
          l.jsxs("section", {
            className: SeoClass,
            children: [
              l.jsx("h2", {
                className: "mb-5 font-heading text-2xl font-bold",
                children: "Расположение баз отдыха",
              }),
              l.jsx(cs, { items: [...st].sort(SeoSort) }),
            ],
          }),
          l.jsx("section", { className: SeoClass, children: l.jsx(ch, {}) }),
          l.jsx(SeoFAQ, {}),
        ],
      }),
      l.jsx(ft, {}),
    ],
  });
}
function lv() {
  ot({
    title: "Базы отдыха Удмуртии — список и принципы сравнения",
    description:
      "Сравните базы отдыха по условиям. Каталог по названию без неподтверждённых оценок качества.",
    canonical: Be("/rating/"),
  });
  ja(
    "rating-items",
    seoListSchema("Базы отдыха Удмуртии", [...st].sort(SeoSort)),
  );
  return l.jsx(SeoShell, {
    title: "Базы отдыха: сравнение условий",
    lead: "Объекты расположены по названию. Наличие большего числа удобств не означает лучшее качество отдыха.",
    children: [
      l.jsx("section", { className: SeoClass, children: l.jsx(ch, {}) }),
      l.jsx("section", {
        className: SeoClass,
        children: l.jsx(SeoCards, { bases: [...st].sort(SeoSort) }),
      }),
    ],
  });
}
function O1() {
  const { slug = "" } = yn(),
    d = md(slug),
    [photo, setPhoto] = S.useState(0),
    compare = gd();
  ot({
    title: d
      ? `База отдыха ${d.name} — фото и условия отдыха в Удмуртии`
      : "Объект не найден",
    description: d
      ? `${d.name}: ${d.area}. Размещение, удобства, ориентиры цен и официальный сайт. Уточните актуальные условия перед поездкой.`
      : "Объект не найден",
    canonical: Be(d ? `/bazy/${d.slug}/` : "/404/"),
    robots: d ? "index, follow" : "noindex, follow",
  });
  ja(
    "base-lodging",
    d
      ? {
          "@context": "https://schema.org",
          "@type": "LodgingBusiness",
          "@id": Be(`/bazy/${d.slug}/#object`),
          name: d.name,
          url: Be(`/bazy/${d.slug}/`),
          sameAs: d.website,
          image: d.photos.map((p) => p.url),
          address: {
            "@type": "PostalAddress",
            addressCountry: "RU",
            addressRegion: "Удмуртская Республика",
            addressLocality: d.area,
          },
          amenityFeature: [
            ["Бассейн", d.services.pool],
            ["Баня", d.services.banya],
            ["Сауна", d.services.sauna],
            ["Чан", d.services.chan],
          ]
            .filter(([, v]) => v === true)
            .map(([name]) => ({
              "@type": "LocationFeatureSpecification",
              name,
              value: true,
            })),
        }
      : null,
  );
  ja(
    "base-breadcrumb",
    d
      ? {
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            {
              "@type": "ListItem",
              position: 1,
              name: "Главная",
              item: Be("/"),
            },
            {
              "@type": "ListItem",
              position: 2,
              name: "Каталог",
              item: Be("/katalog/"),
            },
            {
              "@type": "ListItem",
              position: 3,
              name: d.name,
              item: Be(`/bazy/${d.slug}/`),
            },
          ],
        }
      : null,
  );
  S.useEffect(() => {
    if (d) seoPageEvent("base_view", { base_id: d.id });
  }, [d?.id]);
  if (!d) return l.jsx(rs, {});
  const cats = SeoConfigList.filter((c) => seoMatch(d, c.themeKey)),
    related = dl
      .filter((v) => v.id !== d.id)
      .map((v) => ({
        b: v,
        match: seoFeatures(v).filter((k) => seoFeatures(d).includes(k)).length,
      }))
      .filter((v) => v.match > 0)
      .sort((a, b) => b.match - a.match || SeoSort(a.b, b.b))
      .slice(0, 3)
      .map((v) => v.b);
  const section = (title, content) =>
    l.jsxs(
      "section",
      {
        className: SeoPanel,
        children: [
          l.jsx("h2", {
            className: "mb-4 font-heading text-xl font-bold",
            children: title,
          }),
          content,
        ],
      },
      title,
    );
  const table = (rows) =>
    l.jsx("dl", {
      className: "grid gap-3",
      children: rows.map((row) =>
        l.jsxs(
          "div",
          {
            className:
              "grid gap-1 border-b border-background-200 pb-3 sm:grid-cols-2",
            children: [
              l.jsx("dt", {
                className: "text-sm text-foreground-600",
                children: row.label,
              }),
              l.jsx("dd", {
                className: "text-sm text-foreground-950",
                children: row.value,
              }),
            ],
          },
          row.label,
        ),
      ),
    });
  const outbound = l.jsx("a", {
    href: Ir(d.website, "object", d.id),
    "data-base-id": d.id,
    target: "_blank",
    rel: "noopener nofollow sponsored",
    onClick: () =>
      Jr({
        base: d.name,
        page: seoUrl(d),
        block: "object",
        button: "Официальный сайт",
      }),
    className: SeoButton,
    children: "Связаться на официальном сайте",
  });
  return l.jsx(SeoShell, {
    title: d.name,
    lead: seoSummary(d),
    crumbs: [
      { label: "Главная", to: "/" },
      { label: "Каталог", to: "/katalog/" },
      { label: d.name },
    ],
    children: [
      l.jsxs("section", {
        className: SeoClass,
        children: [
          l.jsx("p", {
            className: "mb-4 text-sm text-foreground-600",
            children: d.address,
          }),
          l.jsxs("div", {
            className: "mb-6 flex flex-wrap gap-3",
            children: [
              outbound,
              l.jsx("button", {
                type: "button",
                className: SeoPanel,
                disabled: compare.full && !compare.has(d.id),
                onClick: () => {
                  compare.toggle(d.id);
                },
                children: compare.has(d.id)
                  ? "Убрать из сравнения"
                  : "Добавить к сравнению",
              }),
              seoLink("/sravnenie/", "Открыть сравнение"),
            ],
          }),
          l.jsxs("div", {
            className:
              "grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,320px)]",
            children: [
              l.jsxs("div", {
                className: "grid min-w-0 gap-6",
                children: [
                  section(
                    "Фотографии",
                    l.jsxs("div", {
                      children: [
                        l.jsx("img", {
                          src: d.photos[photo]?.url || d.mainImage,
                          alt: `${d.name} — фото ${photo + 1}`,
                          width: 1000,
                          height: 650,
                          fetchPriority: "high",
                          decoding: "async",
                          className:
                            "aspect-[4/3] w-full rounded-lg object-cover",
                        }),
                        l.jsx("div", {
                          className: "mt-3 flex gap-2 overflow-x-auto",
                          children: d.photos.map((p, i) =>
                            l.jsx(
                              "button",
                              {
                                type: "button",
                                "aria-label": `Фото ${i + 1}`,
                                "aria-pressed": photo === i,
                                onClick: () => setPhoto(i),
                                children: l.jsx("img", {
                                  src: p.url,
                                  alt: "",
                                  width: 96,
                                  height: 72,
                                  loading: "lazy",
                                  decoding: "async",
                                  className:
                                    "h-20 w-24 shrink-0 rounded-md object-cover",
                                }),
                              },
                              p.url,
                            ),
                          ),
                        }),
                        l.jsx("p", {
                          className: "mt-2 text-xs text-foreground-500",
                          children:
                            "Фотографии по ссылкам из исходной карточки объекта.",
                        }),
                      ],
                    }),
                  ),
                  section(
                    "Размещение и вместимость",
                    table([
                      { label: "Формат", value: d.units },
                      {
                        label: "Вместимость по данным каталога",
                        value: `${d.capacityMin}–${d.capacityMax} гостей; условия конкретного дома уточните`,
                      },
                      {
                        label: "Спальные места по данным каталога",
                        value: d.beds,
                      },
                    ]),
                  ),
                  section("Характеристики и удобства", table(T1(d))),
                  section(
                    "Цены и условия оплаты",
                    l.jsxs("div", {
                      children: [
                        table(q1(d)),
                        l.jsx("p", {
                          className: "mt-4 text-sm text-foreground-600",
                          children: `Ориентиры из исходного каталога, дата в данных: ${d.priceCheckDate}. Проверка владельцем не подтверждена. Итоговую цену, свободные даты и состав тарифа уточните у объекта.`,
                        }),
                      ],
                    }),
                  ),
                  section(
                    "Для какого отдыха подходит",
                    l.jsx("div", {
                      className: "flex flex-wrap gap-2",
                      children: cats.map((c) =>
                        seoLink(c.slug, c.breadcrumbLabel),
                      ),
                    }),
                  ),
                  section("Правила размещения", table(z1(d))),
                  section(
                    "Расположение и как добраться",
                    l.jsxs("div", {
                      children: [
                        l.jsx("p", {
                          className: "mb-4 text-sm text-foreground-600",
                          children: `${d.address}. Расстояние из каталога: около ${d.distanceKm} км от Ижевска. Точный адрес и маршрут подтвердите перед поездкой.`,
                        }),
                        l.jsx(cs, { items: [d] }),
                      ],
                    }),
                  ),
                  section(
                    "Отзывы",
                    l.jsx("p", {
                      className: "text-sm text-foreground-600",
                      children:
                        "Тексты отзывов и подтверждённые пользовательские оценки в каталоге не представлены.",
                    }),
                  ),
                  section(
                    "Источники информации",
                    l.jsxs("div", {
                      children: [
                        l.jsx("a", {
                          href: d.website,
                          target: "_blank",
                          rel: "noopener noreferrer",
                          className: "text-primary-700 underline",
                          children: "Сайт объекта из исходного каталога",
                        }),
                        l.jsx("p", {
                          className: "mt-3 text-sm text-foreground-600",
                          children: `Дата в исходной карточке: ${d.editorialCheckDate}. Независимая повторная проверка в рамках обновления кода не проводилась.`,
                        }),
                        l.jsx("div", {
                          className: "mt-3",
                          children: seoLink(
                            "/soobshit-ob-oshibke/",
                            "Сообщить о неточности",
                          ),
                        }),
                      ],
                    }),
                  ),
                ],
              }),
              l.jsxs("aside", {
                className: "grid content-start gap-5",
                children: [
                  l.jsxs("div", {
                    className: SeoPanel,
                    children: [
                      l.jsx("p", {
                        className: "font-heading text-xl font-bold",
                        children: `От ${d.priceFrom.toLocaleString("ru-RU")} ₽`,
                      }),
                      l.jsx("p", {
                        className: "mb-4 mt-2 text-sm text-foreground-600",
                        children: "Ориентир из каталога, стоимость уточняется",
                      }),
                      outbound,
                      l.jsx("div", {
                        className: "mt-4",
                        children: seoLink(
                          "/sravnenie/",
                          "Сравнить выбранные базы",
                        ),
                      }),
                    ],
                  }),
                  l.jsx(ch, {}),
                ],
              }),
            ],
          }),
        ],
      }),
      l.jsx(SeoFAQ, {
        items: [
          {
            q: `Как уточнить стоимость отдыха в «${d.name}»?`,
            a: "Перейдите на сайт объекта. Укажите даты, количество гостей и нужные услуги. Стоимость из каталога является ориентиром.",
          },
          {
            q: "Можно ли приехать с питомцем?",
            a: d.badges.includes("pets")
              ? "В исходном каталоге есть признак проживания с животными. Размер, породу, доплаты и правила согласуйте с объектом."
              : d.pets,
          },
        ],
      }),
      l.jsxs("section", {
        className: SeoClass,
        children: [
          l.jsx("h2", {
            className: "mb-5 font-heading text-2xl font-bold",
            children: "Другие базы с похожими удобствами",
          }),
          l.jsx(SeoCards, { bases: related }),
        ],
      }),
      l.jsx("div", { className: "seo-mobile-contact", children: outbound }),
    ],
  });
}
function ot({ title, description, canonical, robots = "index, follow" }) {
  const { search, pathname } = Nt();
  S.useEffect(() => {
    if (title) document.title = title;
    gi("name", "description", description);
    gi("property", "og:title", title);
    gi("property", "og:description", description);
    gi("name", "twitter:title", title);
    gi("name", "twitter:description", description);
    const p = new URLSearchParams(search),
      functional = [...p.keys()].some(
        (k) => !/^utm_|^(yclid|gclid|fbclid|_ym_uid|_ym_d)$/.test(k),
      );
    gi("name", "robots", functional ? "noindex, follow" : robots);
    if (canonical) {
      bx(canonical);
      gi("property", "og:url", canonical);
    }
    const image =
      SeoPrimary.get(dl.find((b) => `/bazy/${b.slug}/` === pathname)?.id)
        ?.mainImage ||
      "https://storage.helloreaddy.io/project_files/ca0f8dfd-6612-4ac6-8cab-7fac7b5a4012/e2c52009-55da-4986-b297-f2972daad92d_compressed_449bf7f9-b41d-4362-8b21-712714e218c6.webp";
    gi("property", "og:image", image);
    gi("name", "twitter:image", image);
  }, [title, description, canonical, robots, search, pathname]);
}
function ja(id, data) {
  const { key } = Nt();
  S.useEffect(() => {
    const old = document.head.querySelector(`script[data-jsonld="${id}"]`);
    if (old) old.remove();
    if (!data) return;
    const e = document.createElement("script");
    e.type = "application/ld+json";
    e.dataset.jsonld = id;
    e.textContent = JSON.stringify(data).replace(/</g, "\\u003c");
    document.head.appendChild(e);
    return () => e.remove();
  }, [id, JSON.stringify(data), key]);
}
const SeoSeenEvents = new Set();
const SeoNavigation = { key: null, serial: 0, path: null };
function seoPageEvent(event, payload = {}) {
  const key = [
    SeoNavigation.serial,
    event,
    location.pathname,
    JSON.stringify(payload),
  ].join("|");
  if (SeoSeenEvents.has(key)) return;
  SeoSeenEvents.add(key);
  vi(event, payload);
}
function Kh(event, payload = {}) {
  if (typeof window === "undefined" || window.__SEO_PRERENDER__) return;
  const clean = {};
  for (const [key, value] of Object.entries(payload)) {
    if (
      [
        "base_id",
        "page",
        "block",
        "category",
        "result_count",
        "features",
        "format",
        "guests",
        "area",
        "price",
        "scope",
        "value",
        "device",
      ].includes(key) &&
      ["string", "number", "boolean"].includes(typeof value)
    )
      clean[key] = value;
  }
  const item = { event, ...clean };
  (window.dataLayer = window.dataLayer || []).push(item);
  if (typeof window.ym === "function")
    window.ym(113576337, "reachGoal", event, clean);
}
function vi(event, payload = {}) {
  Kh(event, payload);
}
function Jr(info) {
  const b = [...st, ...Wr].find((v) => v.name === info.base);
  Kh("external_site_click", {
    base_id: b?.id || "",
    page: info.page,
    block: info.block,
  });
}
function SeoLifecycle() {
  const { pathname, key } = Nt();
  S.useEffect(() => {
    if (SeoNavigation.key !== key) {
      if (
        SeoNavigation.path &&
        SeoNavigation.path !== pathname &&
        typeof window.ym === "function" &&
        !window.__SEO_PRERENDER__
      )
        window.ym(113576337, "hit", Be(pathname));
      SeoNavigation.key = key;
      SeoNavigation.path = pathname;
      SeoNavigation.serial++;
    }
    for (const e of document.querySelectorAll("script[data-jsonld]"))
      e.remove();
    const schema = {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "WebSite",
          "@id": Be("/#website"),
          url: Be("/"),
          name: "Базы отдыха Удмуртии",
          inLanguage: "ru-RU",
        },
        {
          "@type": "Organization",
          "@id": Be("/#organization"),
          name: "Базы18",
          url: Be("/"),
        },
      ],
    };
    const e = document.createElement("script");
    e.type = "application/ld+json";
    e.dataset.jsonld = "site";
    e.textContent = JSON.stringify(schema);
    document.head.appendChild(e);
    return () => e.remove();
  }, [pathname, key]);
  return null;
}
function L1() {
  ot({
    title: "Расположение баз отдыха Удмуртии — поиск на карте",
    description:
      "Найдите выбранную базу отдыха на Яндекс Картах. Проверьте адрес и маршрут у объекта.",
    canonical: Be("/karta/"),
  });
  return l.jsx(SeoShell, {
    title: "Расположение баз отдыха",
    lead: "Поиск по названию и адресу из каталога. Точные точки необходимо подтвердить у объектов.",
    children: l.jsx("section", {
      className: SeoClass,
      children: l.jsx(cs, { items: [...st, ...Wr].sort(SeoSort) }),
    }),
  });
}
function SeoCollections() {
  const items = SeoConfigList.filter((c) => seoCount(c) > 0);
  ot({
    title: "Подборки баз отдыха Удмуртии — по задаче поездки",
    description:
      "Подборки по удобствам и формату отдыха с объектами из каталога.",
    canonical: Be("/podborki/"),
  });
  return l.jsx(SeoShell, {
    title: "Подборки по задаче поездки",
    lead: "Выберите удобства и формат отдыха. В подборках представлены только объекты с соответствующим признаком в каталоге.",
    children: l.jsx("section", {
      className: SeoClass,
      children: l.jsx("div", {
        className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
        children: items.map((c) =>
          l.jsx(
            G,
            {
              to: c.slug,
              className: SeoPanel,
              onClick: () => vi("category_select", { category: c.themeKey }),
              children: `${c.breadcrumbLabel} · ${seoCount(c)}`,
            },
            c.slug,
          ),
        ),
      }),
    }),
  });
}
function Mv() {
  return l.jsx(SeoCollections, {});
}
const SeoMethod = B1.find((p) => p.path === "/metodika-reytinga/");
Object.assign(SeoMethod, {
  title: "Принципы отбора и сортировки баз отдыха",
  lead: "Каталог помогает сравнить условия. Соответствие сценарию поездки и оценка качества — разные задачи.",
  seoTitle: "Принципы отбора и сортировки — Базы18",
  seoDescription:
    "Почему каталог использует нейтральный порядок, как выбираются объекты для подборок и что означает отсутствие данных.",
  criteria: false,
  updated: "16 ноября 2026",
  sections: [
    {
      heading: "Почему нет общего балла",
      paragraphs: [
        "В исходном проекте были редакционные оценки, но данных для их независимой проверки недостаточно: нет доступных отзывов, истории расчёта и доказательств по каждому критерию. Поэтому публичные баллы и места не показываются.",
        "По умолчанию объекты расположены по названию. В каталоге можно выбрать сортировку по ориентиру цены или расстоянию. Число удобств не используется как показатель качества.",
      ],
    },
    {
      heading: "Как работают подборки",
      paragraphs: [
        "В подборку попадают только объекты с соответствующим признаком в данных каталога. Нельзя заменить бассейн чаном или считать расположение у воды подтверждением безопасного купания.",
        "Отсутствие подтверждения означает необходимость уточнения, а не доказанное отсутствие услуги. Свободные даты, итоговую стоимость и правила подтверждает объект.",
      ],
    },
    {
      heading: "Происхождение и актуальность",
      paragraphs: [
        "Используются записи и ссылки из исходного каталога. Даты в карточках перенесены из этих данных и не означают повторную проверку владельцем сайта.",
        "Для будущего рейтинга необходимы реальные источники отзывов, количество оценок, дата получения и прозрачная воспроизводимая формула. До появления таких данных рейтинг качества не публикуется.",
      ],
    },
  ],
});
// Keep existing navigation URLs; change only unsubstantiated ranking labels.
for (const link of ah)
  if (link.to === "/rating/") link.label = "Сравнение условий";
// Module-only inspection contract for reproducible checks, never a network endpoint.
if (window.__SEO_TEST__)
  window.__SEO_AUDIT__ = {
    bases: st,
    details: dl,
    extra: Wr,
    configs: SeoConfigList.map((c) => ({
      ...c,
      primary: seoMembers(c).primary.map((b) => b.id),
      extra: seoMembers(c).extra.map((b) => b.id),
      count: seoCount(c),
    })),
    match: seoMatch,
    filterPrimary: ef,
    filterExtra: yv,
  };
function T1(b) {
  const s = b.services;
  return [
    { label: "Баня", ...Yt(s.banya, "Баня на территории") },
    { label: "Сауна", ...Yt(s.sauna, "Сауна на территории") },
    { label: "Чан", ...Yt(s.chan, "Чан на территории") },
    { label: "Бассейн", ...Yt(s.pool, "Бассейн на территории") },
    { label: "Ресторан", ...Yt(s.restaurant, "Ресторан на территории") },
    { label: "Кафе", ...Yt(s.cafe, "Кафе на территории") },
    { label: "Завтрак", ...Yt(s.breakfast, "Завтрак по тарифу") },
    {
      label: "Кухня в доме",
      ...Yt(s.kitchen, "Кухня для самостоятельного приготовления"),
    },
    { label: "Водоём", value: b.water.body },
    {
      label: "Расстояние до воды",
      value: b.water.distance === "—" ? "Не подтверждено" : b.water.distance,
    },
    { label: "Пляж", value: b.water.beach },
    { label: "Рыбалка", ...Yt(b.fishing.available, b.fishing.note) },
    { label: "Пирс", ...Yt(b.fishing.pier, "Пирс на территории") },
    { label: "Прокат лодки", ...Yt(b.fishing.boat, "Прокат лодки") },
    { label: "Wi-Fi", value: b.wifi },
    { label: "Мобильная связь", value: b.mobile },
    { label: "Парковка", value: b.parking },
    { label: "Зимний подъезд", value: b.winterAccess },
    { label: "Режим тишины", value: b.noise },
  ];
}
Jx.pets = "С животными";
if (!cv.includes("pets")) cv.push("pets");
function SeoExtraFilters({ filters, onChange }) {
  const districts = [
    ...new Set(
      [...st.map((b) => b.district), ...Wr.map((b) => b.district)].filter(
        Boolean,
      ),
    ),
  ].sort((a, b) => a.localeCompare(b, "ru"));
  const fields = [
    [
      "district",
      "Район или город",
      [["", "Все районы и города"], ...districts.map((v) => [v, v])],
    ],
    [
      "capacity",
      "Количество гостей",
      [
        ["", "Не важно"],
        ["2", "От 2 гостей"],
        ["4", "От 4 гостей"],
        ["10", "От 10 гостей"],
        ["20", "От 20 гостей"],
      ],
    ],
    [
      "overnight",
      "Размещение",
      [
        ["", "Любой вариант"],
        ["yes", "Есть размещение в доме или номере"],
      ],
    ],
    [
      "season",
      "Сезонность",
      [
        ["", "Любая сезонность"],
        ["year", "Круглогодично по данным каталога"],
      ],
    ],
  ];
  return l.jsxs("div", {
    className: SeoPanel,
    children: [
      l.jsx("p", {
        className: "mb-4 text-sm text-foreground-600",
        children:
          "Удмуртская Республика. Объекты без данных о вместимости не попадают под фильтр количества гостей.",
      }),
      l.jsx("div", {
        className: "grid gap-4 sm:grid-cols-2",
        children: fields.map(([key, label, options]) =>
          l.jsxs(
            "label",
            {
              className: "grid gap-2 text-sm",
              children: [
                label,
                l.jsx("select", {
                  value: filters[key] || "",
                  onChange: (e) =>
                    onChange({ ...filters, [key]: e.target.value }),
                  className:
                    "rounded-md border border-background-300 bg-background-50 px-3 py-2",
                  children: options.map(([value, text]) =>
                    l.jsx("option", { value, children: text }, value),
                  ),
                }),
              ],
            },
            key,
          ),
        ),
      }),
    ],
  });
}
function seoExtraMatch(b, r) {
  const d = SeoPrimary.get(b.id);
  if (r.district && (d ? b.district : b.district) !== r.district) return false;
  if (
    r.capacity &&
    (!d || !d.capacityMax || d.capacityMax < Number(r.capacity))
  )
    return false;
  if (
    r.overnight === "yes" &&
    !(d
      ? b.formats.some((v) => ["Дома", "Коттеджи", "Номера"].includes(v))
      : SeoTag(b, "Домики"))
  )
    return false;
  if (
    r.season === "year" &&
    !(d ? /круглогодич/i.test(d.winterAccess) : SeoTag(b, "Круглый год"))
  )
    return false;
  return true;
}

function Zx(i) {
  return (
    [
      i.format,
      i.guests,
      i.area,
      i.price,
      i.district,
      i.capacity,
      i.overnight,
      i.season,
    ].filter(Boolean).length + i.features.length
  );
}
function seoSummary(b) {
  const d = SeoPrimary.get(b.id);
  if (!d) return b.name;
  const features = seoFeatures(b)
    .map((k) => SeoFeatureNames[k])
    .filter(Boolean)
    .slice(0, 5)
    .join(", ");
  return `${b.district}. ${d.units}. ${features ? `В данных каталога: ${features.toLowerCase()}.` : ""} Актуальные условия уточните у объекта.`;
}
const SeoAdvice = {
  pool: "В подборке учтён именно бассейн. Чан и купель не заменяют бассейн для плавания. Уточните подогрев, глубину, сезон работы и стоимость посещения.",
  banya:
    "Баня и сауна могут иметь разные условия аренды. Уточните вид парной, время посещения и входит ли она в стоимость проживания.",
  water:
    "Расположение рядом с водоёмом не подтверждает доступ к берегу и безопасность купания. Перед поездкой уточните эти условия у объекта.",
  kids: "Уточните спальные места для детей, безопасность территории, условия посещения бассейна и доступность детской площадки.",
  fishing:
    "Наличие рыбалки не означает, что снасти, лодка или разрешение на лов входят в тариф. Согласуйте сезон, правила и стоимость.",
  pets: "Признак проживания с питомцами взят из каталога. До оплаты согласуйте породу, размер животного, доплату и ограничения.",
  budget:
    "В этой подборке ориентир цены в будни — до 6 000 ₽. Это цена из исходного каталога, а не предложение на конкретные даты. Сравните доплаты, залог и условия тарифа.",
  winter:
    "Круглогодичная работа указана в исходных данных. Уточните отопление, состояние подъезда и доступность удобств зимой.",
  glamping:
    "В подборке учтены глэмпинги и сафари-тенты. Уточните сезонность конкретного варианта, санузел, отопление и приватность.",
  weekend:
    "Уточните минимальный срок аренды и время заезда на нужные выходные. Проживание от суток в исходных данных не гарантирует доступность любой даты.",
};
